export type Identity = "nik" | "rumi";

export type Vow = {
  key: string;
  author: Identity;
  title: string;
  text: string;
};

export type ChatLine = {
  id: string;
  sender: "Rumii" | "Nik";
  identity: Identity;
  time: string;
  text: string;
};

export const NAMES = {
  nik: {
    short: "Nik",
    nick: "Nikhil",
    full: "Nikhil Mehra",
    display: "Nikhil Mehra",
  },
  rumi: {
    short: "Rumi",
    nick: "Rumii",
    full: "Rashmika Mehra",
    maiden: "Rashmika Rana",
    display: "Rashmika Mehra",
  },
};

export const WEDDING_DATE_LABEL = "13 September 2026";
export const WEDDING_DATE_SHORT = "09.13.2026";

export const FAMILIES = {
  grooms: {
    person: "Nikhil Mehra",
    now: "Nikhil Mehra",
    father: "Pramod Mehra",
    mother: "Sunita Mehra",
  },
  brides: {
    person: "Rashmika Mehra",
    maiden: "Rashmika Rana (Rumi) — now Rashmika Mehra",
    now: "Rashmika Mehra",
    father: "Mahaveer Rana",
    mother: "Sukh Dei",
  },
};

export const VOWS: Vow[] = [
  {
    key: "rumi-1",
    author: "rumi",
    title: "Chhoti si problem, badi nahi",
    text: "Ham ek dusre se naraz ho sakte h but baat na krke choti si prblm ko kbhi bhi bada nhi karenge me ya aap glti maan kr sorry bol denge aur ek hi topic pe argument nhi krnge unless it's necessary 😝🎀",
  },
  {
    key: "rumi-2",
    author: "rumi",
    title: "Baat karke suljhana",
    text: "Jab bhi apne bich koi misunderstanding hogi ham baat krke solve krenge chup rhke dur ny jayenge aur busy hone pe aake bol denge ki kuch kam h ignore nhi kr rhi/rha aur kitna bhi busy day ho ham ek dusre ke liye time nikalne ki puri koshish krenge (aap apne dost ke sath thoda kam ghumo bby)",
  },
  {
    key: "rumi-3",
    author: "rumi",
    title: "Feelings aur izzat",
    text: "Ham ek dusre ki feelings ki hamesha respect karenge equal efforts pay krenge gusse m kbhi bhi ek dusre ko hurt krne vale words nhi bolenge",
  },
  {
    key: "rumi-4",
    author: "rumi",
    title: "Trust, sach, no jhoot",
    text: "Ham hamesha ek dusre pe trust banaye rkhenge kbhi bhi usko break nhi karenge sath hi ek dusre ko smjhne ki koshish karenge change krne ke bajaye jhuth nhi bolenge jo bhi hoga aake sach bol denge chahe vo fir kaisa bhi ho apna rishta jhuth ke base pr nhi chalega 😝☝🏻",
  },
  {
    key: "nik-1",
    author: "nik",
    title: "Pehla vachan — ladayi, ignore, attitude",
    text: "Mai Nikhil Mehra aaj 13.Sep.2026 ko ye likh rha hu kyuki aaj meri hone wali wifey Rashmika Mehra banne wali hai. Sabse pehle ye ki hum dono kaafi abnormal behave krne lag jate ladayi ke beech — jaise ek dusre ke kuch lagte ho na ho ya farq na padta ho. Wo sab khatam karna hai. Ladayi wahi na khatam krne ki jagah hum badhate rehte aur baar baar off chale jate hain jisse baat bhi nahi hoti aur sab kharab ho jata. Abse ye nahi hoga. Ignore na karna, farq nahi padta wala attitude nahi, kyuki wo hurt karta hai. Hum jhoot nahi bolenge — aake bolenge kahan ho, kitna time lagega.",
  },
  {
    key: "nik-2",
    author: "nik",
    title: "Doosra vachan — rude baat, jhoot, trust",
    text: "Aap merse kabhi kabhi gusse mein bahut rudely baat karti ho, mujhe hurt hota hai. Jhoot inn cheezon mein band — koi bhi baat ho merko batao, main kha thodi jaunga. Male friends ke msg aayenge toh bataogi, naya nahi banana, kisi ladke se baat nahi, kyuki ab aap meri wifey ban gayi ho. Baaki main aapke har nakhra, har cheez, aapki ghulami ke liye bhi taiyar hu. RLS mein balanced rakhunga — meri galti par bhi aaunga. Oki bby?",
  },
  {
    key: "nik-3",
    author: "nik",
    title: "Saath nahi chhodunga",
    text: "Vachan ye hai ki aapka sath nahi chodunga bby. Aap jahan tak na merse kisi bhi type ki waisi harkate karti, main aapse breakup thing ko lekar wapas kabhi baat nahi karunga. Agar karun toh maan lena chakka tha chala gaya — ye bol dena chalega merko, par aap ko iski puri zindagi need na pade bolne ki. Iska main khayal rakhunga bby. I love you so muchhhh myy love rummiiii 💋🎀",
  },
  {
    key: "nik-4",
    author: "nik",
    title: "Humari baatein sirf hamari",
    text: "Hum humari private chats, humari personal baatein, humari talks, humare DM mein ki gayi kesi bhi kuch bhi baat kabhi bhi kisi ko kabhi bhi share nahi karenge. Ladai ho jaye ya kuch bhi — khud se solve karenge, kabhi kisi aur se kuch nahi bolenge. Bass.",
  },
];

export const CHATS: ChatLine[] = [
  {
    id: "c1",
    sender: "Rumii",
    identity: "rumi",
    time: "9/13/2026 9:11 PM",
    text: "Ham ek dusre se naraz ho sakte h but baat na krke choti si prblm ko kbhi bhi bada nhi karenge me ya aap glti maan kr sorry bol denge aur ek hi topic pe argument nhi krnge unless it's necessary😝😝😝🎀",
  },
  {
    id: "c2",
    sender: "Rumii",
    identity: "rumi",
    time: "9/13/2026 9:12 PM",
    text: "Jab bhi apne bich koi misunderstanding hogi ham baat krke solve krenge chup rhke dur ny jayenge aur busy hone pe aake bol denge ki kuch kam h ignore nhi kr rhi/rha aur kitna bhi busy day ho ham ek dusre ke liye tem nikalne ki puri koshish krenge (aap apne dost ke sath thoda kam ghumo bby)",
  },
  {
    id: "c3",
    sender: "Rumii",
    identity: "rumi",
    time: "9/13/2026 9:12 PM",
    text: "Ham ek dusre ki feelings ki hamesha respect karenge equal efforts pay krenge gusse m kbhi bhi ek dusre ko hurt krne vale words nhi bolenge",
  },
  {
    id: "c4",
    sender: "Rumii",
    identity: "rumi",
    time: "9/13/2026 9:12 PM",
    text: "Ham ek dusre se naraz ho sakte h but baat na krke choti si prblm ko kbhi bhi bada nhi karenge me ya aap glti maan kr sorry bol denge aur ek hi topic pe argument nhi krnge unless it's necessary",
  },
  {
    id: "c5",
    sender: "Rumii",
    identity: "rumi",
    time: "9/13/2026 9:12 PM",
    text: "Ham hamesha ek dusre pe trust banaye rkhenge kbhi bhi usko break nhi karenge sath hi ek dusre ko smjhne ki koshi karenge change krne ke bajaye jhuth nhi bolenge jo bhi hoga aake sach bol denge chahe vo fir kaisa bhi ho apna rishta jhuth ke base pr nhi chalega😝☝🏻",
  },
  {
    id: "c6",
    sender: "Nik",
    identity: "nik",
    time: "9/13/2026 9:48 PM",
    text: "Mai nikhil mehra aaj 13.sep.2026 ko ye likh rha hu 😋 kyuki aaj meri aur meri jo hone wali wifey hai rashmika mehra banne wali hai 😈👆🏻 toh ab shadi ke pehle mai kuch vachan lunga and kuch baatein share krunga and kuch bolunga jo meri bawnii wifey rumi ko apne mai change krni hogi sabse pehle toh ye ki hum dono kaafi ab normal behave krne lag jate 😭💔 ladayi ke bheech mai jaise dono ek dusre ke kuch lagte ho na ho ya frk na padta ho esi faltu ki bkc krne lagte wo sab khtm Krna and ladayi jo whi na khtm krne ki jgh hum badhate rehte aur 😔 aur baar baar off chlew jate hai jisse fir baat bhi nhi krte aur fir sab khrab hojata 😭 and abse ye nhi ho mai ye chata hu and bby aap bhi esa kuch na kro ye dhyan rakhna ignore na Krna , abnormal jaise like frk ni padta aapse ye wo kyuki wo hurt krta ngl bolte nhi khudka silly attitude ko upar rkhne ke liye ik 😭💔 bby hum juth nhi bolenge bss kabhi bhi 😡😡 aake bolenge kaha hai kitna time lgega ye wo and aapko agar thoda bhi lagta hai mai ignore krta aapko toh abse nhi lagega meri hi gltiyo ke karan lagta 😭👆🏻 mai bhi lodu hu thoda saw and bby ye hogya pehla vachan and 2nd hai ki aap merse bhut hi jyada bhut hi jyada rudely baat krti kabhi kabhi gusse mai wo aapko nhi malum padta pr mai kilas bhi jata aur meko hurt v hota 😭 bby and aapne merse jhut bola tha ki aap ladko se baat ni kr rhi 😔 wo rls mai hoke bhi aap kr hi rhi thi aapne bola only ek gc mai hu ladko se baat ni krri and wagera wagera ki saare bhaiya bhabhi hai uss gc mai ye cheez maine bby aap pr trust krke maan li thi chalo itna trust kr sktaw pr uss time breakup hogya tha toh kuch pucha bhi nhi maine toh pr apna breakup 2 din chala dhang se then patchup hogya 😭🥀 bhut achi baat hai but uss time maine id kholi toh dekha ki rls mai the uske bhi pehle se aap baat toh kr rhi thi and maine jitne bhi ladke bataye aapne kaha sab dost hai toh wo sab 2 din mai toh banne nhi hoge itne ? 😭 Toh bby aap jhut bolna band krdo pls inn cheezo mai toh and kuch bhi hai aap merko batao naw mai aapko kha thodi jaunga 😭 agar abhi bhi kuch ho toh bata drna pls kyuki mai viswaas nhi kr pata abhi bhi uske liye sorry meko Krna chiye pr nhi krta 1% bhi mai 😭💔🥀 kyuki aap jhut pakde janne ke baad off ese bhagti ho kya bolu replies bhi waise dene lag jati aap rude se 😔 🥀 and aap jhut bolne lag jati and aap jhut toh har baar hi bolti ho kya bolu 😭 bss ye chodd do bby baaki mai aapke har cheez har nakhre aapki gulami krne ko bhi taiyar hu mai aapse waada krta hu ki rls mai balanced rkhunga kuch bhi ho jaye tab bhi mai aaunga aapko meri glti pr v aajaunga pr mai jesa chata hu wesi aap ban toh jaaw 🤭 oki bby ???? Haa aur wo ek cheez aap ab koi v msg aayega toh meko bataogi male freinds abhi jaha tk meko aap pr trust nhi ek bhi nhi banaogi na kisi se baat krogi aap , kyuki aap wesi ny ho ki aapko kisi ladke se baat krne de saku as a freind bhi so nhi krogi aap kisi ladke se baat ya ye rls nhi chlegaw mere sath toh 😈👆🏻 pr aap nahi krogi ab aap meri wifey ban gyi ho aur shyd achi v ban gyi ho thodi toh 🤭🤭 samjhne lagi ho cheezo ko thoda {{{{ BBY SORRY YE WALI CHEEZE REMIND KRNE KE LIYE PR JRURI THA HADS SE JYADA 🤧🫰🏻 }}}} Btw ab vanchan aur promises ka alag likhunga yeto bkc krdi maine 🤣🤣",
  },
  {
    id: "c7",
    sender: "Nik",
    identity: "nik",
    time: "9/13/2026 9:51 PM",
    text: "Vachan ye hai ki aapka sath nhi chodunga bby aap jaha tk na merse kisi bhi type ki waisi harkate krti and mai aapse breakup thing ko lekar wapas kabhi baat ny krunga agar krri toh Maan Lena chakka tha chala gay 😭💔 ye bol den achalega merko pr aap ko iski puri zindagi need na pade bolne ki iska mai khyal rakhunga bby 💋🎀 btw I love you so muchhhh myy love rummiiii 🤭🤭",
  },
  {
    id: "c8",
    sender: "Nik",
    identity: "nik",
    time: "9/13/2026 9:54 PM",
    text: "Hum humari private chats hum humari personal baatein humari talks humare dm mai ki gyi kesi bhi kuch bhi baat hum kabhi bhi bhi kisi ko kabhi bhi share nhi krenge ladayi hoajye ya kuch bhi khudse solve karengew kabhi kisi aur se kuch nhi bolengey bss",
  },
];

export const GALLERY = [
  {
    src: "/images/the-big-day.png",
    title: "The Big Day",
    caption: "Nikhil & Rashmika · our mandap",
  },
  {
    src: "/images/pheras.png",
    title: "Pheras",
    caption: "Saat phere around the sacred fire",
  },
  {
    src: "/images/sindoor.png",
    title: "Sindoor",
    caption: "Nikhil filling Rashmika's sindoor",
  },
  {
    src: "/images/varmala.png",
    title: "Varmala",
    caption: "Jaimala — we chose each other",
  },
];

export function partnerOf(who: Identity): Identity {
  return who === "nik" ? "rumi" : "nik";
}

export function displayName(who: Identity): string {
  return who === "nik" ? NAMES.nik.full : NAMES.rumi.full;
}
