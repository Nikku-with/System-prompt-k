import { HashRouter, Routes, Route, Navigate, useParams, useSearchParams } from "react-router-dom";
import AppShell from "./components/AppShell";
import ShareView from "./components/ShareView";

function InviteRedirect() {
  const { token } = useParams();
  return <Navigate to={`/?invite=${encodeURIComponent(token ?? "")}`} replace />;
}

function MemoryRoute() {
  const { token } = useParams();
  return <ShareView token={token ?? ""} />;
}

function LegacyPathRedirect() {
  // Only run on initial load — once a hash route exists, stay out of the way.
  const hash = window.location.hash || "";
  if (hash && hash !== "#/" && hash !== "#") return null;
  const p = window.location.pathname;
  if (p.startsWith("/invite/") && p.length > "/invite/".length) {
    return <Navigate to={`/invite/${encodeURIComponent(p.slice("/invite/".length))}`} replace />;
  }
  if (p.startsWith("/m/") && p.length > "/m/".length) {
    return <Navigate to={`/m/${encodeURIComponent(p.slice("/m/".length))}`} replace />;
  }
  // Old-style query links sent before this fix: /?invite=... or /?m=...
  const q = new URLSearchParams(window.location.search);
  const inv = q.get("invite");
  if (inv) return <Navigate to={`/?invite=${encodeURIComponent(inv)}`} replace />;
  const m = q.get("m");
  if (m) return <Navigate to={`/m/${encodeURIComponent(m)}`} replace />;
  return null;
}

function Home() {
  const [params] = useSearchParams();
  const m = params.get("m");
  if (m) return <ShareView token={m} />;
  return <AppShell />;
}

export default function App() {
  return (
    <HashRouter>
      <LegacyPathRedirect />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/invite/:token" element={<InviteRedirect />} />
        <Route path="/m/:token" element={<MemoryRoute />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </HashRouter>
  );
}
