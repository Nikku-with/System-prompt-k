import { useEffect, useState } from "react";

type Memory = {
  author: string;
  type: string;
  title: string | null;
  content: string | null;
  mediaPath: string | null;
  createdAt: string;
};

export default function ShareView({ token }: { token: string }) {
  const [password, setPassword] = useState("");
  const [needsPassword, setNeedsPassword] = useState(false);
  const [memory, setMemory] = useState<Memory | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    async function load() {
      const res = await fetch(`/api/share/${token}`, { cache: "no-store" });
      const data = (await res.json()) as {
        ok?: boolean;
        needsPassword?: boolean;
        memory?: Memory;
        error?: string;
      };
      if (!data.ok) {
        setError(data.error || "Not found");
        return;
      }
      if (data.needsPassword) {
        setNeedsPassword(true);
        return;
      }
      setNeedsPassword(false);
      setMemory(data.memory ?? null);
    }
    void load();
  }, [token]);

  async function unlockWithPassword(pw: string) {
    const res = await fetch(`/api/share/${token}?password=${encodeURIComponent(pw)}`, { cache: "no-store" });
    const data = (await res.json()) as {
      ok?: boolean;
      needsPassword?: boolean;
      memory?: Memory;
      error?: string;
    };
    if (!data.ok) {
      setError(data.error || "Not found");
      return;
    }
    if (data.needsPassword) {
      setError("Wrong password 💔");
      return;
    }
    setError("");
    setNeedsPassword(false);
    setMemory(data.memory ?? null);
  }

  return (
    <main className="scene grid place-items-center bg-[#14060a] px-5 text-rose-50">
      <div className="w-full max-w-lg rounded-[28px] border border-amber-200/20 bg-[#2b0b12] p-6">
        <p className="font-script text-4xl text-amber-200">Nik & Rumi</p>
        <h1 className="font-serif text-2xl">Shared memory</h1>
        {needsPassword ? (
          <form
            className="mt-4 space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              void unlockWithPassword(password);
            }}
          >
            <p className="text-sm text-rose-100/70">This memory is locked.</p>
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-2xl border border-amber-200/20 bg-black/30 px-4 py-2 outline-none"
              placeholder="password"
            />
            <button type="submit" className="gold-btn rounded-full px-5 py-2">
              Open
            </button>
          </form>
        ) : null}
        {error ? <p className="mt-3 text-rose-200">{error}</p> : null}
        {memory ? (
          <article className="mt-4">
            <p className="text-xs uppercase tracking-[0.25em] text-amber-200/70">
              {memory.author === "nik" ? "Nikhil" : "Rashmika"}
            </p>
            {memory.title ? <p className="font-serif mt-2 text-xl">{memory.title}</p> : null}
            {memory.content ? <p className="mt-2 text-sm leading-relaxed">{memory.content}</p> : null}
            {memory.mediaPath && memory.type === "photo" ? (
              <img src={memory.mediaPath} alt="" className="mt-3 w-full rounded-2xl" />
            ) : null}
            {memory.mediaPath && memory.type === "video" ? (
              <video src={memory.mediaPath} controls className="mt-3 w-full rounded-2xl" />
            ) : null}
            {memory.mediaPath && memory.type === "voice" ? (
              <audio src={memory.mediaPath} controls className="mt-3 w-full" />
            ) : null}
          </article>
        ) : null}
      </div>
    </main>
  );
}
