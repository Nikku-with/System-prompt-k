export default function Petals({ count = 20 }: { count?: number }) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <span
          key={i}
          className="petal"
          style={{
            left: `${(i * 47 + 3) % 100}%`,
            animationDuration: `${7 + (i % 8)}s`,
            animationDelay: `${(i % 10) * 0.45}s`,
            width: 9 + (i % 7),
            height: 12 + (i % 9),
            opacity: 0.55 + (i % 5) * 0.08,
          }}
        />
      ))}
    </>
  );
}
