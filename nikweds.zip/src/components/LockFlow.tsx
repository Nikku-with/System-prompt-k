import { useState } from "react";
import type { Identity } from "../lib/content";
import Petals from "./Petals";

type Stage = "lock" | "welcome" | "identity";

export default function LockFlow({
  stage,
  onUnlock,
  onWelcomeDone,
  onPickIdentity,
  inviteHint,
}: {
  stage: Stage;
  onUnlock: (date: string) => Promise<boolean>;
  onWelcomeDone: () => void;
  onPickIdentity: (id: Identity) => Promise<void>;
  inviteHint?: string | null;
}) {
  const [date, setDate] = useState("");
  const [typed, setTyped] = useState("");
  const [error, setError] = useState("");
  const [shake, setShake] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(value: string) {
    setBusy(true);
    setError("");
    const ok = await onUnlock(value);
    setBusy(false);
    if (!ok) {
      setError("Nahi baby… woh date nahi hai. Soch ke set karo 💗");
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }
  }

  if (stage === "welcome") {
    return (
      <section className="scene flex items-center justify-center bg-[radial-gradient(circle_at_top,#6b1020,transparent_45%),linear-gradient(180deg,#1a0508,#3a0710_60%,#14060a)] px-6 text-center">
        <Petals count={24} />
        <div className="relative z-10 max-w-3xl">
          <p className="font-corm text-sm tracking-[0.55em] text-amber-200/80 uppercase">
            13 · 09 · 2026
          </p>
          <div className="mx-auto mt-6 h-24 w-24 rounded-full border border-amber-300/40 bg-gradient-to-b from-amber-200/30 to-transparent animate-[spin-slow_18s_linear_infinite]" />
          <p className="welcome-title font-script mt-4 text-4xl text-amber-100 sm:text-5xl">
            Welcome to
          </p>
          <h1 className="welcome-title font-serif mt-2 text-5xl leading-tight text-amber-50 sm:text-7xl">
            <span className="gold-text">Nik & Rumi</span>
            <br />
            World
          </h1>
          <p className="font-corm mt-6 text-xl text-rose-100/90">
            Welcome to Nik & Rumi world wedding stuffs
          </p>
          <button
            type="button"
            onClick={onWelcomeDone}
            className="gold-btn mt-10 rounded-full px-8 py-3 text-sm"
          >
            Enter wedding mandap ✦
          </button>
        </div>
      </section>
    );
  }

  if (stage === "identity") {
    return (
      <section className="scene flex items-center justify-center bg-[linear-gradient(180deg,#1a0508,#4a0d18)] px-5 py-12">
        <Petals count={14} />
        <div className="relative z-10 w-full max-w-4xl">
          <p className="text-center font-corm text-sm tracking-[0.4em] text-amber-200/80 uppercase">
            Who is opening this world?
          </p>
          <h2 className="font-script mt-2 text-center text-5xl text-amber-50">
            Select your name
          </h2>
          {inviteHint ? (
            <p className="mt-3 text-center text-sm text-rose-100/80">{inviteHint}</p>
          ) : null}
          <div className="mt-10 grid gap-6 md:grid-cols-2">
            <button
              type="button"
              onClick={() => onPickIdentity("nik")}
              className="card-3d group overflow-hidden rounded-[28px] bg-[#2a0b12] text-left transition hover:-translate-y-1"
            >
              <div className="relative h-56">
                <img
                  src="/images/pheras.png"
                  alt="Nikhil"
                  className="h-full w-full object-cover object-left"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#2a0b12] to-transparent" />
                <span className="absolute bottom-3 left-4 rounded-full bg-black/40 px-3 py-1 text-xs tracking-widest text-amber-100">
                  GROOM
                </span>
              </div>
              <div className="p-6">
                <p className="font-script text-4xl text-amber-200">Nik</p>
                <p className="font-serif text-2xl text-amber-50">Nikhil Mehra</p>
                <p className="mt-2 text-sm text-rose-100/70">
                  Main Nikhil hoon — meri shaadi wali duniya kholo
                </p>
              </div>
            </button>
            <button
              type="button"
              onClick={() => onPickIdentity("rumi")}
              className="card-3d group overflow-hidden rounded-[28px] bg-[#2a0b12] text-left transition hover:-translate-y-1"
            >
              <div className="relative h-56">
                <img
                  src="/images/varmala.png"
                  alt="Rashmika"
                  className="h-full w-full object-cover object-right"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#2a0b12] to-transparent" />
                <span className="absolute bottom-3 left-4 rounded-full bg-black/40 px-3 py-1 text-xs tracking-widest text-amber-100">
                  BRIDE
                </span>
              </div>
              <div className="p-6">
                <p className="font-script text-4xl text-amber-200">Rumi</p>
                <p className="font-serif text-2xl text-amber-50">Rashmika Mehra</p>
                <p className="mt-2 text-sm text-rose-100/70">
                  Main Rashmika hoon — meri shaadi wali duniya kholo
                </p>
              </div>
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="scene flex items-center justify-center bg-[radial-gradient(circle_at_center,#5a1020,transparent_50%),#120408] px-5">
      <Petals count={22} />
      <div
        className={`relative z-10 w-full max-w-md rounded-[32px] border border-amber-300/30 bg-[#2b0b12]/80 p-8 text-center backdrop-blur-md ${shake ? "lock-shake" : ""}`}
        style={{ animation: "glowpulse 3.2s ease-in-out infinite" }}
      >
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-amber-200/40 bg-gradient-to-b from-amber-200 to-amber-600 text-3xl shadow-[0_0_30px_rgba(224,184,76,0.45)]">
          🔒
        </div>
        <p className="font-script mt-5 text-4xl text-amber-100">Nik & Rumi</p>
        <h1 className="font-serif mt-1 text-3xl text-amber-50">Locked World</h1>
        <p className="mt-3 text-sm text-rose-100/75">
          Sirf hum dono ke liye. Woh special date set karo — 2026 ke ek May wale din.
        </p>
        <label className="mt-6 block text-left text-xs uppercase tracking-[0.2em] text-amber-200/70">
          Set the date (3 May 2026)
        </label>
        <input
          type="date"
          value={date}
          onChange={(e) => {
            setDate(e.target.value);
            if (error) setError("");
          }}
          className="mt-2 w-full rounded-2xl border border-amber-200/30 bg-black/30 px-4 py-3 text-amber-50 outline-none"
        />
        <input
          value={typed}
          onChange={(e) => {
            setTyped(e.target.value);
            if (error) setError("");
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              void submit(typed || date);
            }
          }}
          placeholder="ya type karo — e.g. 3 May 2026"
          className="mt-3 w-full rounded-2xl border border-amber-200/30 bg-black/30 px-4 py-3 text-amber-50 outline-none placeholder:text-rose-100/35"
        />
        <div className="mt-3 flex justify-center">
          <button
            type="button"
            onClick={() => {
              setDate("2026-05-03");
              setTyped("3 May 2026");
              void submit("2026-05-03");
            }}
            className="rounded-full border border-amber-300/40 bg-amber-500/10 px-3 py-1 text-xs text-amber-200 transition hover:bg-amber-500/25"
          >
            ✦ Quick set: 3 May 2026
          </button>
        </div>
        {error ? <p className="mt-3 text-sm text-rose-200">{error}</p> : null}
        <button
          type="button"
          disabled={busy}
          onClick={() => submit(typed || date)}
          className="gold-btn mt-6 w-full rounded-full py-3"
        >
          {busy ? "Checking…" : "Unlock our world"}
        </button>
      </div>
    </section>
  );
}
