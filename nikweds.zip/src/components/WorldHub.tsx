import { useEffect, useMemo, useRef, useState } from "react";
import {
  CHATS,
  FAMILIES,
  GALLERY,
  WEDDING_DATE_LABEL,
  displayName,
  type Identity,
} from "../lib/content";
import type { AppState, MemoryItem } from "../lib/types";
import Petals from "./Petals";

type Tab = "home" | "certificate" | "vows" | "memories";

function fileToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const s = reader.result as string;
      resolve(s.split(",")[1] ?? "");
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

async function compressImage(file: File): Promise<{ blob: Blob; type: string }> {
  if (file.size <= 2.5 * 1024 * 1024) {
    return { blob: file, type: file.type || "image/jpeg" };
  }
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const im = new Image();
      im.onload = () => resolve(im);
      im.onerror = reject;
      im.src = url;
    });
    const maxDim = 1600;
    let width = img.width;
    let height = img.height;
    const scale = Math.min(1, maxDim / Math.max(width, height));
    width = Math.round(width * scale);
    height = Math.round(height * scale);
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return { blob: file, type: file.type || "image/jpeg" };
    ctx.drawImage(img, 0, 0, width, height);
    const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/jpeg", 0.82));
    if (!blob) return { blob: file, type: file.type || "image/jpeg" };
    return { blob, type: "image/jpeg" };
  } catch {
    return { blob: file, type: file.type || "image/jpeg" };
  } finally {
    URL.revokeObjectURL(url);
  }
}

export default function WorldHub({
  state,
  onRefresh,
}: {
  state: AppState;
  onRefresh: (next?: AppState) => void;
}) {
  const identity = state.identity as Identity;
  const [tab, setTab] = useState<Tab>("home");
  const [albumId, setAlbumId] = useState<number | null>(state.tabs[0]?.id ?? null);
  const [newAlbum, setNewAlbum] = useState("");
  const [title, setTitle] = useState("");
  const [note, setNote] = useState("");
  const [locked, setLocked] = useState(false);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState("");
  const [recording, setRecording] = useState(false);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  const activeAlbum = albumId ?? state.tabs[0]?.id ?? null;

  useEffect(() => {
    if (albumId == null && state.tabs[0]) {
      setAlbumId(state.tabs[0].id);
    }
  }, [albumId, state.tabs]);

  const items = useMemo(
    () => state.memories.filter((m) => (activeAlbum ? m.tabId === activeAlbum : true)),
    [state.memories, activeAlbum],
  );

  async function postMemories(body: Record<string, unknown>) {
    const res = await fetch("/api/memories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...body, identity }),
    });
    const data = (await res.json()) as { ok?: boolean; state?: AppState; error?: string };
    if (data.state) {
      const merged: AppState = { ...data.state, unlocked: true, identity };
      onRefresh(merged);
    }
    return data;
  }

  async function uploadFile(file: File) {
    let blob: Blob = file;
    let contentType = file.type || "application/octet-stream";
    let name = file.name || "file";
    if (file.type.startsWith("image/")) {
      const c = await compressImage(file);
      blob = c.blob;
      contentType = c.type;
      if (contentType === "image/jpeg" && !/\.jpe?g$/i.test(name)) {
        name = name.replace(/\.[a-z0-9]+$/i, "") + ".jpg";
      }
    } else if (file.size > 3 * 1024 * 1024) {
      throw new Error("File bahut badi hai — max ~3MB (chhota clip bhejo)");
    }
    const dataBase64 = await fileToBase64(blob);
    const res = await fetch("/api/upload", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fileName: name, contentType, dataBase64, identity }),
    });
    const data = (await res.json()) as { ok?: boolean; path?: string; error?: string };
    if (!data.ok || !data.path) throw new Error(data.error || "upload failed");
    return data.path;
  }

  async function saveMemory(type: string, mediaPath: string | null, content = note) {
    if (!activeAlbum) {
      setToast("Pehle ek memory tab banao");
      setBusy(false);
      return;
    }
    setBusy(true);
    try {
      await postMemories({
        action: "memory",
        tabId: activeAlbum,
        type,
        title,
        content,
        mediaPath,
        locked,
        lockPassword: password,
      });
      setTitle("");
      setNote("");
      setLocked(false);
      setPassword("");
      setToast("Saved in our world 💗");
    } catch {
      setToast("Save nahi hua");
    }
    setBusy(false);
  }

  async function onPickFile(file: File | null) {
    if (!file) return;
    setBusy(true);
    try {
      const path = await uploadFile(file);
      const type = file.type.startsWith("video")
        ? "video"
        : file.type.startsWith("audio")
          ? "voice"
          : "photo";
      await saveMemory(type, path, note || file.name);
    } catch (e) {
      setToast(e instanceof Error ? e.message : "Upload fail");
      setBusy(false);
    }
  }

  async function startRec() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (e) => {
        if (e.data.size) chunksRef.current.push(e.data);
      };
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
        const file = new File([blob], `voice-${Date.now()}.webm`, { type: blob.type });
        await onPickFile(file);
      };
      recRef.current = rec;
      rec.start();
      setRecording(true);
    } catch {
      setToast("Mic allow karo");
    }
  }

  function stopRec() {
    if (recRef.current && recording) {
      recRef.current.stop();
      recRef.current = null;
      setRecording(false);
    }
  }

  async function copyShare(token: string) {
    const url = `${window.location.origin}/#/m/${token}`;
    await navigator.clipboard.writeText(url);
    setToast("Link copied");
  }

  return (
    <div className="scene overflow-y-auto bg-[radial-gradient(circle_at_top,#5a1020,transparent_42%),#120408] text-rose-50">
      <Petals count={10} />
      <header className="relative z-10 mx-auto flex max-w-6xl flex-col items-center gap-3 px-4 pb-4 pt-8">
        <p className="font-corm text-xs tracking-[0.5em] text-amber-200/80 uppercase">
          {WEDDING_DATE_LABEL}
        </p>
        <h1 className="font-script text-5xl text-amber-100 sm:text-6xl">Nik & Rumi World</h1>
        <p className="font-serif text-lg text-rose-100/80">
          {displayName(identity)} · signed in
        </p>
        <nav className="mt-2 flex flex-wrap justify-center gap-2">
          {(
            [
              ["home", "Home"],
              ["certificate", "Certificate"],
              ["vows", "Vachan"],
              ["memories", "Memories"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`rounded-full px-4 py-2 text-sm ${
                tab === id ? "gold-btn" : "maroon-btn"
              }`}
            >
              {label}
            </button>
          ))}
          <button
            type="button"
            className="rounded-full border border-amber-200/30 px-4 py-2 text-sm"
            onClick={async () => {
              await postMemories({ action: "ping", content: "💗 ping" });
              setToast("Ping bhej diya");
            }}
          >
            Ping 💗
          </button>
        </nav>
        {toast ? <p className="text-xs text-amber-200">{toast}</p> : null}
      </header>

      <main className="relative z-10 mx-auto max-w-6xl px-4 pb-24">
        {tab === "home" ? <HomeGallery /> : null}
        {tab === "certificate" ? <Certificate /> : null}
        {tab === "vows" ? <VowsWall /> : null}
        {tab === "memories" ? (
          <section>
            <div className="flex flex-wrap items-center gap-2">
              {state.tabs.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setAlbumId(t.id)}
                  className={`rounded-full px-4 py-2 text-sm ${
                    activeAlbum === t.id ? "gold-btn" : "maroon-btn"
                  }`}
                >
                  {t.name}
                </button>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <input
                value={newAlbum}
                onChange={(e) => setNewAlbum(e.target.value)}
                placeholder="New memory tab name"
                className="min-w-[200px] flex-1 rounded-full border border-amber-200/20 bg-black/30 px-4 py-2 text-sm outline-none"
              />
              <button
                type="button"
                className="gold-btn rounded-full px-4 py-2 text-sm"
                onClick={async () => {
                  if (!newAlbum.trim()) return;
                  const data = await postMemories({ action: "tab", name: newAlbum.trim() });
                  setNewAlbum("");
                  const last = data.state?.tabs.at(-1);
                  if (last) setAlbumId(last.id);
                }}
              >
                Create tab
              </button>
            </div>

            <div className="card-3d mt-6 rounded-[28px] bg-[#2b0b12]/85 p-5">
              <p className="font-serif text-xl text-amber-100">Instant memory</p>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Title"
                className="mt-3 w-full rounded-2xl border border-amber-200/20 bg-black/30 px-4 py-2 text-sm outline-none"
              />
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Note, caption, ya kuch bhi…"
                rows={3}
                className="mt-3 w-full rounded-2xl border border-amber-200/20 bg-black/30 px-4 py-2 text-sm outline-none"
              />
              <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={locked}
                    onChange={(e) => setLocked(e.target.checked)}
                  />
                  Lock + shareable link
                </label>
                {locked ? (
                  <input
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="lock password"
                    className="rounded-full border border-amber-200/20 bg-black/30 px-3 py-1 outline-none"
                  />
                ) : null}
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => saveMemory("note", null)}
                  className="gold-btn rounded-full px-4 py-2 text-sm"
                >
                  Save note
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => fileRef.current?.click()}
                  className="maroon-btn rounded-full px-4 py-2 text-sm"
                >
                  Photo / video
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onPointerDown={startRec}
                  onPointerUp={stopRec}
                  onPointerLeave={stopRec}
                  className={`rounded-full px-4 py-2 text-sm ${recording ? "gold-btn" : "maroon-btn"}`}
                >
                  {recording ? "Recording… release" : "Hold mic 🎤"}
                </button>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*,video/*"
                  className="hidden"
                  onChange={(e) => onPickFile(e.target.files?.[0] ?? null)}
                />
              </div>
            </div>

            <div className="mt-6 grid gap-4 md:grid-cols-2">
              {items.map((m) => (
                <MemoryCard key={m.id} item={m} onShare={() => copyShare(m.shareToken)} />
              ))}
              {items.length === 0 ? (
                <p className="text-sm text-rose-100/60">Is tab mein abhi kuch nahi… pehli memory daalo.</p>
              ) : null}
            </div>
          </section>
        ) : null}
      </main>
    </div>
  );
}

function HomeGallery() {
  return (
    <section>
      <div className="grid gap-5 md:grid-cols-2">
        {GALLERY.map((g) => (
          <figure
            key={g.src}
            className="card-3d overflow-hidden rounded-[28px] bg-[#2b0b12]"
          >
            <div className="relative">
              <img src={g.src} alt={g.title} className="h-80 w-full object-cover" />
              <span className="absolute bottom-3 left-3 rounded-full bg-black/55 px-3 py-1 font-script text-2xl text-amber-200">
                Nikhil
              </span>
              <span className="absolute bottom-3 right-3 rounded-full bg-black/55 px-3 py-1 font-script text-2xl text-amber-200">
                Rashmika
              </span>
            </div>
            <figcaption className="p-4">
              <p className="font-serif text-xl text-amber-100">{g.title}</p>
              <p className="text-sm text-rose-100/70">{g.caption}</p>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}

function Certificate() {
  return (
    <section className="mx-auto max-w-3xl">
      <article className="ornament-border paper relative rounded-[8px] px-8 py-10 text-[#4a1a16] sm:px-12">
        <p className="text-center text-xs tracking-[0.5em] uppercase">Republic of Love</p>
        <h2 className="font-script mt-2 text-center text-5xl text-[#7a1830] sm:text-6xl">
          Marriage Certificate
        </h2>
        <p className="font-corm mt-2 text-center text-lg">
          This is to certify that on {WEDDING_DATE_LABEL}
        </p>
        <div className="mt-8 grid gap-6 sm:grid-cols-2">
          <div className="rounded-2xl border border-[#e0b84c]/40 bg-[#fffdfa]/70 p-5">
            <p className="text-xs tracking-[0.3em] uppercase text-[#7a1830] font-semibold">वर (Groom)</p>
            <p className="font-serif text-2xl text-[#3a0710] font-bold">Nikhil Mehra</p>
            <div className="mt-3 space-y-1 text-sm text-[#4a1a16]">
              <p><b>पिता:</b> {FAMILIES.grooms.father}</p>
              <p><b>माता:</b> {FAMILIES.grooms.mother}</p>
            </div>
          </div>
          <div className="rounded-2xl border border-[#e0b84c]/40 bg-[#fffdfa]/70 p-5">
            <p className="text-xs tracking-[0.3em] uppercase text-[#7a1830] font-semibold">वधू (Bride)</p>
            <p className="font-serif text-2xl text-[#3a0710] font-bold">Rashmika Mehra</p>
            <p className="text-xs text-[#7a1830] font-medium mt-0.5">
              Rashmika Rana (Rumi) — Now converted into Mehra
            </p>
            <div className="mt-3 space-y-1 text-sm text-[#4a1a16]">
              <p><b>पिता:</b> {FAMILIES.brides.father}</p>
              <p><b>माता:</b> {FAMILIES.brides.mother}</p>
            </div>
          </div>
        </div>
        <p className="font-corm mt-8 text-center text-lg leading-relaxed font-semibold text-[#4a1a16]">
          Hum dono — <b>Nikhil Mehra</b> aur <b>Rashmika Mehra</b> — ne 13 September 2026 ko ek dusre ke sath
          pavitra vachan lekar, anguthi pehna kar, hamesha ke liye ek dusre ko apna jeevansathi sweekar kiya.
          Rashmika abse poore samman ke sath <b>Rashmika Mehra</b> hain.
        </p>
        <div className="mt-10 flex flex-wrap justify-between gap-6">
          <div className="text-center">
            <p className="font-script text-4xl">Nikhil Mehra</p>
            <p className="text-xs tracking-[0.3em] uppercase">Groom</p>
          </div>
          <div className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-[#c9a227] font-script text-2xl text-[#7a1830]">
            N ♥ R
          </div>
          <div className="text-center">
            <p className="font-script text-4xl">Rashmika Mehra</p>
            <p className="text-xs tracking-[0.3em] uppercase">Bride</p>
          </div>
        </div>
      </article>
    </section>
  );
}

function VowsWall() {
  return (
    <section className="mx-auto max-w-2xl space-y-4">
      {CHATS.map((chat) => (
        <article
          key={chat.id}
          className={`chat-in rounded-3xl border border-amber-200/20 p-4 ${
            chat.identity === "nik" ? "ml-6 bg-[#3a1a10]/80" : "mr-6 bg-[#4a1020]/80"
          }`}
        >
          <div className="flex items-baseline justify-between gap-3">
            <p className="font-script text-2xl text-amber-200">{chat.sender}</p>
            <p className="text-[11px] text-rose-100/60">{chat.time}</p>
          </div>
          <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed">{chat.text}</p>
        </article>
      ))}
    </section>
  );
}

function MemoryCard({ item, onShare }: { item: MemoryItem; onShare: () => void }) {
  return (
    <article className="rounded-3xl border border-amber-200/15 bg-[#2b0b12]/80 p-4">
      <div className="flex items-center justify-between gap-2 text-xs text-amber-200/80">
        <span>{item.author === "nik" ? "Nikhil" : "Rashmika"} · {item.type}</span>
        <span>{new Date(item.createdAt).toLocaleString()}</span>
      </div>
      {item.title ? <p className="font-serif mt-2 text-lg text-amber-100">{item.title}</p> : null}
      {item.content ? <p className="mt-2 text-sm leading-relaxed">{item.content}</p> : null}
      {item.mediaPath && item.type === "photo" ? (
        <img src={item.mediaPath} alt="" className="mt-3 max-h-72 w-full rounded-2xl object-cover" />
      ) : null}
      {item.mediaPath && item.type === "video" ? (
        <video src={item.mediaPath} controls className="mt-3 w-full rounded-2xl" />
      ) : null}
      {item.mediaPath && item.type === "voice" ? (
        <audio src={item.mediaPath} controls className="mt-3 w-full" />
      ) : null}
      <div className="mt-3 flex items-center justify-between text-xs">
        <span>{item.locked ? "🔒 locked share" : "open in our world"}</span>
        <button type="button" onClick={onShare} className="underline decoration-amber-300">
          Copy link
        </button>
      </div>
    </article>
  );
}
