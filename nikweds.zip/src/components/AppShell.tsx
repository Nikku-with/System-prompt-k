import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import type { Identity } from "../lib/content";
import type { AppState } from "../lib/types";
import LockFlow from "./LockFlow";
import Rituals from "./Rituals";
import WorldHub from "./WorldHub";

function Boot() {
  return (
    <div className="scene grid place-items-center bg-[#14060a] text-amber-100">
      <p className="font-script text-5xl" style={{ animation: "heartbeat 1.4s infinite" }}>
        N ♥ R
      </p>
    </div>
  );
}

export default function AppShell() {
  const [params] = useSearchParams();
  const inviteToken = params.get("invite");
  const [state, setState] = useState<AppState | null>(null);
  const [welcomeSeen, setWelcomeSeen] = useState(true);
  const [celebSeen, setCelebSeen] = useState(true);
  const [ready, setReady] = useState(false);
  const [ping, setPing] = useState<string | null>(null);
  const seenPing = useRef<number>(0);
  const identityRef = useRef<Identity | null>(null);

  const load = useCallback(async () => {
    const res = await fetch("/api/state", { cache: "no-store" });
    const data = (await res.json()) as AppState;
    const isLocalUnlocked = typeof window !== "undefined" && localStorage.getItem("nr_unlocked_local") === "1";
    const finalUnlocked = Boolean(data.unlocked || isLocalUnlocked);
    const localId = typeof window !== "undefined" ? localStorage.getItem("nr_identity_local") : null;
    const finalIdentity = data.identity || (localId === "nik" || localId === "rumi" ? localId : null);

    const mergedData: AppState = {
      ...data,
      unlocked: finalUnlocked,
      identity: finalIdentity,
    };
    identityRef.current = finalIdentity;
    setState(mergedData);
    return mergedData;
  }, []);

  useEffect(() => {
    const welcomeDone = localStorage.getItem("nr_welcome_seen") === "1";
    const celebDone = localStorage.getItem("nr_celeb_seen") === "1";
    setWelcomeSeen(welcomeDone);
    setCelebSeen(celebDone);

    load().finally(() => setReady(true));
  }, [load]);

  useEffect(() => {
    if (!state?.unlocked) return;
    const t = setInterval(() => {
      void load();
    }, 1600);
    return () => clearInterval(t);
  }, [state?.unlocked, load]);

  useEffect(() => {
    if (!state?.identity) return;
    const myIdentity = state.identity;
    const newest = state.pings.find((p) => p.fromWho !== myIdentity && !p.seen);
    if (newest && newest.id !== seenPing.current) {
      seenPing.current = newest.id;
      setPing(
        `${newest.fromWho === "nik" ? "Nikhil" : "Rashmika"} pinged you 💗 ${newest.message ?? ""}`,
      );
      void fetch("/api/memories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "seenPings", identity: myIdentity }),
      });
      setTimeout(() => setPing(null), 4200);
    }
  }, [state]);

  async function unlock(date: string) {
    try {
      const res = await fetch("/api/unlock", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date }),
      });
      if (!res.ok) return false;
      localStorage.setItem("nr_unlocked_local", "1");
      if (localStorage.getItem("nr_welcome_seen") !== "1") {
        setWelcomeSeen(false);
      }
      setState((prev) => (prev ? { ...prev, unlocked: true } : prev));
      await load();
      return true;
    } catch {
      return false;
    }
  }

  async function pickIdentity(id: Identity) {
    localStorage.setItem("nr_identity_local", id);
    identityRef.current = id;
    setState((prev) => (prev ? { ...prev, identity: id } : prev));
    await fetch("/api/identity", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ identity: id }),
    });
    await load();
  }

  const onAct = useCallback(async (body: Record<string, unknown>) => {
    const res = await fetch("/api/ceremony", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...body, identity: identityRef.current }),
    });
    const data = (await res.json()) as { ok?: boolean; error?: string; state?: AppState };
    if (data.state) {
      const fresh = data.state;
      setState((prev) =>
        prev
          ? {
              ...fresh,
              unlocked: fresh.unlocked || prev.unlocked,
              identity: fresh.identity || prev.identity,
            }
          : fresh,
      );
    }
    if (!data.ok) return data.error || "Could not save";
    return null;
  }, []);

  if (!ready || !state) return <Boot />;

  if (!state.unlocked) {
    return (
      <LockFlow
        stage="lock"
        onUnlock={unlock}
        onWelcomeDone={() => undefined}
        onPickIdentity={async () => undefined}
      />
    );
  }

  if (!welcomeSeen) {
    return (
      <LockFlow
        stage="welcome"
        onUnlock={async () => true}
        onWelcomeDone={() => {
          localStorage.setItem("nr_welcome_seen", "1");
          setWelcomeSeen(true);
        }}
        onPickIdentity={async () => undefined}
      />
    );
  }

  if (!state.identity) {
    let hint: string | null = null;
    if (inviteToken && inviteToken === state.ceremony.nikInviteToken) {
      hint = "Ye link Rashmika / Rumi ke accept ke liye hai.";
    } else if (inviteToken && inviteToken === state.ceremony.rumiInviteToken) {
      hint = "Ye link Nikhil / Nik ke accept ke liye hai.";
    }
    return (
      <LockFlow
        stage="identity"
        onUnlock={async () => true}
        onWelcomeDone={() => undefined}
        onPickIdentity={pickIdentity}
        inviteHint={hint}
      />
    );
  }

  const showWorld = state.ceremony.phase === "complete" && celebSeen;

  return (
    <>
      {ping ? (
        <div className="fixed left-1/2 top-6 z-[80] -translate-x-1/2 rounded-full bg-[#7a1830] px-5 py-2 text-sm text-amber-100 shadow-xl">
          {ping}
        </div>
      ) : null}
      {showWorld ? (
        <WorldHub state={state} onRefresh={(next) => (next ? setState(next) : void load())} />
      ) : (
        <Rituals
          state={state}
          inviteToken={inviteToken}
          onAct={onAct}
          onCelebrationDone={() => {
            localStorage.setItem("nr_celeb_seen", "1");
            setCelebSeen(true);
          }}
        />
      )}
    </>
  );
}
