import supabase from './db-client.js';
import { setCors, ensureCeremony, buildState } from './_helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const body = req.body || {};
    const identity = body.identity;
    if (identity !== 'nik' && identity !== 'rumi') {
      return res.status(401).json({ ok: false, error: 'identity required' });
    }
    await ensureCeremony();

    if (body.action === 'tab') {
      const name = String(body.name ?? '').trim();
      if (!name) {
        return res.status(400).json({ ok: false, error: 'Name required' });
      }
      const { error } = await supabase.from('memory_tabs').insert({
        name,
        created_by: identity,
        share_token: crypto.randomUUID(),
      });
      if (error) throw error;
    } else if (body.action === 'memory') {
      const tabId = body.tabId;
      const type = body.type ?? 'note';
      if (!tabId) {
        return res.status(400).json({ ok: false, error: 'Tab required' });
      }
      const locked = Boolean(body.locked);
      const { error } = await supabase.from('memories').insert({
        tab_id: tabId,
        author: identity,
        type,
        title: String(body.title ?? '').trim() || null,
        content: String(body.content ?? '').trim() || null,
        media_path: body.mediaPath ?? null,
        locked,
        lock_password: locked ? (body.lockPassword || null) : null,
        share_token: crypto.randomUUID(),
      });
      if (error) throw error;
    } else if (body.action === 'ping') {
      const { error } = await supabase.from('pings').insert({
        from_who: identity,
        message: String(body.content ?? '').trim() || 'thinking of you',
      });
      if (error) throw error;
    } else if (body.action === 'seenPings') {
      const { error } = await supabase.from('pings').update({ seen: true }).neq('from_who', identity).eq('seen', false);
      if (error) throw error;
    } else {
      return res.status(400).json({ ok: false, error: 'Unknown action' });
    }

    const state = await buildState(identity);
    return res.status(200).json({ ok: true, state });
  } catch (err) {
    console.error('memories error:', err);
    return res.status(500).json({ ok: false, error: 'memories failed' });
  }
}
