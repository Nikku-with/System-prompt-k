import supabase from '../db-client.js';
import { setCors } from '../_helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const token = req.query.token;
    const password = req.query.password ?? '';
    const { data: rows, error } = await supabase.from('memories').select('*').eq('share_token', token);
    if (error) throw error;
    const memory = rows[0];
    if (!memory) {
      return res.status(404).json({ ok: false, error: 'Not found' });
    }
    if (memory.locked && password !== (memory.lock_password ?? '')) {
      return res.status(200).json({ ok: true, locked: true, needsPassword: true });
    }
    return res.status(200).json({
      ok: true,
      locked: false,
      memory: {
        id: memory.id,
        author: memory.author,
        type: memory.type,
        title: memory.title,
        content: memory.content,
        mediaPath: memory.media_path,
        createdAt: new Date(memory.created_at).toISOString(),
      },
    });
  } catch (err) {
    console.error('share error:', err);
    return res.status(500).json({ ok: false, error: 'share failed' });
  }
}
