import { setCors } from './_helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { identity } = req.body || {};
    if (identity !== 'nik' && identity !== 'rumi') {
      return res.status(400).json({ ok: false, error: 'bad identity' });
    }
    res.setHeader('Set-Cookie', `nr_identity=${identity}; Path=/; Max-Age=31536000; SameSite=Lax`);
    return res.status(200).json({ ok: true, identity });
  } catch (err) {
    console.error('identity error:', err);
    return res.status(500).json({ ok: false, error: 'identity failed' });
  }
}
