import supabase from './db-client.js';
import { setCors } from './_helpers.js';

const MAX_BYTES = Math.floor(4.2 * 1024 * 1024);

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { fileName, contentType, dataBase64, identity } = req.body || {};
    if (identity !== 'nik' && identity !== 'rumi') {
      return res.status(401).json({ ok: false, error: 'identity required' });
    }
    const type = contentType || 'application/octet-stream';
    if (!(type.startsWith('image/') || type.startsWith('video/') || type.startsWith('audio/'))) {
      return res.status(400).json({ ok: false, error: 'Type not allowed' });
    }
    if (!dataBase64) {
      return res.status(400).json({ ok: false, error: 'No file' });
    }
    const buf = Buffer.from(dataBase64, 'base64');
    if (buf.length > MAX_BYTES) {
      return res.status(400).json({ ok: false, error: 'File too large (max ~4MB)' });
    }
    const rawName = String(fileName || 'file');
    const m = rawName.toLowerCase().match(/\.([a-z0-9]+)$/);
    const fallback = (String(type).split('/')[1] || 'bin').split(';')[0];
    const ext = m ? m[1] : fallback;
    const path = `${crypto.randomUUID()}.${ext}`;

    const { error } = await supabase.storage.from('memories').upload(path, buf, { contentType: type, upsert: true });
    if (error) throw error;

    const { data } = supabase.storage.from('memories').getPublicUrl(path);
    return res.status(200).json({ ok: true, path: data.publicUrl });
  } catch (err) {
    console.error('upload error:', err);
    return res.status(500).json({ ok: false, error: 'upload failed' });
  }
}
