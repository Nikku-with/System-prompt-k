import { setCors, ensureCeremony, buildState } from './_helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    await ensureCeremony();
    const state = await buildState();
    return res.status(200).json(state);
  } catch (err) {
    console.error('state error:', err);
    return res.status(500).json({ ok: false, error: 'state failed' });
  }
}
