import supabase from './db-client.js';
import { setCors, ensureCeremony, syncCeremonyPhase, buildState, VOW_AUTHORS } from './_helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { action, token, vowKey, accepted, identity } = req.body || {};
    if (identity !== 'nik' && identity !== 'rumi') {
      return res.status(401).json({ ok: false, error: 'identity required' });
    }

    const row = await ensureCeremony();

    if (action === 'accept') {
      const t = token ?? '';
      if (t === row.nik_invite_token && identity === 'rumi') {
        const { error } = await supabase.from('ceremony').update({ nik_accepted: true, updated_at: new Date().toISOString() }).eq('id', row.id);
        if (error) throw error;
      } else if (t === row.rumi_invite_token && identity === 'nik') {
        const { error } = await supabase.from('ceremony').update({ rumi_accepted: true, updated_at: new Date().toISOString() }).eq('id', row.id);
        if (error) throw error;
      } else {
        return res.status(400).json({ ok: false, error: 'This link is for your partner.' });
      }
    } else if (action === 'vow') {
      const author = VOW_AUTHORS[vowKey];
      if (!author) {
        return res.status(400).json({ ok: false, error: 'Unknown vow' });
      }
      if (author === identity) {
        return res.status(400).json({ ok: false, error: 'Partner answers your vachan.' });
      }
      if (accepted !== true) {
        return res.status(200).json({ ok: false, error: 'Soch lo phir se… haa bolna hai 💗' });
      }
      const { data: existing, error: e1 } = await supabase.from('vow_responses').select('*').eq('vow_key', vowKey);
      if (e1) throw e1;
      if (existing && existing[0]) {
        const { error: e2 } = await supabase.from('vow_responses').update({ accepted: true, responder: identity }).eq('id', existing[0].id);
        if (e2) throw e2;
      } else {
        const { error: e2 } = await supabase.from('vow_responses').insert({ vow_key: vowKey, responder: identity, accepted: true });
        if (e2) throw e2;
      }
    } else if (action === 'ring') {
      const patch = identity === 'nik' ? { nik_ring_done: true } : { rumi_ring_done: true };
      patch.updated_at = new Date().toISOString();
      const { error } = await supabase.from('ceremony').update(patch).eq('id', row.id);
      if (error) throw error;
    } else {
      return res.status(400).json({ ok: false, error: 'Unknown action' });
    }

    await syncCeremonyPhase();
    const state = await buildState(identity);
    return res.status(200).json({ ok: true, state });
  } catch (err) {
    console.error('ceremony error:', err);
    return res.status(500).json({ ok: false, error: 'ceremony failed' });
  }
}
