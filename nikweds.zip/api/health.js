import supabase from './db-client.js';
import { setCors } from './_helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { error } = await supabase.from('ceremony').select('id').limit(1);
    if (error) throw error;
    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('health error:', err);
    return res.status(500).json({ ok: false });
  }
}
