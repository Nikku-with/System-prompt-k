import supabase from './db-client.js';

export const VOW_KEYS = [
  'rumi-1', 'rumi-2', 'rumi-3', 'rumi-4',
  'nik-1', 'nik-2', 'nik-3', 'nik-4',
];

export const VOW_AUTHORS = {
  'rumi-1': 'rumi', 'rumi-2': 'rumi', 'rumi-3': 'rumi', 'rumi-4': 'rumi',
  'nik-1': 'nik', 'nik-2': 'nik', 'nik-3': 'nik', 'nik-4': 'nik',
};

export function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

export async function ensureCeremony() {
  const { data: existing, error } = await supabase.from('ceremony').select('*').limit(1);
  if (error) throw error;
  let row = existing[0];
  if (!row) {
    const { data: inserted, error: e2 } = await supabase
      .from('ceremony')
      .insert({
        nik_accepted: false,
        rumi_accepted: false,
        nik_invite_token: crypto.randomUUID(),
        rumi_invite_token: crypto.randomUUID(),
        phase: 'invite',
        nik_ring_done: false,
        rumi_ring_done: false,
      })
      .select()
      .single();
    if (e2) throw e2;
    row = inserted;
  }
  const { data: tabs, error: e3 } = await supabase.from('memory_tabs').select('*').limit(1);
  if (e3) throw e3;
  if (!tabs[0]) {
    const { error: e4 } = await supabase.from('memory_tabs').insert({
      name: 'Shaadi Night · 13 Sep 2026',
      created_by: 'nik',
      share_token: crypto.randomUUID(),
    });
    if (e4) throw e4;
  }
  return row;
}

export async function syncCeremonyPhase() {
  const row = await ensureCeremony();
  if (row.phase === 'complete') return row;

  const { data: responses, error } = await supabase.from('vow_responses').select('*');
  if (error) throw error;
  const accepted = new Set((responses || []).filter((r) => r.accepted).map((r) => r.vow_key));
  const allVowsYes = VOW_KEYS.every((k) => accepted.has(k));

  let phase = row.phase;
  let completedAt = row.completed_at;

  if (row.nik_accepted && row.rumi_accepted && phase === 'invite') {
    phase = 'vows';
  }
  if (allVowsYes && row.nik_accepted && row.rumi_accepted && (phase === 'vows' || phase === 'invite')) {
    phase = 'ring';
  }
  if (row.nik_ring_done && row.rumi_ring_done && (phase === 'ring' || phase === 'vows')) {
    phase = 'complete';
    completedAt = completedAt ?? new Date().toISOString();
  }

  if (phase !== row.phase || completedAt !== row.completed_at) {
    const { error: e2 } = await supabase
      .from('ceremony')
      .update({ phase, completed_at: completedAt, updated_at: new Date().toISOString() })
      .eq('id', row.id);
    if (e2) throw e2;
    return { ...row, phase, completed_at: completedAt };
  }
  return row;
}

export async function buildState(identity = null) {
  const row = await syncCeremonyPhase();

  const { data: responses, error: e1 } = await supabase.from('vow_responses').select('*');
  if (e1) throw e1;
  const { data: tabs, error: e2 } = await supabase.from('memory_tabs').select('*').order('id', { ascending: true });
  if (e2) throw e2;
  const { data: mems, error: e3 } = await supabase.from('memories').select('*').order('id', { ascending: false });
  if (e3) throw e3;
  const { data: pingRows, error: e4 } = await supabase.from('pings').select('*').order('id', { ascending: false }).limit(30);
  if (e4) throw e4;

  const vowMap = {};
  for (const r of (responses || [])) {
    vowMap[r.vow_key] = r.accepted;
  }

  return {
    unlocked: false,
    identity,
    ceremony: {
      phase: row.phase,
      nikAccepted: !!row.nik_accepted,
      rumiAccepted: !!row.rumi_accepted,
      nikInviteToken: row.nik_invite_token,
      rumiInviteToken: row.rumi_invite_token,
      nikRingDone: !!row.nik_ring_done,
      rumiRingDone: !!row.rumi_ring_done,
      completedAt: row.completed_at ? new Date(row.completed_at).toISOString() : null,
    },
    vowResponses: vowMap,
    tabs: (tabs || []).map((t) => ({
      id: t.id,
      name: t.name,
      createdBy: t.created_by,
      shareToken: t.share_token,
      createdAt: new Date(t.created_at).toISOString(),
    })),
    memories: (mems || []).map((m) => ({
      id: m.id,
      tabId: m.tab_id,
      author: m.author,
      type: m.type,
      title: m.title,
      content: m.content,
      mediaPath: m.media_path,
      locked: !!m.locked,
      shareToken: m.share_token,
      createdAt: new Date(m.created_at).toISOString(),
    })),
    pings: (pingRows || []).map((p) => ({
      id: p.id,
      fromWho: p.from_who,
      message: p.message,
      seen: !!p.seen,
      createdAt: new Date(p.created_at).toISOString(),
    })),
  };
}
