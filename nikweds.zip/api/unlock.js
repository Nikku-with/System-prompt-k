import { setCors } from './_helpers.js';

function isUnlockDate(raw) {
  if (!raw) return false;
  const s = String(raw)
    .trim()
    .toLowerCase()
    .replace(/,/g, ' ')
    .replace(/[.]/g, '-')
    .replace(/\//g, '-')
    .replace(/\s+/g, ' ');

  const allowed = [
    '2026-05-03', '2026-5-3', '2026-5-03', '2026-05-3',
    '3 may 2026', '03 may 2026', 'may 3 2026', 'may 03 2026',
    'may 3rd 2026', '3rd may 2026',
    '3-5-2026', '03-05-2026', '3-05-2026', '03-5-2026',
    '5-3-2026', '05-03-2026', '05-3-2026', '5-03-2026',
    '03-may-2026', '3-may-2026',
    '3 may', '03 may', '3rd may',
  ];
  if (allowed.includes(s)) return true;

  const has3 = /\b0?3(rd)?\b/.test(s);
  const hasMay = /\b(may|mai)\b/.test(s) || /[-/]0?5[-/]/.test(s) || /2026-0?5/.test(s);
  const has2026 = /\b2026\b/.test(s) || /\b26\b/.test(s);
  if (has3 && hasMay && has2026) return true;
  if (/^2026[-/]0?5[-/]0?3$/.test(s)) return true;
  if (/^0?3[-/]0?5[-/]2026$/.test(s)) return true;
  if (/^0?5[-/]0?3[-/]2026$/.test(s)) return true;
  return false;
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { date } = req.body || {};
    if (!isUnlockDate(date ?? '')) {
      return res.status(401).json({ ok: false, error: 'wrong-date' });
    }
    res.setHeader('Set-Cookie', 'nr_unlocked=1; Path=/; Max-Age=31536000; SameSite=Lax');
    return res.status(200).json({ ok: true, unlocked: true });
  } catch (err) {
    console.error('unlock error:', err);
    return res.status(500).json({ ok: false, error: 'unlock failed' });
  }
}
