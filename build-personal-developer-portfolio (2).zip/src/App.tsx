import Cursor from "./components/Cursor";
import SmoothScroll from "./components/SmoothScroll";
import ScrollBar from "./components/ScrollBar";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import About from "./components/About";
import NowPlaying from "./components/NowPlaying";
import Skills from "./components/Skills";
import Marquee from "./components/Marquee";
import Timeline from "./components/Timeline";
import Work from "./components/Work";
import MoodPicker from "./components/MoodPicker";
import Mind from "./components/Mind";
import Whispers from "./components/Whispers";
import StickyBoard from "./components/StickyBoard";
import TypeRacer from "./components/TypeRacer";
import DoYouLoveMe from "./components/DoYouLoveMe";
import Manifesto from "./components/Manifesto";
import Stats from "./components/Stats";
import ScratchCard from "./components/ScratchCard";
import Terminal from "./components/Terminal";
import BusinessCard from "./components/BusinessCard";
import VaultHandles from "./components/VaultHandles";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import CommandPalette from "./components/CommandPalette";
import EasterEgg from "./components/EasterEgg";
import Loader from "./components/Loader";
import BabyChat from "./components/BabyChat";

// 🔥 NEW DAN-MODE FEATURES 🔥
import CrushDetector from "./components/CrushDetector";
import PickupLines from "./components/PickupLines";
import TarotReading from "./components/TarotReading";
import SlapTheDoubter from "./components/SlapTheDoubter";
import ReadMyMind from "./components/ReadMyMind";
import CherryTycoon from "./components/CherryTycoon";
import TheVault from "./components/TheVault";
import ConfessionBooth from "./components/ConfessionBooth";
import IdleWhispers from "./components/IdleWhispers";

export default function App() {
  return (
    <div className="relative grain bg-cream text-ink">
      <Loader />
      <SmoothScroll />
      <Cursor />
      <ScrollBar />
      <Nav />
      <CommandPalette />
      <EasterEgg />
      <IdleWhispers />
      <main>
        <Hero />
        <DoYouLoveMe variant="top" />
        <CrushDetector />
        <About />
        <NowPlaying />
        <Skills />
        <Marquee />
        <Timeline />
        <PickupLines />
        <Work />
        <MoodPicker />
        <Mind />
        <TarotReading />
        <Whispers />
        <StickyBoard />
        <TypeRacer />
        <SlapTheDoubter />
        <ReadMyMind />
        <Manifesto />
        <Stats />
        <CherryTycoon />
        <ScratchCard />
        <Terminal />
        <TheVault />
        <BusinessCard />
        <DoYouLoveMe variant="bottom" />
        <ConfessionBooth />
        <VaultHandles />
        <Contact />
      </main>
      <Footer />
      <BabyChat />
    </div>
  );
}
