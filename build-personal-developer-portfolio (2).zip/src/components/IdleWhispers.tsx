import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useRef, useState } from "react";

const whispers = [
  "missing me already? 🥺",
  "kya dekh raha hai cutie 👀",
  "scroll kar na, mai yahi hu 🩷",
  "tap kuch karle 💋",
  "bored? mai bhi 😏",
  "mujhe ignore mat kar yaar 🙄",
  "oye! kahan kho gaya 🌚",
  "DM karle, mai padh lunga 💌",
  "you're cute when you're idle 😌",
  "psst... niche aur cool stuff hai 👇",
];

export default function IdleWhispers() {
  const [show, setShow] = useState(false);
  const [text, setText] = useState(whispers[0]);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const idleT = useRef<number | null>(null);
  const lastPos = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const reset = () => {
      setShow(false);
      if (idleT.current) clearTimeout(idleT.current);
      idleT.current = window.setTimeout(() => {
        setText(whispers[Math.floor(Math.random() * whispers.length)]);
        setPos({ x: lastPos.current.x, y: lastPos.current.y });
        setShow(true);
      }, 9000); // 9s idle
    };
    const move = (e: MouseEvent) => {
      lastPos.current = { x: e.clientX, y: e.clientY };
      reset();
    };
    const click = () => reset();
    const scroll = () => reset();

    window.addEventListener("mousemove", move);
    window.addEventListener("click", click);
    window.addEventListener("scroll", scroll, { passive: true });
    reset();
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("click", click);
      window.removeEventListener("scroll", scroll);
      if (idleT.current) clearTimeout(idleT.current);
    };
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, scale: 0.7, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.7 }}
          transition={{ type: "spring", stiffness: 220, damping: 16 }}
          style={{
            left: Math.min(pos.x + 18, window.innerWidth - 240),
            top: Math.min(pos.y + 18, window.innerHeight - 80),
          }}
          className="fixed pointer-events-none z-[75]"
        >
          <div className="relative bg-cherry text-cream px-4 py-2.5 rounded-2xl rounded-tl-sm border-2 border-ink font-display text-base shadow-[3px_3px_0_#0a0a0a] max-w-[220px]">
            {text}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
