import { motion } from "framer-motion";
import Reveal from "./Reveal";

const quotes = [
  {
    big: "If you wanna be my friend — I'm the best friend you've ever seen. If you wanna be my enemy — I'm good at that too.",
    small: "rule #01",
    style: "bg-cream",
    fg: "#0a0a0a",
    emojis: ["🤝", "⚔️", "🩷"],
    tape: "rgba(210,54,82,.35)",
  },
  {
    big: "Don't be average when you have potential to become the best in your bloodline.",
    small: "rule #02",
    style: "bg-cherry",
    fg: "#fff5f0",
    emojis: ["🔥", "👑", "⚡"],
    tape: "rgba(255,243,160,.55)",
  },
  {
    big: "Don't focus on girls at a young age. They're a distraction with a soft voice.",
    small: "rule #03",
    style: "bg-lemon",
    fg: "#0a0a0a",
    emojis: ["🚫", "🎯", "🧠"],
    tape: "rgba(0,0,0,.2)",
  },
  {
    big: "I want to become a mystery for everyone who meets me — and force them to wonder who's behind that face.",
    small: "rule #04",
    style: "bg-pinkish",
    fg: "#0a0a0a",
    emojis: ["🕵️", "🌫️", "🎭"],
    tape: "rgba(0,0,0,.2)",
  },
  {
    big: "I never said you deserve better. Because I've never seen anyone better than me.",
    small: "rule #05",
    style: "bg-ink",
    fg: "#fdf8f3",
    emojis: ["💎", "🪞", "✨"],
    tape: "rgba(255,243,160,.4)",
  },
  {
    big: "Enjoy my temporary downfall. Once I come back — you'll never smile again.",
    small: "for the enemies",
    style: "bg-skyish",
    fg: "#0a0a0a",
    emojis: ["🌪️", "📈", "😈"],
    tape: "rgba(210,54,82,.35)",
  },
];

export default function Mind() {
  return (
    <section id="mind" className="relative py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-ink" /> 04 — The mind, unfiltered <span className="sparkle">✦</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.95] max-w-4xl">
            Notes I tell myself <span className="italic text-cherry">in the mirror.</span> 🪞
          </h2>
        </Reveal>

        <div className="mt-14 grid md:grid-cols-3 gap-7">
          {quotes.map((q, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 60, rotate: i % 2 ? 2.5 : -2.5 }}
              whileInView={{ opacity: 1, y: 0, rotate: i % 2 ? 1 : -1 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.9, delay: (i % 3) * 0.1, ease: [0.2, 0.85, 0.2, 1] }}
              whileHover={{ y: -10, rotate: 0, scale: 1.02 }}
              className={`cute-board ${q.style} relative p-7 md:p-8 min-h-[300px] flex flex-col justify-between overflow-visible`}
              style={{ color: q.fg }}
              data-cursor="hover"
            >
              {/* tape strip */}
              <div
                className="absolute -top-3 left-1/2 -translate-x-1/2 rotate-[-3deg] w-20 h-5 rounded-sm"
                style={{ background: q.tape, boxShadow: "0 4px 8px rgba(0,0,0,.15)" }}
              />
              {/* corner emojis */}
              <span className="float-emoji" style={{ top: -14, right: -10 }}>{q.emojis[0]}</span>
              <span className="float-emoji delay-2" style={{ bottom: -16, left: -8 }}>{q.emojis[1]}</span>
              <span className="float-emoji delay-3 text-base" style={{ top: 18, left: -14 }}>{q.emojis[2]}</span>

              <div className="flex items-center justify-between">
                <div className="text-[11px] font-mono uppercase tracking-widest px-2 py-1 rounded-md" style={{ background: "rgba(0,0,0,.08)", color: q.fg }}>
                  ★ {q.small}
                </div>
                <div className="text-[10px] font-mono opacity-80">№ {String(i + 1).padStart(2, "0")}</div>
              </div>
              <p className="font-display text-2xl md:text-[27px] leading-tight" style={{ color: q.fg }}>
                <span className="text-3xl opacity-70">"</span>
                {q.big}
                <span className="text-3xl opacity-70">"</span>
              </p>
              <div className="flex items-center justify-between text-[11px] font-mono">
                <span style={{ color: q.fg, opacity: .8 }}>— nikhil ✍️</span>
                <span className="wiggle cursor-pointer" style={{ color: q.fg }}>📌</span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Big highlight banner */}
        <Reveal delay={0.2}>
          <div className="mt-20 relative overflow-hidden rounded-[2rem] cute-board paper px-8 py-14 md:py-20">
            <div className="absolute -top-10 -left-10 w-60 h-60 bg-pinkish blob opacity-80" />
            <div className="absolute -bottom-10 -right-10 w-60 h-60 bg-skyish blob opacity-80" />
            <span className="float-emoji text-4xl" style={{ top: 16, left: 24 }}>👨‍👩‍👦</span>
            <span className="float-emoji delay-2 text-4xl" style={{ top: 16, right: 24 }}>🩷</span>
            <span className="float-emoji delay-3 text-3xl" style={{ bottom: 18, left: "45%" }}>✨</span>
            <p className="relative font-display text-4xl md:text-6xl leading-[0.95] text-center">
              No one can love you more than your <span className="italic text-cherry">Mom & Dad.</span>
              <br />
              Everything else is just <span className="line-through opacity-60">noise</span> data. 📊
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
