import { motion, AnimatePresence } from "framer-motion";
import { useState, useRef } from "react";
import Reveal from "./Reveal";

const verdicts = [
  { range: [90, 100], v: "soulmate-tier · DM him before someone else does", emoji: "🩷" },
  { range: [75, 89],  v: "dangerous chemistry · proceed with caution", emoji: "🔥" },
  { range: [60, 74],  v: "decent vibes · he might reply on a good day", emoji: "✨" },
  { range: [40, 59],  v: "friend-zoned in advance · sorry babe", emoji: "🤝" },
  { range: [20, 39],  v: "block each other for safety", emoji: "🚧" },
  { range: [0, 19],   v: "go touch grass first then come back", emoji: "🌱" },
];

const flirtyLines = [
  "he already noticed you 👀",
  "he saved your name in his head",
  "you're his type — and he hates that",
  "the algorithm is shipping you two",
  "danger: cherry-coded compatibility",
];

export default function CrushDetector() {
  const [name, setName] = useState("");
  const [stage, setStage] = useState<"input" | "loading" | "result">("input");
  const [score, setScore] = useState(0);
  const [metrics, setMetrics] = useState({ vibe: 0, brain: 0, danger: 0, loyalty: 0, chaos: 0 });
  const [progress, setProgress] = useState(0);
  const intRef = useRef<number | null>(null);

  // hash name → deterministic score so same name = same result
  const hash = (s: string) => {
    let h = 7;
    for (const c of s.toLowerCase().trim()) h = (h * 31 + c.charCodeAt(0)) % 1000003;
    return h;
  };

  const start = () => {
    if (!name.trim()) return;
    const h = hash(name);
    const s = 35 + (h % 65); // 35-99
    const m = {
      vibe: 50 + (h % 50),
      brain: 40 + ((h * 3) % 60),
      danger: 30 + ((h * 7) % 70),
      loyalty: 20 + ((h * 11) % 80),
      chaos: 60 + ((h * 13) % 40),
    };
    setStage("loading");
    setProgress(0);
    let p = 0;
    intRef.current = window.setInterval(() => {
      p += 4 + Math.random() * 6;
      if (p >= 100) {
        p = 100;
        if (intRef.current) clearInterval(intRef.current);
        setProgress(100);
        setTimeout(() => {
          setScore(s);
          setMetrics(m);
          setStage("result");
        }, 400);
      } else setProgress(Math.floor(p));
    }, 90);
  };

  const reset = () => {
    setStage("input");
    setName("");
    setScore(0);
  };

  const verdict = verdicts.find((v) => score >= v.range[0] && score <= v.range[1]) || verdicts[5];
  const flirt = flirtyLines[hash(name) % flirtyLines.length];

  return (
    <section className="relative py-32 px-6 bg-pinkish/40 overflow-hidden">
      <span className="float-emoji text-5xl" style={{ top: 80, left: 60 }}>💘</span>
      <span className="float-emoji delay-2 text-5xl" style={{ top: 100, right: 80 }}>🔬</span>
      <span className="float-emoji delay-3 text-4xl" style={{ bottom: 80, left: 100 }}>🧪</span>

      <div className="relative max-w-4xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-ink" /> lab — compatibility test <span className="sparkle">💘</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.9] mb-12">
            crush <span className="italic text-cherry">detector</span> 9000.
          </h2>
        </Reveal>

        <div className="cute-board bg-cream relative p-6 md:p-10">
          <span className="float-emoji text-3xl" style={{ top: -16, right: 20 }}>🩷</span>

          <AnimatePresence mode="wait">
            {stage === "input" && (
              <motion.div
                key="input"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-center"
              >
                <p className="font-display text-3xl md:text-4xl mb-2">Enter your name 👇</p>
                <p className="text-sm font-mono uppercase tracking-widest opacity-80 mb-6">
                  let's see how compatible you are with nikhil
                </p>
                <div className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && start()}
                    placeholder="your full name..."
                    className="flex-1 px-5 py-4 rounded-2xl bg-cream border-2 border-ink font-display text-xl placeholder:text-ink/40 focus:outline-none focus:ring-4 focus:ring-cherry/40"
                  />
                  <button
                    onClick={start}
                    disabled={!name.trim()}
                    className="px-6 py-4 rounded-2xl bg-cherry text-cream font-display text-xl border-2 border-ink shadow-[4px_4px_0_#0a0a0a] hover:-translate-y-0.5 transition disabled:opacity-50"
                    data-cursor="hover"
                  >
                    test it 🔬
                  </button>
                </div>
              </motion.div>
            )}

            {stage === "loading" && (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-center py-8"
              >
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1.2, repeat: Infinity, ease: "linear" }}
                  className="text-6xl mb-4 inline-block"
                >
                  💘
                </motion.div>
                <p className="font-display text-2xl md:text-3xl mb-2">analyzing {name}...</p>
                <p className="font-mono text-xs uppercase tracking-widest opacity-80 mb-6">
                  scanning vibes · checking aura · matching cherry levels
                </p>
                <div className="max-w-md mx-auto h-3 rounded-full bg-ink/10 overflow-hidden">
                  <motion.div animate={{ width: `${progress}%` }} className="h-full bg-cherry" />
                </div>
                <p className="font-mono text-xs mt-2">{progress}%</p>
              </motion.div>
            )}

            {stage === "result" && (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ type: "spring", stiffness: 150, damping: 16 }}
              >
                {/* hero score */}
                <div className="text-center mb-8">
                  <div className="font-mono text-xs uppercase tracking-widest opacity-80 mb-2">
                    {name} × Nikhil
                  </div>
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
                    className="font-display text-[120px] md:text-[180px] leading-none text-cherry"
                  >
                    {score}<span className="text-5xl md:text-7xl">%</span>
                  </motion.div>
                  <div className="font-display text-2xl md:text-3xl italic mt-2">
                    {verdict.emoji} {verdict.v}
                  </div>
                  <div className="font-mono text-xs uppercase tracking-widest mt-3 opacity-80">
                    psst → {flirt}
                  </div>
                </div>

                {/* metrics */}
                <div className="grid sm:grid-cols-2 gap-3 mb-8">
                  {Object.entries(metrics).map(([k, v]) => (
                    <div key={k} className="bg-cream border-2 border-ink rounded-xl p-3">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-mono text-xs uppercase tracking-widest">{k}</span>
                        <span className="font-display text-lg">{v}%</span>
                      </div>
                      <div className="h-2 bg-ink/10 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${v}%` }}
                          transition={{ duration: 1.2, delay: 0.3 }}
                          className={k === "loyalty" ? "h-full bg-skyish" : k === "danger" ? "h-full bg-cherry" : k === "chaos" ? "h-full bg-pinkish" : "h-full bg-lemon"}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                {/* shareable card preview */}
                <div className="bg-ink text-cream rounded-2xl p-5 mb-6 relative overflow-hidden">
                  <div className="absolute -top-6 -right-6 text-[150px] opacity-10">🍒</div>
                  <div className="font-mono text-[10px] uppercase tracking-widest opacity-80 mb-1">
                    📸 screenshot this · share on stories
                  </div>
                  <div className="font-display text-2xl">
                    "{name} is <span className="text-cherry">{score}%</span> compatible with Nikhil Mehra"
                  </div>
                  <div className="font-mono text-[10px] mt-2 opacity-80">tag @Enzo_x590 — let chaos begin</div>
                </div>

                <div className="flex gap-3 justify-center flex-wrap">
                  <button
                    onClick={reset}
                    className="px-6 py-3 rounded-full bg-ink text-cream font-display text-base hover:bg-cherry transition border-2 border-ink"
                  >
                    ↻ test another name
                  </button>
                  <a
                    href="https://www.instagram.com/Enzo_x590"
                    target="_blank"
                    rel="noreferrer"
                    className="px-6 py-3 rounded-full bg-cherry text-cream font-display text-base hover:bg-ink transition border-2 border-ink"
                  >
                    DM the result →
                  </a>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
