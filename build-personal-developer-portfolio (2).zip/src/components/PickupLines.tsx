import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import Reveal from "./Reveal";

const lines = [
  "teri smile dekhi, mera CSS bhi crash ho gaya 💻",
  "tu git pull hai, tu meri life mein update layi 💖",
  "main introvert hu, but tere liye exception bana lunga 🩷",
  "agar tu null hoti, mai bhi undefined ho jaata 🥲",
  "tere jaisi koi rare commit nahi dekhi maine 📦",
  "scroll bhi karu toh tu hi mil hai, refresh bhi karu toh tu hi 🔄",
  "tu cherry hai, mai 2AM ka coder — perfect ship 🍒",
  "mujhse zyada loyal toh meri localStorage hai, par tu uske level pe aa sakti hai 💾",
  "main tera n8n hu — automatically tujh tak pahuch jaata hu ⚙️",
  "tu mera biggest distraction hai, aur main potential pe focus karta hu — soch matlab kya hai 🎯",
  "tere bina mera dark mode bhi sad lagta hai 🌙",
  "ek baar try kar le, mai tera favourite framework ban jaaunga 💌",
  "main mystery hu, tu uska clue — mil ke kahaani complete 📖",
  "teri ek smile = mere 100 deploys successful 🚀",
  "tujhe dekha toh laga — life ka demo over, full version unlocked 🔓",
  "tu mere portfolio pe sabse pretty section hai, aur main jaanta nahi tu kya hai 😏",
  "main quiet hu but tere liye mai stories upload karta hu 📸",
  "tu meri inspiration hai, even though humne baat bhi nahi ki yet 🙈",
  "mai expensive nahi hu, mai limited edition hu — collect kar le 🎴",
  "agar pyaar ek language hoti, main usme fluent hu — tujhse seekh ke 🩷",
];

export default function PickupLines() {
  const [idx, setIdx] = useState(0);
  const [copied, setCopied] = useState(false);
  const [used, setUsed] = useState<number[]>([]);

  const next = () => {
    let n = Math.floor(Math.random() * lines.length);
    if (used.length >= lines.length) setUsed([]);
    while (used.includes(n) && used.length < lines.length) n = Math.floor(Math.random() * lines.length);
    setUsed((u) => [...u, n]);
    setIdx(n);
  };

  const copy = () => {
    navigator.clipboard?.writeText(lines[idx]);
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  };

  return (
    <section className="relative py-32 px-6 bg-lemon/30 overflow-hidden">
      <span className="float-emoji text-5xl" style={{ top: 60, left: 80 }}>😏</span>
      <span className="float-emoji delay-2 text-5xl" style={{ top: 100, right: 60 }}>🌹</span>
      <span className="float-emoji delay-3 text-4xl" style={{ bottom: 70, left: 100 }}>💌</span>

      <div className="relative max-w-4xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-ink" /> rizz lab · hinglish edition <span className="sparkle">😏</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.9] mb-4">
            steal a <span className="italic text-cherry">line.</span>
          </h2>
        </Reveal>
        <Reveal>
          <p className="text-base md:text-lg mb-10 max-w-xl">
            free real estate — copy paste karo, dm karo, fame kamao. credit dene ki zaroorat nahi 😉
          </p>
        </Reveal>

        <div className="cute-board bg-cherry text-cream relative p-8 md:p-12 min-h-[280px] flex flex-col justify-between overflow-visible">
          <span className="float-emoji text-3xl" style={{ top: -16, left: 20 }}>💘</span>
          <span className="float-emoji delay-2 text-3xl" style={{ top: -16, right: 20 }}>🩷</span>

          <div className="font-mono text-xs uppercase tracking-widest opacity-90">
            line #{(used.indexOf(idx) + 1).toString().padStart(2, "0")} / {lines.length}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="font-display text-3xl md:text-5xl italic leading-tight my-6"
            >
              "{lines[idx]}"
            </motion.div>
          </AnimatePresence>

          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="font-mono text-xs uppercase tracking-widest opacity-90">
              — nikhil's secret arsenal
            </div>
            <div className="flex gap-3">
              <button
                onClick={copy}
                className="px-5 py-2.5 rounded-full bg-cream text-ink font-display text-base border-2 border-ink hover:bg-lemon transition"
                data-cursor="hover"
              >
                {copied ? "copied ✓" : "copy 📋"}
              </button>
              <button
                onClick={next}
                className="px-5 py-2.5 rounded-full bg-ink text-cream font-display text-base border-2 border-ink hover:bg-cream hover:text-ink transition"
                data-cursor="hover"
              >
                next line 🔁
              </button>
            </div>
          </div>
        </div>

        <div className="mt-4 text-center font-mono text-xs uppercase tracking-widest opacity-80">
          ⚠️ use responsibly · we are not liable for slaps
        </div>
      </div>
    </section>
  );
}
