import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import Reveal from "./Reveal";

type Upgrade = {
  id: string;
  name: string;
  emoji: string;
  baseCost: number;
  baseRate: number; // ₹ per second
  desc: string;
  unlockQuote: string;
};

const UPGRADES: Upgrade[] = [
  { id: "gpt",     name: "GPT Subscription", emoji: "🤖", baseCost: 50,    baseRate: 0.5,  desc: "auto-codes for you while you sleep", unlockQuote: "vibe coding unlocked. you're not alone anymore." },
  { id: "monitor", name: "2nd Monitor",      emoji: "🖥️", baseCost: 200,   baseRate: 2,    desc: "twice the chaos, twice the output",  unlockQuote: "now you can stalk and code at the same time." },
  { id: "n8n",     name: "n8n Server",       emoji: "⚙️", baseCost: 800,   baseRate: 8,    desc: "automate the boring parts of life",   unlockQuote: "manual work is for amateurs." },
  { id: "domain",  name: "Custom Domain",    emoji: "🌐", baseCost: 3000,  baseRate: 30,   desc: ".com or nothing",                       unlockQuote: "you exist on the internet now. officially." },
  { id: "team",    name: "Hire a Junior",    emoji: "🧑‍💻", baseCost: 12000, baseRate: 120,  desc: "delegate the bugs",                     unlockQuote: "first hire. don't go soft." },
  { id: "saas",    name: "SaaS Launch",      emoji: "🚀", baseCost: 50000, baseRate: 600,  desc: "monthly recurring chaos",               unlockQuote: "MRR > salary. always." },
  { id: "lambo",   name: "Lambo Down Payment", emoji: "🏎️", baseCost: 250000, baseRate: 0, desc: "the flex (no extra income)",            unlockQuote: "you've made it. tell your enemies." },
];

const fmt = (n: number) => {
  if (n >= 10000000) return `${(n / 10000000).toFixed(2)}Cr`;
  if (n >= 100000)   return `${(n / 100000).toFixed(2)}L`;
  if (n >= 1000)     return `${(n / 1000).toFixed(1)}k`;
  return `${Math.floor(n)}`;
};

const GOAL = 10000000; // ₹1 crore

export default function CherryTycoon() {
  const [money, setMoney] = useState(0);
  const [owned, setOwned] = useState<Record<string, number>>({});
  const [popups, setPopups] = useState<{ id: number; x: number; y: number; v: number }[]>([]);
  const [toast, setToast] = useState("");
  const lastTick = useRef(Date.now());
  const moneyRef = useRef(0);

  // load
  useEffect(() => {
    try {
      const s = localStorage.getItem("nm-tycoon");
      if (s) {
        const d = JSON.parse(s);
        setMoney(d.money || 0);
        setOwned(d.owned || {});
        moneyRef.current = d.money || 0;
      }
    } catch {}
  }, []);

  // save
  useEffect(() => {
    moneyRef.current = money;
    localStorage.setItem("nm-tycoon", JSON.stringify({ money, owned }));
  }, [money, owned]);

  // passive income tick
  useEffect(() => {
    const t = setInterval(() => {
      const rate = UPGRADES.reduce((s, u) => s + (owned[u.id] || 0) * u.baseRate, 0);
      const now = Date.now();
      const dt = (now - lastTick.current) / 1000;
      lastTick.current = now;
      if (rate > 0) setMoney((m) => m + rate * dt);
    }, 250);
    return () => clearInterval(t);
  }, [owned]);

  const click = (e: React.MouseEvent) => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const v = 1 + Object.keys(owned).length * 0.5;
    const id = Date.now() + Math.random();
    setPopups((p) => [...p, { id, x: e.clientX - r.left, y: e.clientY - r.top, v }]);
    setMoney((m) => m + v);
    setTimeout(() => setPopups((p) => p.filter((pp) => pp.id !== id)), 800);
  };

  const cost = (u: Upgrade) => Math.floor(u.baseCost * Math.pow(1.45, owned[u.id] || 0));

  const buy = (u: Upgrade) => {
    const c = cost(u);
    if (money < c) {
      setToast("not enough ₹");
      setTimeout(() => setToast(""), 1200);
      return;
    }
    const wasFirst = !owned[u.id];
    setMoney((m) => m - c);
    setOwned((o) => ({ ...o, [u.id]: (o[u.id] || 0) + 1 }));
    if (wasFirst) {
      setToast(`🔓 ${u.unlockQuote}`);
      setTimeout(() => setToast(""), 3500);
    }
  };

  const reset = () => {
    if (!confirm("reset all progress? (everything lost)")) return;
    setMoney(0);
    setOwned({});
    localStorage.removeItem("nm-tycoon");
  };

  const ratePerSec = UPGRADES.reduce((s, u) => s + (owned[u.id] || 0) * u.baseRate, 0);
  const pct = Math.min(100, (money / GOAL) * 100);
  const isMillionaire = money >= GOAL;

  return (
    <section className="relative py-32 px-6 bg-cream overflow-hidden">
      <span className="float-emoji text-5xl" style={{ top: 60, left: 60 }}>💸</span>
      <span className="float-emoji delay-2 text-5xl" style={{ top: 100, right: 80 }}>🍒</span>
      <span className="float-emoji delay-3 text-4xl" style={{ bottom: 80, right: 100 }}>📈</span>

      <div className="relative max-w-6xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-ink" /> incremental · save persists <span className="sparkle">💾</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.9] mb-4">
            cherry <span className="italic text-cherry">tycoon.</span>
          </h2>
        </Reveal>
        <Reveal>
          <p className="text-base md:text-lg mb-8 max-w-xl">
            tap the cherry to earn ₹. buy upgrades. unlock nikhil-quotes. goal: <span className="text-cherry">₹1 crore</span> = millionaire status 🏆
          </p>
        </Reveal>

        {/* HUD */}
        <div className="cute-board bg-ink text-cream relative p-5 mb-6 overflow-visible">
          <span className="float-emoji text-3xl" style={{ top: -16, right: 20 }}>👑</span>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <div className="font-mono text-xs uppercase tracking-widest opacity-90">balance</div>
              <div className="font-display text-5xl md:text-6xl">₹{fmt(money)}</div>
            </div>
            <div>
              <div className="font-mono text-xs uppercase tracking-widest opacity-90">income</div>
              <div className="font-display text-3xl md:text-4xl text-lemon">+₹{ratePerSec.toFixed(1)}/s</div>
            </div>
            <div className="flex-1 min-w-[200px]">
              <div className="flex justify-between font-mono text-xs uppercase tracking-widest opacity-90 mb-1">
                <span>progress to ₹1 cr</span><span>{pct.toFixed(2)}%</span>
              </div>
              <div className="h-3 bg-cream/15 rounded-full overflow-hidden">
                <motion.div animate={{ width: `${pct}%` }} className="h-full bg-cherry" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-5 gap-5">
          {/* tap area */}
          <div
            onClick={click}
            className="lg:col-span-2 cute-board bg-pinkish relative h-[420px] cursor-pointer overflow-hidden flex items-center justify-center select-none"
            data-cursor="hover"
          >
            <motion.div
              animate={{ scale: [1, 0.92, 1] }}
              transition={{ duration: 1.6, repeat: Infinity }}
              className="text-[160px] md:text-[220px] pointer-events-none select-none"
            >
              🍒
            </motion.div>
            <div className="absolute top-3 left-3 font-mono text-xs uppercase tracking-widest">tap to earn</div>
            <div className="absolute bottom-3 right-3 font-mono text-xs">+₹{(1 + Object.keys(owned).length * 0.5).toFixed(1)} per tap</div>
            <AnimatePresence>
              {popups.map((p) => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 1, scale: 0, y: 0 }}
                  animate={{ opacity: 0, scale: 1.4, y: -70 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.8 }}
                  style={{ left: p.x, top: p.y }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none font-display text-2xl text-cherry font-black drop-shadow-[2px_2px_0_#0a0a0a]"
                >
                  +₹{p.v.toFixed(1)}
                </motion.div>
              ))}
            </AnimatePresence>

            {isMillionaire && (
              <motion.div
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 bg-cherry/95 flex flex-col items-center justify-center text-cream"
              >
                <div className="text-7xl mb-4">👑</div>
                <div className="font-display text-3xl">MILLIONAIRE STATUS</div>
                <div className="font-mono text-xs uppercase tracking-widest mt-2">told you. nothing is impossible.</div>
              </motion.div>
            )}
          </div>

          {/* upgrades */}
          <div className="lg:col-span-3 grid sm:grid-cols-2 gap-3 max-h-[420px] overflow-y-auto pr-1">
            {UPGRADES.map((u) => {
              const c = cost(u);
              const can = money >= c;
              return (
                <motion.button
                  key={u.id}
                  onClick={() => buy(u)}
                  whileHover={can ? { y: -4 } : {}}
                  whileTap={can ? { scale: 0.97 } : {}}
                  disabled={!can}
                  className={`text-left cute-board ${can ? "bg-lemon" : "bg-cream opacity-60"} relative p-4 overflow-visible`}
                >
                  <span className="float-emoji text-2xl" style={{ top: -14, right: -6 }}>{u.emoji}</span>
                  <div className="flex items-baseline justify-between mb-1">
                    <span className="font-display text-lg leading-tight">{u.name}</span>
                    <span className="font-mono text-xs">×{owned[u.id] || 0}</span>
                  </div>
                  <div className="text-xs opacity-90 mb-2">{u.desc}</div>
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs uppercase tracking-widest">+₹{u.baseRate}/s</span>
                    <span className={`font-display text-lg ${can ? "text-cherry" : ""}`}>₹{fmt(c)}</span>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        <div className="mt-5 flex items-center justify-between flex-wrap gap-3">
          <div className="font-mono text-xs uppercase tracking-widest">💾 auto-saves to your device</div>
          <button onClick={reset} className="font-mono text-xs uppercase tracking-widest text-cherry hover:underline">
            reset progress
          </button>
        </div>

        <AnimatePresence>
          {toast && (
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[70] bg-cherry text-cream font-display text-base px-6 py-3 rounded-full shadow-2xl border-2 border-ink max-w-md text-center"
            >
              {toast}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
