import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import Reveal from "./Reveal";

/* ============================================================
   ASSETS
============================================================ */
const GAREEB_AUDIO =
  "https://www.myinstants.com/media/sounds/jo-gareeb-hove-naa.mp3";
const HANDSOME_AUDIO =
  "https://www.myinstants.com/media/sounds/wow-kya-ladka-hai-very-handsome-boy.mp3";

const PROCESSING_GIF =
  "https://media1.giphy.com/media/v1.Y2lkPTZjMDliOTUyZXl3NzRtNHJ6dzlxb3NnMnJ4b2lwMmV0eXVpcXBxNnFnZW56YnQ5NiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9dg/FYb5IqqhtkwR2aPiM8/giphy.gif";

const REVEAL_GIF =
  "https://media2.giphy.com/media/v1.Y2lkPTZjMDliOTUyZm5pdXhsa2NyN2EyeHZ0bmIwaGhsdzcweTh3ZXJmdDlnOWphMjVpdCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/XYEEvoX0Ub69ZgN9ai/giphy.gif";

// floating thought bubbles during the "reading" animation
const THOUGHTS = [
  "thinking about him...",
  "why is he so mysterious 😩",
  "should I message him today?",
  "omg stop it 🫣",
  "he's literally my type",
  "focus... focus... 🧘",
  "wait he's so cute though",
  "is he reading MY thoughts rn?",
  "cherry boy 🍒",
  "he's different. different.",
];

type Phase = "idle" | "reading" | "ready" | "processing" | "almost" | "reveal";

export default function ReadMyMind() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timers = useRef<number[]>([]);

  const clearTimers = () => {
    timers.current.forEach((t) => clearTimeout(t));
    timers.current = [];
  };

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }
  };

  const play = (src: string) => {
    try {
      stopAudio();
      const a = new Audio(src);
      a.volume = 0.75;
      a.play().catch(() => {});
      audioRef.current = a;
      return a;
    } catch {
      return null;
    }
  };

  useEffect(() => {
    return () => {
      clearTimers();
      stopAudio();
    };
  }, []);

  // ============== START ==============
  const start = () => {
    clearTimers();
    setProgress(0);
    setPhase("reading");
    // after 10s, show the fast button
    const t = window.setTimeout(() => setPhase("ready"), 10000);
    timers.current.push(t);
  };

  // ============== DO IT FAST ==============
  const doFast = () => {
    setPhase("processing");
    // play gareeb audio
    const a = play(GAREEB_AUDIO);
    if (a) {
      // when audio ends, auto-advance to almost
      a.addEventListener("ended", () => {
        // fallback: move forward if we haven't yet
      });
    }

    // animate progress 1 -> 100 over ~5s
    let p = 1;
    const tick = () => {
      p += 2;
      if (p >= 100) {
        setProgress(100);
        // move to almost phase
        const t = window.setTimeout(() => setPhase("almost"), 200);
        timers.current.push(t);
        const t2 = window.setTimeout(() => setPhase("reveal"), 2200);
        timers.current.push(t2);
        return;
      }
      setProgress(p);
      const tt = window.setTimeout(tick, 100);
      timers.current.push(tt);
    };
    tick();

    // safety: force reveal after 8s no matter what
    const safety = window.setTimeout(() => setPhase("reveal"), 8000);
    timers.current.push(safety);
  };

  // play handsome audio once reveal phase kicks in
  useEffect(() => {
    if (phase === "reveal") {
      // small delay so GIF loads first
      const t = window.setTimeout(() => play(HANDSOME_AUDIO), 350);
      timers.current.push(t);
    }
  }, [phase]);

  const reset = () => {
    clearTimers();
    stopAudio();
    setProgress(0);
    setPhase("idle");
  };

  return (
    <section className="relative py-32 px-6 bg-pinkish/40 overflow-hidden">
      {/* floating emojis */}
      <span className="float-emoji text-5xl" style={{ top: 60, left: 80 }}>
        🧠
      </span>
      <span className="float-emoji delay-2 text-5xl" style={{ top: 100, right: 100 }}>
        🔮
      </span>
      <span className="float-emoji delay-3 text-4xl" style={{ bottom: 80, left: 100 }}>
        💭
      </span>

      <div className="relative max-w-3xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-ink" /> mind reader · experimental{" "}
            <span className="sparkle">🔮</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.9] mb-12">
            read my <span className="italic text-cherry">mind.</span> ✨
          </h2>
        </Reveal>

        {/* THE CARD */}
        <Reveal delay={0.1}>
          <div className="relative">
            {/* stacked depth layers */}
            <div className="absolute inset-0 translate-x-3 translate-y-3 rounded-[36px] bg-cherry/80" />
            <div className="absolute inset-0 translate-x-1.5 translate-y-1.5 rounded-[36px] bg-ink/90" />

            <div className="relative rounded-[36px] bg-cream border-2 border-ink overflow-hidden shadow-2xl">
              {/* top ribbon */}
              <div className="flex items-center justify-between px-6 py-3 border-b-2 border-ink bg-lemon">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-cherry border border-ink" />
                  <span className="w-3 h-3 rounded-full bg-skyish border border-ink" />
                  <span className="w-3 h-3 rounded-full bg-pinkish border border-ink" />
                </div>
                <span className="font-mono text-[11px] tracking-[0.2em] uppercase">
                  mind-reader.exe · v1.0
                </span>
                <span className="font-mono text-[11px]">
                  {phase === "reading" || phase === "ready" ? "●REC" : "○"}
                </span>
              </div>

              {/* content */}
              <div className="px-6 md:px-12 py-12 md:py-16 min-h-[440px] flex flex-col items-center justify-center text-center">
                <AnimatePresence mode="wait">
                  {/* ============ IDLE ============ */}
                  {phase === "idle" && (
                    <motion.div
                      key="idle"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ duration: 0.5 }}
                    >
                      <motion.div
                        animate={{ rotate: [0, -8, 8, 0], scale: [1, 1.05, 1] }}
                        transition={{ duration: 3, repeat: Infinity }}
                        className="text-8xl mb-6"
                      >
                        🧖🏻
                      </motion.div>
                      <h3 className="font-display text-4xl md:text-5xl leading-[1.05] mb-3">
                        read your mind <span className="italic text-cherry">focusly.</span>
                      </h3>
                      <p className="font-display text-2xl md:text-3xl italic mb-2">
                        don't disturb me 😡
                      </p>
                      <p className="text-base md:text-lg mb-10">
                        be peaceful while i'm reading ur mind 🫶
                      </p>

                      <motion.button
                        onClick={start}
                        whileHover={{ scale: 1.06 }}
                        whileTap={{ scale: 0.94 }}
                        className="relative group"
                        data-cursor="hover"
                      >
                        <span className="absolute inset-0 translate-x-1.5 translate-y-1.5 rounded-full bg-ink" />
                        <span className="relative inline-flex items-center gap-3 px-10 py-5 rounded-full bg-cherry text-cream font-display text-2xl md:text-3xl border-2 border-ink shadow-lg">
                          Read My Mind ✨
                        </span>
                      </motion.button>

                      <p className="font-mono text-[10px] uppercase tracking-widest mt-6 opacity-70">
                        🔊 sound on · full experience
                      </p>
                    </motion.div>
                  )}

                  {/* ============ READING ============ */}
                  {phase === "reading" && (
                    <motion.div
                      key="reading"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="relative w-full"
                    >
                      <motion.div
                        animate={{ scale: [1, 1.15, 1], rotate: [0, 10, -10, 0] }}
                        transition={{ duration: 2.5, repeat: Infinity }}
                        className="text-9xl mb-4 inline-block"
                      >
                        🧖🏻
                      </motion.div>
                      <h3 className="font-display text-4xl md:text-5xl italic mb-4">
                        reading ur current thoughts 🧖🏻
                      </h3>
                      <p className="font-mono text-xs uppercase tracking-widest opacity-80 mb-6">
                        ⏳ be still · i can feel it working
                      </p>

                      {/* floating thought bubbles */}
                      <div className="relative h-32 md:h-40 mb-6 overflow-hidden">
                        <ThoughtStream />
                      </div>

                      {/* progress ring */}
                      <div className="flex items-center justify-center gap-3">
                        {Array.from({ length: 3 }).map((_, i) => (
                          <motion.span
                            key={i}
                            className="w-4 h-4 rounded-full bg-cherry"
                            animate={{ y: [0, -14, 0] }}
                            transition={{
                              duration: 0.9,
                              repeat: Infinity,
                              delay: i * 0.2,
                            }}
                          />
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {/* ============ READY ============ */}
                  {phase === "ready" && (
                    <motion.div
                      key="ready"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="relative w-full"
                    >
                      <motion.div
                        animate={{ scale: [1, 1.15, 1], rotate: [0, 10, -10, 0] }}
                        transition={{ duration: 2.5, repeat: Infinity }}
                        className="text-9xl mb-4 inline-block"
                      >
                        🧖🏻
                      </motion.div>
                      <h3 className="font-display text-4xl md:text-5xl italic mb-4">
                        i can almost read it...
                      </h3>
                      <p className="text-base md:text-lg mb-2">
                        but i need your help to crack it open 🔓
                      </p>
                      <p className="font-mono text-xs uppercase tracking-widest opacity-80 mb-6">
                        press the button · do not hesitate
                      </p>

                      {/* thought stream still running */}
                      <div className="relative h-28 mb-6 overflow-hidden">
                        <ThoughtStream />
                      </div>

                      <motion.button
                        onClick={doFast}
                        whileHover={{ scale: 1.08 }}
                        whileTap={{ scale: 0.92 }}
                        animate={{ scale: [1, 1.04, 1] }}
                        transition={{ duration: 0.8, repeat: Infinity }}
                        className="relative group"
                        data-cursor="hover"
                      >
                        <span className="absolute inset-0 translate-x-1.5 translate-y-1.5 rounded-full bg-ink" />
                        <span className="relative inline-flex items-center gap-2 px-8 py-4 rounded-full bg-cherry text-cream font-display text-xl md:text-2xl border-2 border-ink shadow-lg">
                          Do it fast 😭🙏🏻
                        </span>
                      </motion.button>
                    </motion.div>
                  )}

                  {/* ============ PROCESSING ============ */}
                  {phase === "processing" && (
                    <motion.div
                      key="processing"
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0 }}
                      className="w-full"
                    >
                      <h3 className="font-display text-3xl md:text-4xl mb-4 italic">
                        scanning... {progress}%
                      </h3>

                      {/* progress bar */}
                      <div className="max-w-md mx-auto mb-6 h-4 bg-ink/10 rounded-full overflow-hidden border-2 border-ink">
                        <motion.div
                          animate={{ width: `${progress}%` }}
                          transition={{ ease: "linear" }}
                          className="h-full bg-cherry"
                        />
                      </div>

                      <p className="font-mono text-xs uppercase tracking-widest opacity-80 mb-6">
                        🔊 decoding ur vibe...
                      </p>

                      {/* GIF appears once progress hits 100 */}
                      <AnimatePresence>
                        {progress >= 100 && (
                          <motion.div
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            transition={{ type: "spring", stiffness: 160, damping: 16 }}
                            className="flex justify-center"
                          >
                            <div className="relative inline-block">
                              <div className="absolute inset-0 bg-cherry rounded-2xl translate-x-2 translate-y-2" />
                              <img
                                src={PROCESSING_GIF}
                                alt="processing"
                                className="relative w-56 md:w-64 h-auto rounded-2xl border-2 border-ink object-cover"
                              />
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  )}

                  {/* ============ ALMOST ============ */}
                  {phase === "almost" && (
                    <motion.div
                      key="almost"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="w-full"
                    >
                      <motion.h3
                        animate={{
                          scale: [1, 1.08, 1],
                          filter: ["blur(0px)", "blur(4px)", "blur(0px)"],
                        }}
                        transition={{ duration: 1.2, repeat: Infinity }}
                        className="font-display text-5xl md:text-6xl italic mb-4"
                      >
                        almost <span className="text-cherry">there...</span>
                      </motion.h3>
                      <p className="font-mono text-xs uppercase tracking-widest opacity-80">
                        🫣 don't blink
                      </p>

                      {/* blurry reveal effect */}
                      <motion.div
                        animate={{
                          filter: ["blur(30px)", "blur(10px)", "blur(0px)"],
                          scale: [0.9, 1.05, 1],
                        }}
                        transition={{ duration: 2, ease: "easeOut" }}
                        className="mt-6 flex justify-center"
                      >
                        <div className="relative inline-block">
                          <div className="absolute inset-0 bg-cherry rounded-3xl translate-x-2 translate-y-2" />
                          <img
                            src={REVEAL_GIF}
                            alt="the reveal"
                            className="relative w-64 md:w-80 h-auto rounded-3xl border-2 border-ink object-cover"
                          />
                        </div>
                      </motion.div>
                    </motion.div>
                  )}

                  {/* ============ REVEAL ============ */}
                  {phase === "reveal" && (
                    <motion.div
                      key="reveal"
                      initial={{ opacity: 0, scale: 0.5, rotate: -5 }}
                      animate={{ opacity: 1, scale: 1, rotate: 0 }}
                      transition={{ type: "spring", stiffness: 120, damping: 14 }}
                      className="w-full"
                    >
                      <motion.h3
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.2 }}
                        className="font-display text-4xl md:text-6xl leading-[1] mb-3"
                      >
                        your think about me
                      </motion.h3>
                      <motion.p
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.4 }}
                        className="font-display text-2xl md:text-4xl italic mb-6"
                      >
                        ik very well <span className="text-cherry">🥴🤘🏻</span>
                      </motion.p>

                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.6, type: "spring", stiffness: 150 }}
                        className="flex justify-center mb-6"
                      >
                        <div className="relative inline-block">
                          <div className="absolute inset-0 bg-cherry rounded-3xl translate-x-2 translate-y-2" />
                          <img
                            src={REVEAL_GIF}
                            alt="your mind"
                            className="relative w-64 md:w-80 h-auto rounded-3xl border-2 border-ink object-cover"
                          />
                        </div>
                      </motion.div>

                      <motion.p
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.9 }}
                        className="font-mono text-xs uppercase tracking-widest opacity-80 mb-2"
                      >
                        🔊 ur mind sounds like when u think about me:
                      </motion.p>

                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 1.1 }}
                        className="inline-block bg-ink text-cream px-5 py-3 rounded-full font-display italic text-lg"
                      >
                        "wow kya ladka hai... very handsome boy" 🩷
                      </motion.div>

                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 1.5 }}
                        className="mt-8"
                      >
                        <button
                          onClick={reset}
                          className="px-6 py-3 rounded-full bg-ink text-cream font-display text-base hover:bg-cherry transition border-2 border-ink"
                        >
                          ↻ read again
                        </button>
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* footer */}
              <div className="px-6 py-3 border-t-2 border-ink bg-skyish/40 flex items-center justify-between font-mono text-[10px] uppercase tracking-widest">
                <span>nikhil · mind reader</span>
                <span>
                  {phase === "idle" && "tap to start"}
                  {phase === "reading" && "scanning..."}
                  {phase === "ready" && "ready!"}
                  {phase === "processing" && "processing..."}
                  {phase === "almost" && "almost..."}
                  {phase === "reveal" && "✓ decoded"}
                </span>
                <span>v 1.0</span>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ============================================================
   Floating thought bubbles during reading animation
============================================================ */
function ThoughtStream() {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIdx((i) => (i + 1) % THOUGHTS.length), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center gap-2">
      <AnimatePresence mode="wait">
        <motion.div
          key={idx}
          initial={{ opacity: 0, y: 20, scale: 0.85 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.85 }}
          transition={{ duration: 0.5 }}
          className="bg-cream border-2 border-ink rounded-2xl px-5 py-2.5 font-display italic text-lg md:text-xl shadow-[3px_3px_0_#0a0a0a]"
        >
          💭 {THOUGHTS[idx]}
        </motion.div>
      </AnimatePresence>
      {/* floating mini bubbles */}
      <div className="absolute inset-x-0 bottom-0 pointer-events-none">
        {Array.from({ length: 6 }).map((_, i) => (
          <motion.span
            key={i}
            className="absolute bottom-0 text-xl"
            style={{ left: `${15 + i * 14}%` }}
            animate={{ y: [0, -120], opacity: [0, 1, 0] }}
            transition={{
              duration: 3 + (i % 3),
              repeat: Infinity,
              delay: i * 0.4,
              ease: "easeOut",
            }}
          >
            💭
          </motion.span>
        ))}
      </div>
    </div>
  );
}
