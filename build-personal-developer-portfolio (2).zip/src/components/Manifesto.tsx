import { motion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { useRef } from "react";

const lines = [
  { text: "I'm not building a portfolio.", emoji: "🚫" },
  { text: "I'm building proof.", emoji: "📜" },
  { text: "Proof that a kid from Kota,", emoji: "🌆" },
  { text: "with HTML, CSS, Java", emoji: "💻" },
  { text: "and a head full of plans,", emoji: "🧠" },
  { text: "can rewrite his bloodline by 19.", emoji: "👑" },
];

function Line({
  text,
  emoji,
  progress,
  i,
  total,
  italic,
}: {
  text: string;
  emoji: string;
  progress: MotionValue<number>;
  i: number;
  total: number;
  italic?: boolean;
}) {
  const start = i / total;
  const end = (i + 1) / total;
  const op = useTransform(progress, [start * 0.7, ((start + end) / 2) * 0.9, end * 0.95], [0.18, 1, 0.3]);
  const x = useTransform(progress, [start * 0.7, end * 0.95], [50, -10]);
  const scale = useTransform(progress, [start * 0.7, ((start + end) / 2) * 0.9, end * 0.95], [0.96, 1.02, 0.98]);
  return (
    <motion.div style={{ opacity: op, x, scale }} className="flex items-center gap-4 md:gap-6">
      <motion.span
        className="text-3xl md:text-5xl shrink-0"
        animate={{ rotate: [0, -8, 8, 0] }}
        transition={{ duration: 3.5, repeat: Infinity, delay: i * 0.3 }}
      >
        {emoji}
      </motion.span>
      <p className={`font-display text-4xl md:text-6xl leading-tight ${italic ? "italic text-cherry" : ""}`}>
        {text}
      </p>
    </motion.div>
  );
}

export default function Manifesto() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });

  return (
    <section ref={ref} className="relative py-32 px-6 bg-cream overflow-hidden">
      <span className="float-emoji text-5xl" style={{ top: 50, left: 60 }}>📌</span>
      <span className="float-emoji delay-2 text-5xl" style={{ top: 80, right: 80 }}>✨</span>
      <span className="float-emoji delay-3 text-4xl" style={{ bottom: 60, right: 100 }}>🍒</span>
      <div className="max-w-5xl mx-auto relative">
        <div className="text-xs font-mono uppercase tracking-widest mb-8 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-ink text-cream">
          <span className="sparkle">📜</span> manifesto · scroll slow
        </div>
        <div className="space-y-6 md:space-y-8">
          {lines.map((l, i) => (
            <Line
              key={i}
              text={l.text}
              emoji={l.emoji}
              progress={scrollYProgress}
              i={i}
              total={lines.length}
              italic={i === lines.length - 1}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
