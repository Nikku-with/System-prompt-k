import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import Reveal from "./Reveal";

const seedConfessions = [
  "i refresh his portfolio every night before sleeping 🥺",
  "i memorized his quotes before my exams",
  "i told my mom about him as 'just a friend'",
  "every cherry emoji reminds me of him now",
  "i screenshot his Insta stories. all of them.",
  "i started learning code because of his vibe",
  "he doesn't know but i visit this site daily at 2AM",
  "i once practiced my reply to his story for 40 mins",
  "my crush rating with him was 94%. i didn't share it.",
  "i hate that i think about him this much",
];

export default function ConfessionBooth() {
  const [text, setText] = useState("");
  const [sent, setSent] = useState(false);
  const [count, setCount] = useState(1247);
  const [showRandom, setShowRandom] = useState(false);
  const [randomIdx, setRandomIdx] = useState(0);

  useEffect(() => {
    const saved = parseInt(localStorage.getItem("nm-confessions") || "0", 10);
    setCount(1247 + saved);
  }, []);

  // rotate random confession every 4s
  useEffect(() => {
    const t = setInterval(() => {
      setRandomIdx((i) => (i + 1) % seedConfessions.length);
    }, 4000);
    return () => clearInterval(t);
  }, []);

  const submit = () => {
    if (!text.trim()) return;
    const next = parseInt(localStorage.getItem("nm-confessions") || "0", 10) + 1;
    localStorage.setItem("nm-confessions", String(next));
    setCount(1247 + next);
    setSent(true);
    setTimeout(() => setShowRandom(true), 1800);
  };

  const reset = () => {
    setText("");
    setSent(false);
    setShowRandom(false);
  };

  return (
    <section className="relative py-32 px-6 bg-skyish/30 overflow-hidden">
      <span className="float-emoji text-5xl" style={{ top: 60, left: 80 }}>💌</span>
      <span className="float-emoji delay-2 text-5xl" style={{ top: 100, right: 100 }}>🤫</span>
      <span className="float-emoji delay-3 text-4xl" style={{ bottom: 80, right: 80 }}>📮</span>

      <div className="relative max-w-3xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-ink" /> anonymous · no logs · no judgement <span className="sparkle">🤫</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.9] mb-4">
            the <span className="italic text-cherry">confession</span> booth.
          </h2>
        </Reveal>
        <Reveal>
          <p className="text-base md:text-lg mb-10 max-w-xl">
            tell me something. anything. nobody is watching except me 👀
          </p>
        </Reveal>

        {/* counter */}
        <Reveal>
          <div className="cute-board bg-cherry text-cream relative p-5 mb-6 text-center overflow-visible">
            <span className="float-emoji text-3xl" style={{ top: -16, left: 20 }}>📬</span>
            <span className="float-emoji delay-2 text-3xl" style={{ top: -16, right: 20 }}>✨</span>
            <div className="font-mono text-xs uppercase tracking-widest opacity-90">total confessions sealed</div>
            <motion.div
              key={count}
              initial={{ scale: 1.3 }}
              animate={{ scale: 1 }}
              className="font-display text-6xl md:text-7xl"
            >
              {count.toLocaleString()}
            </motion.div>
          </div>
        </Reveal>

        {/* booth */}
        <div className="cute-board bg-cream relative p-6 md:p-10">
          <AnimatePresence mode="wait">
            {!sent && (
              <motion.div
                key="form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="bata bhai... mai sun raha hu 🍒"
                  rows={5}
                  maxLength={300}
                  className="w-full px-5 py-4 rounded-2xl bg-cream border-2 border-ink font-display text-xl resize-none placeholder:text-ink/40 focus:outline-none focus:ring-4 focus:ring-cherry/40"
                />
                <div className="flex items-center justify-between mt-4 flex-wrap gap-3">
                  <span className="font-mono text-xs opacity-80">
                    {text.length} / 300 · 🔒 nothing leaves your device
                  </span>
                  <button
                    onClick={submit}
                    disabled={!text.trim()}
                    className="px-6 py-3 rounded-full bg-cherry text-cream font-display text-lg border-2 border-ink shadow-[4px_4px_0_#0a0a0a] hover:-translate-y-0.5 transition disabled:opacity-50"
                    data-cursor="hover"
                  >
                    seal envelope 💌
                  </button>
                </div>
              </motion.div>
            )}

            {sent && (
              <motion.div
                key="sent"
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center"
              >
                {/* envelope flying off */}
                <motion.div
                  initial={{ y: 0, rotate: 0, opacity: 1, scale: 1 }}
                  animate={{ y: -200, rotate: -25, opacity: 0, scale: 0.6 }}
                  transition={{ duration: 1.6, ease: [0.5, 0, 0.5, 1] }}
                  className="text-7xl inline-block"
                >
                  💌
                </motion.div>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.2 }}
                  className="font-display text-3xl md:text-4xl mt-2"
                >
                  sealed. delivered. 🩷
                </motion.p>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.5 }}
                  className="font-mono text-xs uppercase tracking-widest mt-2 opacity-80"
                >
                  your secret is safe with me · always
                </motion.p>

                {showRandom && (
                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-8 p-5 bg-ink text-cream rounded-2xl text-left relative overflow-hidden"
                  >
                    <div className="font-mono text-[10px] uppercase tracking-widest opacity-80 mb-1">
                      🔓 someone else once said
                    </div>
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={randomIdx}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.5 }}
                        className="font-display text-2xl italic"
                      >
                        "{seedConfessions[randomIdx]}"
                      </motion.div>
                    </AnimatePresence>
                    <div className="font-mono text-[10px] mt-2 opacity-80">
                      could be anyone · could be you 👀
                    </div>
                  </motion.div>
                )}

                <button
                  onClick={reset}
                  className="mt-6 px-5 py-2 rounded-full bg-cream text-ink border-2 border-ink font-mono text-xs uppercase tracking-widest hover:bg-cherry hover:text-cream transition"
                >
                  ↻ confess again
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
