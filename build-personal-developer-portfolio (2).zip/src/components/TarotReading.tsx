import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import Reveal from "./Reveal";

type Card = { name: string; emoji: string; bg: string; fg: string; reading: string };

const deck: Card[] = [
  { name: "the introvert",   emoji: "🌫️", bg: "#1f3a5f", fg: "#fdf8f3", reading: "your silence is loud. people misread it as weakness — it's actually your edit mode." },
  { name: "the millionaire", emoji: "👑", bg: "#fff3a0", fg: "#0a0a0a", reading: "the bag is closer than you think. but stop checking. just build." },
  { name: "the curse",       emoji: "💀", bg: "#0a0a0a", fg: "#fdf8f3", reading: "someone you trusted is loading betrayal. set the boundary before it sets you." },
  { name: "the cherry",      emoji: "🍒", bg: "#d23652", fg: "#fdf8f3", reading: "small thing. sweet thing. don't dismiss it — it's the sign you've been ignoring." },
  { name: "the comeback",    emoji: "📈", bg: "#ffc8d6", fg: "#0a0a0a", reading: "the dip wasn't the end. it was the loading screen. ship in 30 days." },
  { name: "the 2AM",         emoji: "🌙", bg: "#1a1820", fg: "#ff5c7a", reading: "your best ideas are in the silence after midnight. log off socials." },
  { name: "the empty chat",  emoji: "💬", bg: "#c8e6ff", fg: "#0a0a0a", reading: "stop waiting for that reply. they already saw it. move on, queen/king." },
  { name: "the mirror",      emoji: "🪞", bg: "#fdf8f3", fg: "#0a0a0a", reading: "what you criticize in others — fix it in you first. then watch the upgrade." },
  { name: "the cherry vault",emoji: "🔒", bg: "#8b1a2f", fg: "#fdf8f3", reading: "you're holding back a version of you that scares you. let her/him out." },
];

export default function TarotReading() {
  const [shuffled, setShuffled] = useState(() => [...deck].sort(() => Math.random() - 0.5));
  const [picked, setPicked] = useState<number[]>([]);
  const [reveal, setReveal] = useState(false);

  const pick = (i: number) => {
    if (picked.length >= 3 || picked.includes(i)) return;
    const next = [...picked, i];
    setPicked(next);
    if (next.length === 3) setTimeout(() => setReveal(true), 600);
  };

  const reset = () => {
    setShuffled([...deck].sort(() => Math.random() - 0.5));
    setPicked([]);
    setReveal(false);
  };

  return (
    <section className="relative py-32 px-6 bg-ink text-cream overflow-hidden">
      <span className="float-emoji text-5xl" style={{ top: 60, left: 60, filter: "none" }}>🔮</span>
      <span className="float-emoji delay-2 text-5xl" style={{ top: 100, right: 100 }}>🌙</span>
      <span className="float-emoji delay-3 text-4xl" style={{ bottom: 80, left: 80 }}>✨</span>
      <span className="float-emoji text-4xl" style={{ bottom: 80, right: 60 }}>🕯️</span>

      <div className="relative max-w-6xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-cream" /> the mystic · pick your fate <span className="sparkle">🔮</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.9] mb-4">
            tarot reading <br />
            <span className="italic text-cherry">by nikhil.</span>
          </h2>
        </Reveal>
        <Reveal>
          <p className="text-base md:text-lg mb-10 max-w-xl text-cream/90">
            pick 3 cards. don't think — feel. the deck knows what you need to hear today 🌙
          </p>
        </Reveal>

        {/* deck */}
        {!reveal && (
          <div className="grid grid-cols-3 md:grid-cols-9 gap-3 md:gap-4 mb-8">
            {shuffled.map((_, i) => {
              const isPicked = picked.includes(i);
              const order = picked.indexOf(i);
              return (
                <motion.button
                  key={i}
                  onClick={() => pick(i)}
                  whileHover={!isPicked ? { y: -10, rotate: i % 2 ? 4 : -4 } : {}}
                  animate={isPicked ? { y: -20, scale: 1.05 } : {}}
                  className="relative aspect-[2/3] rounded-2xl border-2 border-cream/40 bg-gradient-to-br from-cherry/40 to-ink overflow-hidden group"
                  data-cursor="hover"
                  disabled={picked.length >= 3 && !isPicked}
                >
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-3xl md:text-4xl group-hover:scale-110 transition">🃏</span>
                  </div>
                  <div className="absolute inset-2 border border-cream/30 rounded-xl pointer-events-none" />
                  {isPicked && (
                    <div className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-cherry text-cream font-display text-sm flex items-center justify-center border-2 border-cream">
                      {order + 1}
                    </div>
                  )}
                </motion.button>
              );
            })}
          </div>
        )}

        {!reveal && (
          <div className="text-center font-mono text-xs uppercase tracking-widest opacity-90">
            picked {picked.length} / 3 · {picked.length === 3 ? "revealing soon..." : "tap a card"}
          </div>
        )}

        {/* readings */}
        <AnimatePresence>
          {reveal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid md:grid-cols-3 gap-5"
            >
              {picked.map((i, idx) => {
                const c = shuffled[i];
                return (
                  <motion.div
                    key={idx}
                    initial={{ rotateY: 180, opacity: 0 }}
                    animate={{ rotateY: 0, opacity: 1 }}
                    transition={{ delay: idx * 0.4, duration: 0.7, type: "spring", stiffness: 100 }}
                    className="cute-board relative p-6 min-h-[300px] flex flex-col justify-between overflow-visible"
                    style={{ background: c.bg, color: c.fg }}
                  >
                    <span className="float-emoji text-3xl" style={{ top: -16, left: 20, filter: "none" }}>{c.emoji}</span>
                    <div>
                      <div className="font-mono text-[10px] uppercase tracking-widest opacity-80">card {idx + 1} · past · present · future</div>
                      <div className="font-display text-3xl md:text-4xl mt-2 italic" style={{ color: c.fg }}>
                        {c.name}
                      </div>
                    </div>
                    <p className="font-display text-lg md:text-xl leading-snug" style={{ color: c.fg }}>
                      "{c.reading}"
                    </p>
                    <div className="font-mono text-[10px] uppercase tracking-widest opacity-80">
                      reading by · nikhil ✦
                    </div>
                  </motion.div>
                );
              })}
              <div className="md:col-span-3 text-center mt-4">
                <button
                  onClick={reset}
                  className="px-6 py-3 rounded-full bg-cherry text-cream font-display text-base hover:bg-cream hover:text-ink transition border-2 border-cream/40"
                >
                  🔮 shuffle & re-read
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
