import { motion, AnimatePresence } from "framer-motion";
import { useRef, useState } from "react";
import Reveal from "./Reveal";

const PIN = "19";

const SECRET = [
  "you weren't supposed to see this.",
  "but since you cracked it — listen carefully.",
  "the world rewards 1% of people. they aren't smarter.",
  "they just refuse to quit when it stops being fun.",
  "stop asking permission. stop asking opinions.",
  "build in silence. show only the receipts.",
  "and when they finally clap — don't smile.",
  "you didn't do it for them.",
  "— v2.0, only for the 0.1%",
];

export default function TheVault() {
  const [val, setVal] = useState("");
  const [open, setOpen] = useState(false);
  const [shake, setShake] = useState(0);
  const [wrong, setWrong] = useState(false);
  const audioRef = useRef<AudioContext | null>(null);

  const beep = (freq: number, dur = 0.15) => {
    try {
      if (!audioRef.current) audioRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const ctx = audioRef.current!;
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "sine";
      o.frequency.setValueAtTime(freq, ctx.currentTime);
      g.gain.setValueAtTime(0.2, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
      o.connect(g).connect(ctx.destination);
      o.start();
      o.stop(ctx.currentTime + dur);
    } catch {}
  };

  const tryUnlock = () => {
    if (val === PIN) {
      beep(660, 0.2);
      setTimeout(() => beep(880, 0.3), 200);
      setOpen(true);
    } else {
      beep(180, 0.25);
      setShake((s) => s + 1);
      setWrong(true);
      setVal("");
      setTimeout(() => setWrong(false), 1500);
    }
  };

  const reset = () => {
    setOpen(false);
    setVal("");
  };

  return (
    <section className="relative py-32 px-6 bg-ink text-cream overflow-hidden">
      <span className="float-emoji text-5xl" style={{ top: 60, left: 60, filter: "none" }}>🔐</span>
      <span className="float-emoji delay-2 text-4xl" style={{ top: 100, right: 80 }}>🗝️</span>
      <span className="float-emoji delay-3 text-4xl" style={{ bottom: 80, right: 60 }}>💎</span>

      <div className="relative max-w-3xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-cream" /> classified · enter pin <span className="sparkle">🔐</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.9] mb-4">
            the <span className="italic text-cherry">vault.</span>
          </h2>
        </Reveal>

        <AnimatePresence mode="wait">
          {!open ? (
            <motion.div
              key="locked"
              animate={shake > 0 ? { x: [0, -16, 16, -10, 10, -4, 4, 0] } : {}}
              transition={{ duration: 0.45 }}
              className="cute-board bg-[#1a1820] border-cream/20 relative p-8 md:p-12 text-center"
              style={{ boxShadow: "inset 0 0 0 2px rgba(255,255,255,.1)" }}
            >
              <motion.div
                animate={{ rotate: [0, -3, 3, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="text-8xl mb-4"
              >
                🔒
              </motion.div>
              <p className="font-display text-2xl md:text-3xl mb-1">enter the 2-digit PIN</p>
              <p className="font-mono text-xs uppercase tracking-widest opacity-90 mb-6">
                hint: the age I'll make my first crore
              </p>

              <div className="flex justify-center gap-3 mb-6">
                <input
                  value={val}
                  onChange={(e) => setVal(e.target.value.replace(/\D/g, "").slice(0, 2))}
                  onKeyDown={(e) => e.key === "Enter" && tryUnlock()}
                  maxLength={2}
                  inputMode="numeric"
                  placeholder="••"
                  className="w-32 text-center px-4 py-4 rounded-2xl bg-ink border-2 border-cream/30 font-display text-4xl tracking-[0.5em] focus:outline-none focus:border-cherry text-cream placeholder:text-cream/30"
                />
                <button
                  onClick={tryUnlock}
                  className="px-6 py-4 rounded-2xl bg-cherry text-cream font-display text-xl border-2 border-cream/30 hover:bg-cream hover:text-ink transition"
                  data-cursor="hover"
                >
                  unlock 🗝️
                </button>
              </div>

              <AnimatePresence>
                {wrong && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="font-mono text-xs uppercase tracking-widest text-cherry"
                  >
                    ❌ wrong pin · the vault stays locked
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ) : (
            <motion.div
              key="open"
              initial={{ opacity: 0, scale: 0.9, rotateX: -20 }}
              animate={{ opacity: 1, scale: 1, rotateX: 0 }}
              transition={{ type: "spring", stiffness: 110, damping: 14 }}
              className="cute-board bg-[#1a1820] border-cream/20 relative p-8 md:p-12"
            >
              <span className="float-emoji text-3xl" style={{ top: -16, right: 20, filter: "none" }}>🔓</span>
              <div className="text-center mb-6">
                <div className="text-6xl mb-2">🔓</div>
                <div className="font-mono text-xs uppercase tracking-widest text-cherry">
                  ✓ vault unlocked · welcome to the 0.1%
                </div>
              </div>

              <div className="space-y-3 max-w-xl mx-auto">
                {SECRET.map((line, i) => (
                  <motion.p
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.25, duration: 0.5 }}
                    className={`font-display text-xl md:text-2xl leading-snug ${i === SECRET.length - 1 ? "italic text-cherry mt-4" : ""}`}
                  >
                    {line}
                  </motion.p>
                ))}
              </div>

              <div className="text-center mt-8">
                <button
                  onClick={reset}
                  className="px-5 py-2 rounded-full bg-cream/10 border border-cream/30 font-mono text-xs uppercase tracking-widest hover:bg-cherry hover:border-cherry transition"
                >
                  🔒 lock it back
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
