import { motion, AnimatePresence } from "framer-motion";
import { useRef, useState } from "react";
import Reveal from "./Reveal";

const doubts = [
  "you can't.",
  "be realistic kid.",
  "Kota se millionaire? lol.",
  "code seekh ke kya hoga?",
  "you're too young.",
  "your friends are doing better.",
  "you'll fail.",
  "average is safe.",
  "give up already.",
  "no one will care.",
];

const reactions = [
  "+1 doubt slapped",
  "they felt that one",
  "💀 doubt destroyed",
  "haye! wo gir gaya",
  "another one bites the dust",
  "rip doubter",
  "K.O.",
  "bro got cooked",
];

export default function SlapTheDoubter() {
  const [combo, setCombo] = useState(0);
  const [popups, setPopups] = useState<{ id: number; x: number; y: number; t: string }[]>([]);
  const [doubtIdx, setDoubtIdx] = useState(0);
  const [shake, setShake] = useState(0);
  const ctxRef = useRef<AudioContext | null>(null);

  const playSlap = () => {
    try {
      if (!ctxRef.current) ctxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const ctx = ctxRef.current!;
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "triangle";
      o.frequency.setValueAtTime(420, ctx.currentTime);
      o.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.12);
      g.gain.setValueAtTime(0.35, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
      o.connect(g).connect(ctx.destination);
      o.start();
      o.stop(ctx.currentTime + 0.2);
    } catch {}
  };

  const slap = (e: React.MouseEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = Date.now() + Math.random();
    const t = reactions[Math.floor(Math.random() * reactions.length)];
    setPopups((p) => [...p, { id, x, y, t }]);
    setCombo((c) => c + 1);
    setShake((s) => s + 1);
    setDoubtIdx((i) => (i + 1) % doubts.length);
    playSlap();
    setTimeout(() => setPopups((p) => p.filter((pp) => pp.id !== id)), 1100);
  };

  const reset = () => setCombo(0);

  // rank
  const rank =
    combo === 0 ? { label: "warm-up time", color: "bg-cream" } :
    combo < 10 ? { label: "rookie slapper", color: "bg-skyish" } :
    combo < 25 ? { label: "menace mode", color: "bg-lemon" } :
    combo < 50 ? { label: "doubt destroyer", color: "bg-pinkish" } :
    combo < 100 ? { label: "untouchable", color: "bg-cherry text-cream" } :
    { label: "millionaire energy 👑", color: "bg-ink text-cream" };

  return (
    <section className="relative py-32 px-6 bg-cream overflow-hidden">
      <span className="float-emoji text-5xl" style={{ top: 60, left: 60 }}>👊</span>
      <span className="float-emoji delay-2 text-5xl" style={{ top: 100, right: 80 }}>💥</span>
      <span className="float-emoji delay-3 text-4xl" style={{ bottom: 80, left: 100 }}>🥊</span>

      <div className="relative max-w-6xl mx-auto">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-ink" /> therapy room · slap therapy <span className="sparkle">👊</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.9] mb-4">
            slap the <span className="italic text-cherry">doubter.</span>
          </h2>
        </Reveal>
        <Reveal>
          <p className="text-base md:text-lg mb-10 max-w-xl">
            har baar koi ne bola tha "you can't"? aaja, beat it out 🥊
          </p>
        </Reveal>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* punching bag */}
          <motion.div
            key={shake}
            animate={shake > 0 ? { x: [0, -10, 12, -8, 6, -3, 0], rotate: [0, -3, 4, -2, 0] } : {}}
            transition={{ duration: 0.5 }}
            onClick={slap}
            className="lg:col-span-2 cute-board bg-cherry relative h-[460px] cursor-pointer overflow-hidden flex items-center justify-center select-none"
            data-cursor="hover"
          >
            <span className="float-emoji text-3xl" style={{ top: -14, left: 20 }}>💢</span>
            <span className="float-emoji delay-2 text-3xl" style={{ top: -14, right: 20 }}>💢</span>

            {/* the doubter */}
            <div className="text-center px-6">
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-[120px] md:text-[180px] mb-4 select-none"
              >
                🤡
              </motion.div>
              <AnimatePresence mode="wait">
                <motion.div
                  key={doubtIdx}
                  initial={{ opacity: 0, scale: 0.7 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.3 }}
                  transition={{ duration: 0.3 }}
                  className="font-display text-3xl md:text-5xl text-cream italic"
                >
                  "{doubts[doubtIdx]}"
                </motion.div>
              </AnimatePresence>
              <p className="font-mono text-xs uppercase tracking-widest text-cream/90 mt-4">
                ☝ tap anywhere to slap
              </p>
            </div>

            <AnimatePresence>
              {popups.map((p) => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 1, scale: 0, y: 0 }}
                  animate={{ opacity: 0, scale: 1.6, y: -90 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 1 }}
                  style={{ left: p.x, top: p.y }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                >
                  <span className="font-display text-2xl text-lemon font-black drop-shadow-[3px_3px_0_#0a0a0a]">
                    {p.t}
                  </span>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>

          {/* combo + rank */}
          <div className="space-y-4">
            <div className="cute-board bg-ink text-cream relative p-6 overflow-visible">
              <span className="float-emoji text-3xl" style={{ top: -16, right: -8 }}>🔥</span>
              <div className="font-mono text-xs uppercase tracking-widest opacity-80">combo</div>
              <motion.div key={combo} initial={{ scale: 1.3 }} animate={{ scale: 1 }} className="font-display text-7xl">
                {combo}
              </motion.div>
            </div>
            <motion.div
              key={rank.label}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className={`cute-board ${rank.color} relative p-6 overflow-visible`}
            >
              <span className="float-emoji text-3xl" style={{ top: -16, left: -8 }}>👑</span>
              <div className="font-mono text-xs uppercase tracking-widest opacity-80">rank</div>
              <div className="font-display text-3xl mt-1">{rank.label}</div>
            </motion.div>
            <button
              onClick={reset}
              className="w-full bg-cream border-2 border-ink rounded-2xl py-3 font-mono text-xs uppercase tracking-widest hover:bg-cherry hover:text-cream transition"
            >
              ↻ reset combo
            </button>
            <div className="text-[11px] font-mono opacity-80 text-center">
              🔊 sound on for max therapy
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
