import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import Reveal from "./Reveal";

const events = [
  { year: "stage 01", title: "discovered the keyboard", text: "first <html> tag. small fire. addicted.", color: "bg-skyish", emoji: "⌨️" },
  { year: "stage 02", title: "vibe coding became a habit", text: "free time = building. weekends = building. nights = building.", color: "bg-pinkish", emoji: "🎧" },
  { year: "stage 03", title: "added java, then python", text: "logic clicked. now learning n8n to automate the boring parts.", color: "bg-lemon", emoji: "🐍" },
  { year: "stage 04", title: "game dev experiment", text: "depends on the mood. some days unity, some days web. always something.", color: "bg-cherry", textC: "text-cream", emoji: "🎮" },
  { year: "stage 05", title: "millionaire by 19", text: "loading… nothing is impossible. i win definitely.", color: "bg-ink", textC: "text-cream", emoji: "👑" },
];

export default function Timeline() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const lineH = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  return (
    <section ref={ref} className="relative py-32 px-6 bg-cream overflow-hidden">
      <span className="float-emoji text-5xl" style={{ top: 60, right: 60 }}>🛤️</span>
      <span className="float-emoji delay-2 text-4xl" style={{ bottom: 100, left: 80 }}>🚀</span>
      <div className="max-w-6xl mx-auto relative">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-ink" /> the road so far <span className="sparkle">🛣️</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.9] mb-16">
            no shortcuts. <br />
            <span className="italic text-cherry">just stages.</span> 🪜
          </h2>
        </Reveal>

        <div className="relative pl-8 md:pl-0">
          {/* spine */}
          <div className="absolute left-3 md:left-1/2 top-0 bottom-0 w-px bg-ink/15" />
          <motion.div
            style={{ height: lineH }}
            className="absolute left-3 md:left-1/2 top-0 w-px bg-cherry origin-top"
          />

          <div className="space-y-16">
            {events.map((e, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 60 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.7 }}
                className={`relative md:grid md:grid-cols-2 md:gap-12 ${i % 2 === 0 ? "" : "md:[&>*:first-child]:order-2"}`}
              >
                <motion.div
                  className="absolute left-3 md:left-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-cherry ring-4 ring-cream flex items-center justify-center text-base shadow-lg"
                  whileInView={{ scale: [0, 1.3, 1] }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                >
                  {e.emoji}
                </motion.div>
                <div className={`${i % 2 === 0 ? "md:text-right md:pr-12" : "md:pl-12 md:col-start-2"} pl-8 md:pl-0`}>
                  <motion.div
                    whileHover={{ y: -6, scale: 1.02 }}
                    className={`cute-board ${e.color} ${e.textC || "text-ink"} relative inline-block p-6 max-w-md text-left`}
                  >
                    <div className="text-[11px] font-mono uppercase tracking-widest mb-3 opacity-90">★ {e.year}</div>
                    <h3 className="font-display text-3xl md:text-4xl mb-2 leading-tight">{e.title}</h3>
                    <p className="leading-relaxed">{e.text}</p>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
