import { motion } from "framer-motion";
import { useState } from "react";
import Reveal from "./Reveal";

const whispers = [
  { q: "are you okay?", a: "always. just busy becoming.", emoji: "🌙", color: "#ffc8d6" },
  { q: "why no best friend?", a: "loyalty is rare. i don't gamble on people.", emoji: "🎲", color: "#fff3a0" },
  { q: "do you sleep?", a: "yes. between 3am ideas.", emoji: "💤", color: "#c8e6ff" },
  { q: "what's your plan B?", a: "there isn't one. plan A or nothing.", emoji: "🎯", color: "#ffc8d6" },
  { q: "scared of failing?", a: "no. scared of being average. that's worse.", emoji: "🥶", color: "#fff3a0" },
  { q: "what do you want?", a: "to make my mom & dad never worry about money again.", emoji: "🩷", color: "#c8e6ff" },
];

export default function Whispers() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section className="relative py-32 px-6 bg-skyish/40 overflow-hidden">
      <span className="float-emoji text-5xl" style={{ top: 60, right: 80 }}>💭</span>
      <span className="float-emoji delay-2 text-4xl" style={{ bottom: 80, left: 60 }}>🤫</span>
      <div className="max-w-5xl mx-auto relative">
        <Reveal>
          <div className="flex items-center gap-3 mb-6 text-sm font-mono uppercase tracking-widest">
            <span className="w-8 h-px bg-ink" /> whispers — tap to hear <span className="sparkle">💌</span>
          </div>
        </Reveal>
        <Reveal>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.9] mb-4">
            questions people ask. <br />
            <span className="italic text-cherry">answers i don't usually give.</span> 🗝️
          </h2>
        </Reveal>
        <Reveal>
          <p className="text-base md:text-lg mb-12 max-w-2xl">
            tap any line below — each one is a tiny souvenir from my head. take what hits, leave what doesn't. 🎁
          </p>
        </Reveal>

        <div className="space-y-4">
          {whispers.map((w, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07 }}
              onClick={() => setOpen(open === i ? null : i)}
              className="cute-board bg-cream relative px-6 py-5 cursor-pointer overflow-visible"
              data-cursor="hover"
              whileHover={{ x: 6 }}
            >
              {/* corner emoji floater */}
              <span
                className="float-emoji"
                style={{ top: -14, right: 18, fontSize: "1.8rem" }}
              >
                {w.emoji}
              </span>
              {/* color stripe left */}
              <div
                className="absolute left-0 top-3 bottom-3 w-1.5 rounded-r-full"
                style={{ background: w.color }}
              />
              <div className="flex items-center justify-between gap-4 pl-3">
                <div className="flex items-center gap-4">
                  <span className="font-mono text-xs px-2 py-1 rounded-md bg-ink text-cream">Q · 0{i + 1}</span>
                  <span className="font-display text-2xl md:text-3xl">"{w.q}"</span>
                </div>
                <motion.span
                  animate={{ rotate: open === i ? 45 : 0, scale: open === i ? 1.3 : 1 }}
                  className="text-3xl text-cherry"
                >
                  +
                </motion.span>
              </div>
              <motion.div
                initial={false}
                animate={{ height: open === i ? "auto" : 0, opacity: open === i ? 1 : 0 }}
                transition={{ duration: 0.4, ease: [0.2, 0.9, 0.2, 1] }}
                className="overflow-hidden"
              >
                <div className="pt-4 mt-4 ml-3 border-t-2 border-dashed border-ink/20 font-display italic text-xl md:text-2xl text-cherry flex items-start gap-3">
                  <span className="text-2xl mt-1 wiggle">💭</span>
                  <span>{w.a}</span>
                </div>
                {open === i && (
                  <div className="mt-3 ml-3 text-[11px] font-mono uppercase tracking-widest text-ink/70">
                    🎁 souvenir collected · keep walking
                  </div>
                )}
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
