"use client";

import { useState } from "react";
import { useAgent } from "@/store/agent-store";
import Sidebar from "@/components/sidebar";
import ChatPanel from "@/components/chat-panel";
import { ToolsPanel, FilesPanel, SettingsModal } from "@/components/panels";

function Shell() {
  const { activeTab } = useAgent();
  const [navOpen, setNavOpen] = useState(false);

  return (
    <div className="h-dvh flex bg-zinc-950 text-zinc-100 overflow-hidden">
      <aside className="hidden md:block w-72 shrink-0">
        <Sidebar />
      </aside>

      {navOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setNavOpen(false)}
          />
          <div className="absolute left-0 top-0 bottom-0 w-72 animate-slide-in">
            <Sidebar onNavigate={() => setNavOpen(false)} />
          </div>
        </div>
      )}

      <main className="flex-1 flex flex-col min-w-0 min-h-0">
        <div className="md:hidden flex items-center gap-2 px-3 py-2 border-b border-zinc-800/80 bg-zinc-950/95">
          <button
            onClick={() => setNavOpen(true)}
            className="w-9 h-9 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-300"
          >
            ☰
          </button>
          <span className="font-black text-[14px] truncate">
            🍌 BANANA <span className="text-yellow-400">AGENT</span>
          </span>
        </div>

        <div className="flex-1 min-h-0">
          {activeTab === "tools" ? (
            <ToolsPanel />
          ) : activeTab === "files" ? (
            <FilesPanel />
          ) : (
            <ChatPanel />
          )}
        </div>
      </main>

      <SettingsModal />
    </div>
  );
}

export default function Page() {
  return <Shell />;
}
