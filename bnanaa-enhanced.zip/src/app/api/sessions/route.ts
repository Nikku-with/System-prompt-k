import { db } from "@/db";
import { sessions, messages, files, memory } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const data = await db
      .select()
      .from(sessions)
      .orderBy(desc(sessions.updatedAt))
      .limit(100);
    return Response.json(data);
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const [row] = await db
      .insert(sessions)
      .values({
        title: body.title || "New Session",
        model: body.model || "auto",
      })
      .returning();
    return Response.json(row, { status: 201 });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { id } = await req.json();
    await db.delete(messages).where(eq(messages.sessionId, id));
    await db.delete(files).where(eq(files.sessionId, id));
    await db.delete(memory).where(eq(memory.sessionId, id));
    await db.delete(sessions).where(eq(sessions.id, id));
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}
