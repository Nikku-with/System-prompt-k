import { db } from "@/db";
import { memory } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const sid = Number(url.searchParams.get("session_id"));
    if (!sid) return Response.json([]);
    const data = await db
      .select()
      .from(memory)
      .where(eq(memory.sessionId, sid))
      .orderBy(desc(memory.createdAt))
      .limit(50);
    return Response.json(data);
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const [row] = await db
      .insert(memory)
      .values({
        sessionId: body.session_id,
        key: body.key,
        value: body.value,
      })
      .returning();
    return Response.json(row, { status: 201 });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}
