import { db } from "@/db";
import { sessions, messages, files, memory } from "@/db/schema";
import { eq } from "drizzle-orm";
import { buildSystemPrompt, extractCodeBlocks, ThinkingTagSplitter } from "@/lib/prompt";
import { streamText, type ModelMessage } from "ai";
import { getModel, reasoningProviderOptions, type Provider, type ReasoningEffort } from "@/lib/ai-providers";
import { modelSupportsReasoning } from "@/lib/free-models";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const DEMO_RESPONSE = `## 🍌 Banana Agent — Connected & Ready!

Everything is working! I have your API key and I'm ready to help.

**What I can do:**
- Build full-stack apps with complete code
- 🌐 **Real live web search** with scrolling source links
- 🧠 **Real reasoning tokens** from thinking-capable free models (DeepSeek R1, GLM-4.5-Air, GPT-OSS…)
- 🕐 I always know the **current date & time**
- 100 verified tools across 9 categories

Try asking me to build something, search the web, or explain a concept!

[WIDGET:choice:Build a website,Fix my code,Search the web,3D animations,Explain a concept]

[WIDGET:copy:npm create vite@latest my-app]

\`\`\`javascript:demo.js
console.log("Banana Agent is ready! 🍌");
console.log("Time:", new Date().toLocaleString());
\`\`\`

[WIDGET:file:demo.js]`;

interface HistoryMsg {
  role: string;
  content: string;
}

function sse(obj: unknown): string {
  return `data: ${JSON.stringify(obj)}\n\n`;
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

// AI SDK v6 fullStream delta parts expose the chunk under `.text`; we fall back to
// `.delta` defensively since some provider adapters still emit the older shape.
function chunkText(part: unknown): string {
  const p = part as { text?: string; delta?: string };
  return p.text ?? p.delta ?? "";
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body)
    return Response.json({ error: "Invalid body" }, { status: 400 });

  const {
    session_id,
    message,
    api_key,
    groq_key,
    provider,
    model,
    history,
    mode,
    custom_prompt,
    memory_context,
    search_results,
    search_sources,
    reasoning_effort,
  } = body as Record<string, string> & {
    history: HistoryMsg[];
    search_sources?: {
      title: string;
      url: string;
      snippet: string;
      domain: string;
    }[];
  };

  const sid = Number(session_id);
  if (!sid || !message) {
    return Response.json(
      { error: "session_id and message required" },
      { status: 400 }
    );
  }
  const envGroq = process.env.GROQ_API_KEY || "";
  const envOr = process.env.OPENROUTER_API_KEY || "";
  const prov: Provider = provider === "groq" ? "groq" : "openrouter";
  const key = prov === "groq" ? groq_key || envGroq : api_key || envOr;
  const hasKey = Boolean(key && key.trim().length > 5);
  const chosenModel = model || (prov === "groq" ? "llama-3.1-8b-instant" : "openrouter/free");
  const nativeReasoning = hasKey && modelSupportsReasoning(prov, chosenModel);
  const effort: ReasoningEffort =
    reasoning_effort === "low" || reasoning_effort === "high" ? reasoning_effort : "medium";

  console.log(
    `[AGENT] session=${sid} msg="${message.slice(0, 40)}" key=${hasKey ? "YES" : "NO"} provider=${prov} model=${chosenModel} reasoning=${nativeReasoning}`
  );

  try {
    await db.insert(messages).values({
      sessionId: sid,
      role: "user",
      content: message,
      messageType: "text",
      metadata: {},
    });
  } catch (e) {
    console.error("[AGENT] Failed to save user message:", (e as Error).message);
  }

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const emit = (obj: unknown) => controller.enqueue(encoder.encode(sse(obj)));

      let fullContent = "";
      let reasoningText = "";
      let usage: unknown = null;
      let serverError: string | null = null;

      emit({ phase: "thinking", detail: "🧠 Reading your request…" });

      if (!hasKey) {
        emit({ phase: "reasoning", detail: "🔌 Demo mode active — add an API key in ⚙️ Settings for real generation" });
        await sleep(150);
        emit({ phase: "writing", detail: "✍️ Writing response…" });
        let accum = "";
        for (let i = 0; i < DEMO_RESPONSE.length; i++) {
          accum += DEMO_RESPONSE[i];
          if (accum.length >= 12 || i === DEMO_RESPONSE.length - 1) {
            emit({ token: accum });
            fullContent += accum;
            accum = "";
            const pause = DEMO_RESPONSE[i] === "`" ? 5 : DEMO_RESPONSE[i] === "\n" ? 15 : 2;
            await sleep(pause);
          }
        }
      } else {
        try {
          emit({
            phase: "reasoning",
            detail: nativeReasoning
              ? `💭 ${chosenModel} is thinking…`
              : `⚡ Generating with ${chosenModel}`,
          });

          const sysPrompt = buildSystemPrompt({
            mode,
            customPrompt: custom_prompt,
            memoryContext: memory_context,
            searchResults: search_results,
            nativeReasoning,
          });
          const msgs: ModelMessage[] = [{ role: "system", content: sysPrompt }];
          for (const m of history || []) {
            const role = m.role === "agent" ? "assistant" : m.role === "user" ? "user" : null;
            if (!role) continue; // drop stray system/error bubbles, never replay them to the model
            msgs.push({ role, content: m.content });
          }
          msgs.push({ role: "user", content: message });

          const aiModel = getModel({ provider: prov, model: chosenModel, apiKey: key });
          const providerOptions = reasoningProviderOptions(prov, chosenModel, effort);

          const result = streamText({
            model: aiModel,
            messages: msgs,
            temperature: 0.7,
            maxOutputTokens: prov === "groq" ? 16000 : 8000,
            ...(providerOptions ? { providerOptions } : {}),
            abortSignal: AbortSignal.timeout(110_000),
          });

          const splitter = nativeReasoning ? null : new ThinkingTagSplitter();
          let writingPhaseEmitted = false;

          for await (const part of result.fullStream) {
            if (part.type === "reasoning-delta") {
              const delta = chunkText(part);
              if (delta) {
                reasoningText += delta;
                emit({ phase: "reasoning", reasoning_token: delta });
              }
            } else if (part.type === "text-delta") {
              const delta = chunkText(part);
              if (!delta) continue;
              if (splitter) {
                const { reasoning, visible } = splitter.push(delta);
                if (reasoning) {
                  reasoningText += reasoning;
                  emit({ phase: "reasoning", reasoning_token: reasoning });
                }
                if (visible) {
                  if (!writingPhaseEmitted) {
                    writingPhaseEmitted = true;
                    emit({ phase: "writing", detail: "✍️ Writing response…" });
                  }
                  fullContent += visible;
                  emit({ token: visible });
                }
              } else {
                if (!writingPhaseEmitted) {
                  writingPhaseEmitted = true;
                  emit({ phase: "writing", detail: "✍️ Writing response…" });
                }
                fullContent += delta;
                emit({ token: delta });
              }
            } else if (part.type === "finish") {
              const u = (part as { totalUsage?: { inputTokens?: number; outputTokens?: number } })
                .totalUsage;
              if (u) usage = { prompt_tokens: u.inputTokens || 0, completion_tokens: u.outputTokens || 0 };
            } else if (part.type === "error") {
              const errPart = part as { error?: unknown };
              throw errPart.error instanceof Error ? errPart.error : new Error(String(errPart.error || "stream error"));
            }
          }

          if (splitter) {
            const { reasoning, visible } = splitter.flush();
            if (reasoning) {
              reasoningText += reasoning;
              emit({ phase: "reasoning", reasoning_token: reasoning });
            }
            if (visible) {
              fullContent += visible;
              emit({ token: visible });
            }
          }

          if (!fullContent.trim()) {
            fullContent = "_(model returned an empty response — try again or switch models in ⚙️ Settings)_";
          }
        } catch (e) {
          console.error("[AGENT] Generation error:", e);
          serverError = (e as Error).message || "Generation failed";
        }
      }

      const finalContent = serverError
        ? `## ❌ Request Failed\n\n**Error:** ${serverError}\n\n**Please try again.** If the issue persists, check your API key in ⚙️ Settings.\n\nYou can also try switching providers (Groq ↔ OpenRouter) or choosing a different model.`
        : fullContent;

      const codeBlocks = extractCodeBlocks(finalContent);
      try {
        for (const block of codeBlocks) {
          await db
            .insert(files)
            .values({
              sessionId: sid,
              filename: block.filename,
              content: block.content,
              language: block.language,
            })
            .catch(() => {});
        }
        await db.insert(messages).values({
          sessionId: sid,
          role: "agent",
          content: finalContent,
          messageType: "agent_response",
          metadata: {
            code_files: codeBlocks.map((b) => ({
              filename: b.filename,
              language: b.language,
            })),
            model_used: chosenModel,
            usage,
            mode,
            demo: !hasKey,
            sources: Array.isArray(search_sources) ? search_sources.slice(0, 50) : [],
            reasoning: reasoningText ? reasoningText.slice(0, 6000) : undefined,
          },
        });
        if (/my name is|i am |i'm |call me/i.test(message) && message.length < 200) {
          await db
            .insert(memory)
            .values({
              sessionId: sid,
              key: "user_note",
              value: message.slice(0, 180),
            })
            .catch(() => {});
        }
        await db
          .update(sessions)
          .set({ updatedAt: new Date(), title: message.substring(0, 80) })
          .where(eq(sessions.id, sid))
          .catch(() => {});
      } catch (e) {
        console.error("[AGENT] DB save error:", (e as Error).message);
      }

      emit({
        phase: serverError ? "error" : "complete",
        detail: serverError ? `❌ ${serverError}` : "✅ Done",
      });
      emit({
        complete: true,
        code_files: codeBlocks.map((b) => ({
          filename: b.filename,
          language: b.language,
        })),
        saved_files: codeBlocks.length,
        usage,
        model_used: chosenModel,
        demo: !hasKey,
        reasoning_used: Boolean(reasoningText),
      });
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
