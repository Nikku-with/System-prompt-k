import { db } from "@/db";
import { messages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const sid = Number(url.searchParams.get("session_id"));
    if (!sid) return Response.json([]);
    const data = await db
      .select()
      .from(messages)
      .where(eq(messages.sessionId, sid))
      .orderBy(asc(messages.createdAt), asc(messages.id))
      .limit(300);
    return Response.json(data);
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const [row] = await db
      .insert(messages)
      .values({
        sessionId: body.session_id,
        role: body.role,
        content: body.content,
        messageType: body.message_type || "text",
        metadata: body.metadata || {},
      })
      .returning();
    return Response.json(row, { status: 201 });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { session_id } = await req.json();
    await db.delete(messages).where(eq(messages.sessionId, session_id));
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}
