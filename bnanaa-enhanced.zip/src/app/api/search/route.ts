export const dynamic = "force-dynamic";
export const maxDuration = 60;

interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  domain: string;
}

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

function decodeEntities(s: string) {
  return s
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ")
    .trim();
}

function resolveDdgUrl(href: string): string {
  try {
    let h = href;
    if (h.startsWith("//")) h = "https:" + h;
    const u = new URL(h, "https://duckduckgo.com");
    const uddg = u.searchParams.get("uddg");
    if (uddg) return decodeURIComponent(uddg);
    return h;
  } catch {
    return href;
  }
}

function parseDdgHtml(html: string): SearchResult[] {
  const results: SearchResult[] = [];
  const linkRx =
    /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  const snipRx =
    /<a[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/a>|<td[^>]*class="result-snippet"[^>]*>([\s\S]*?)<\/td>/g;
  const snippets: string[] = [];
  let sm: RegExpExecArray | null;
  while ((sm = snipRx.exec(html)) !== null)
    snippets.push(decodeEntities(sm[1] || sm[2] || ""));

  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = linkRx.exec(html)) !== null) {
    const url = resolveDdgUrl(m[1]);
    const title = decodeEntities(m[2]);
    if (!title || !url.startsWith("http")) continue;
    let domain = "";
    try {
      domain = new URL(url).hostname.replace(/^www\./, "");
    } catch {}
    results.push({ title, url, snippet: snippets[i] || "", domain });
    i++;
  }
  return results;
}

async function ddgPage(query: string, offset: number): Promise<SearchResult[]> {
  const params = new URLSearchParams({ q: query });
  if (offset > 0) {
    params.set("s", String(offset));
    params.set("dc", String(offset + 1));
  }
  try {
    const r = await fetch(
      `https://html.duckduckgo.com/html/?${params.toString()}`,
      {
        headers: { "User-Agent": UA, Accept: "text/html" },
        signal: AbortSignal.timeout(12000),
      }
    );
    if (!r.ok) return [];
    return parseDdgHtml(await r.text());
  } catch {
    return [];
  }
}

async function ddgLite(query: string): Promise<SearchResult[]> {
  try {
    const r = await fetch(
      `https://lite.duckduckgo.com/lite/?q=${encodeURIComponent(query)}`,
      {
        headers: { "User-Agent": UA, Accept: "text/html" },
        signal: AbortSignal.timeout(12000),
      }
    );
    if (!r.ok) return [];
    const html = await r.text();
    const results: SearchResult[] = [];
    const liteRx =
      /<a[^>]*rel="nofollow"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
    let m: RegExpExecArray | null;
    while ((m = liteRx.exec(html)) !== null) {
      const url = resolveDdgUrl(m[1]);
      const title = decodeEntities(m[2]);
      if (!title || !url.startsWith("http")) continue;
      let domain = "";
      try {
        domain = new URL(url).hostname.replace(/^www\./, "");
      } catch {}
      results.push({ title, url, snippet: "", domain });
    }
    return results;
  } catch {
    return [];
  }
}

async function fetchPageText(url: string): Promise<string> {
  try {
    const r = await fetch(url, {
      headers: { "User-Agent": UA, Accept: "text/html" },
      signal: AbortSignal.timeout(8000),
      redirect: "follow",
    });
    if (!r.ok) return "";
    const ct = r.headers.get("content-type") || "";
    if (!ct.includes("html") && !ct.includes("text")) return "";
    const html = (await r.text()).slice(0, 300000);
    const text = html
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<nav[\s\S]*?<\/nav>/gi, " ")
      .replace(/<footer[\s\S]*?<\/footer>/gi, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/&\w+;|&#\d+;/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    return text.slice(0, 2000);
  } catch {
    return "";
  }
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const deep: boolean = body.deep !== false;
  const queries: string[] = (
    Array.isArray(body.queries) && body.queries.length > 0
      ? body.queries
      : [body.query]
  )
    .filter((q: unknown): q is string => typeof q === "string" && q.trim().length > 0)
    .map((q: string) => q.trim())
    .slice(0, 3);
  if (queries.length === 0)
    return Response.json({ error: "Query required" }, { status: 400 });
  const query = queries[0];

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: unknown) =>
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));
      try {
        send({ status: "connecting", detail: "Connecting to DuckDuckGo…" });

        const all: SearchResult[] = [];
        const seen = new Set<string>();

        // === Search each planned query ===
        for (let qi = 0; qi < queries.length; qi++) {
          const q = queries[qi];
          send({
            status: "querying",
            detail: `🔍 Query ${qi + 1}/${queries.length}: "${q}"`,
            query: q,
          });
          let page = await ddgPage(q, 0);
          if (page.length === 0 && qi === 0) {
            send({ status: "querying", detail: "Trying lite endpoint…" });
            page = await ddgLite(q);
          }
          let added = 0;
          for (const res of page) {
            if (seen.has(res.url)) continue;
            seen.add(res.url);
            all.push(res);
            added++;
            send({ result: res });
            await new Promise((r) => setTimeout(r, 80));
          }
          send({
            status: "found",
            detail: `"${q}" → ${added} new sources (${all.length} total)`,
          });
        }

        // === Dig deeper on first query until minimum 10 ===
        let offset = 30;
        let rounds = 0;
        while (all.length < 10 && rounds < 3) {
          send({ status: "more", detail: `Digging deeper… page ${rounds + 2}` });
          const more = await ddgPage(query, offset);
          let added = 0;
          for (const res of more) {
            if (seen.has(res.url)) continue;
            seen.add(res.url);
            all.push(res);
            added++;
            send({ result: res });
            await new Promise((r) => setTimeout(r, 70));
          }
          if (added === 0) break;
          offset += 30;
          rounds++;
        }

        send({
          status: "found",
          detail: `${all.length} sources locked — fetching page content…`,
        });

        const pageTexts: { url: string; domain: string; text: string }[] = [];
        if (deep && all.length > 0) {
          const top = all.slice(0, 4);
          for (const res of top) {
            send({ status: "fetching", detail: `📖 Reading ${res.domain}…`, fetching: res.domain });
            const text = await fetchPageText(res.url);
            if (text) {
              pageTexts.push({ url: res.url, domain: res.domain, text });
              send({ status: "fetched", detail: `✅ ${res.domain} — ${text.length} chars extracted` });
            } else {
              send({ status: "fetched", detail: `⚠️ ${res.domain} — skipped` });
            }
          }
        }

        const linkContext = all
          .map(
            (r, i) =>
              `[${i + 1}] ${r.title}\nURL: ${r.url}\n${r.snippet ? `Snippet: ${r.snippet}` : ""}`
          )
          .join("\n\n");
        const deepContext = pageTexts
          .map((p) => `=== PAGE CONTENT from ${p.domain} (${p.url}) ===\n${p.text}`)
          .join("\n\n");
        const contextText = `${linkContext}${deepContext ? `\n\n${deepContext}` : ""}`;

        send({
          done: true,
          count: all.length,
          fetched: pageTexts.length,
          context: contextText,
          sources: all,
        });
      } catch (e) {
        send({ error: (e as Error).message });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
