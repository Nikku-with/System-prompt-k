// 🍌 FREE MODEL CATALOG — June 2026
// Curated from https://openrouter.ai/collections/free-models + Groq's reasoning lineup.
// `reasoning: true` = the model natively streams reasoning/thinking tokens (no prompt hack needed).
// This list is intentionally hand-picked (not auto-fetched) so the app keeps working even if
// OpenRouter's catalog shuffles — but you can wire `fetchLiveFreeModels()` below to refresh it.

export interface ModelInfo {
  id: string; // exact id to send to the provider
  label: string; // short UI label
  desc: string; // one-liner shown in the picker
  reasoning: boolean; // supports native reasoning/thinking tokens
  context: string; // human-readable context window
  good_for: "general" | "coding" | "agentic" | "fast" | "vision";
}

export const OPENROUTER_FREE_MODELS: ModelInfo[] = [
  {
    id: "openrouter/free",
    label: "🎲 Auto (best free route)",
    desc: "OpenRouter's free-models router — auto-picks a healthy free model for you",
    reasoning: true,
    context: "varies",
    good_for: "general",
  },
  {
    id: "deepseek/deepseek-r1-0528:free",
    label: "DeepSeek R1",
    desc: "Top-tier free reasoning model — full chain-of-thought, great at math/code",
    reasoning: true,
    context: "164K",
    good_for: "agentic",
  },
  {
    id: "z-ai/glm-4.5-air:free",
    label: "GLM-4.5 Air",
    desc: "Hybrid thinking/non-thinking mode, strong agentic + tool use",
    reasoning: true,
    context: "131K",
    good_for: "agentic",
  },
  {
    id: "openai/gpt-oss-120b:free",
    label: "GPT-OSS 120B",
    desc: "OpenAI's open-weight MoE — configurable reasoning depth, full CoT access",
    reasoning: true,
    context: "131K",
    good_for: "general",
  },
  {
    id: "openai/gpt-oss-20b:free",
    label: "GPT-OSS 20B",
    desc: "Smaller, faster GPT-OSS — still reasoning-capable",
    reasoning: true,
    context: "131K",
    good_for: "fast",
  },
  {
    id: "qwen/qwen3-coder:free",
    label: "Qwen3 Coder",
    desc: "Strongest free coding model on OpenRouter — huge context",
    reasoning: false,
    context: "1M",
    good_for: "coding",
  },
  {
    id: "moonshotai/kimi-k2.6:free",
    label: "Kimi K2.6",
    desc: "Long-horizon coding + multi-agent orchestration, swarm-style execution",
    reasoning: false,
    context: "262K",
    good_for: "agentic",
  },
  {
    id: "nvidia/nemotron-3-super-120b-a12b:free",
    label: "Nemotron 3 Super",
    desc: "1M context, MoE hybrid Mamba-Transformer — multi-step reasoning & planning",
    reasoning: true,
    context: "1M",
    good_for: "agentic",
  },
  {
    id: "google/gemma-4-31b-it:free",
    label: "Gemma 4 31B",
    desc: "Google DeepMind, configurable thinking mode, strong coding + reasoning",
    reasoning: true,
    context: "262K",
    good_for: "general",
  },
  {
    id: "poolside/laguna-m.1:free",
    label: "Laguna M.1",
    desc: "Poolside's flagship coding agent — tool calling + reasoning",
    reasoning: true,
    context: "262K",
    good_for: "coding",
  },
  {
    id: "meta-llama/llama-3.3-70b-instruct:free",
    label: "Llama 3.3 70B",
    desc: "Reliable general-purpose free model, no native reasoning",
    reasoning: false,
    context: "131K",
    good_for: "general",
  },
];

export const GROQ_MODELS: ModelInfo[] = [
  {
    id: "qwen/qwen3-32b",
    label: "Qwen3 32B",
    desc: "Reasoning model on Groq's LPU — very fast thinking tokens",
    reasoning: true,
    context: "131K",
    good_for: "fast",
  },
  {
    id: "openai/gpt-oss-120b",
    label: "GPT-OSS 120B (Groq)",
    desc: "Same open model, Groq-speed inference, configurable reasoning effort",
    reasoning: true,
    context: "131K",
    good_for: "general",
  },
  {
    id: "openai/gpt-oss-20b",
    label: "GPT-OSS 20B (Groq)",
    desc: "Faster, smaller — still reasoning-capable",
    reasoning: true,
    context: "131K",
    good_for: "fast",
  },
  {
    id: "llama-3.3-70b-versatile",
    label: "Llama 3.3 70B",
    desc: "Fast general-purpose, no native reasoning",
    reasoning: false,
    context: "131K",
    good_for: "general",
  },
  {
    id: "llama-3.1-8b-instant",
    label: "Llama 3.1 8B Instant",
    desc: "Fastest option for small talk / simple answers",
    reasoning: false,
    context: "131K",
    good_for: "fast",
  },
];

export function findModel(provider: string, id: string): ModelInfo | undefined {
  const list = provider === "groq" ? GROQ_MODELS : OPENROUTER_FREE_MODELS;
  return list.find((m) => m.id === id);
}

export function modelSupportsReasoning(provider: string, id: string): boolean {
  return findModel(provider, id)?.reasoning ?? false;
}

// Optional: pull a live snapshot of OpenRouter's free models at request time.
// Not called by default (keeps the picker fast + offline-stable) — wire it into
// /api/models if you want the picker to always reflect what's free *right now*.
export async function fetchLiveFreeModels(): Promise<ModelInfo[]> {
  try {
    const r = await fetch("https://openrouter.ai/api/v1/models", {
      signal: AbortSignal.timeout(8000),
    });
    if (!r.ok) return OPENROUTER_FREE_MODELS;
    const data = await r.json();
    const models = Array.isArray(data?.data) ? data.data : [];
    return models
      .filter(
        (m: { id?: string; pricing?: { prompt?: string; completion?: string } }) =>
          typeof m.id === "string" &&
          m.id.endsWith(":free") &&
          Number(m.pricing?.prompt || 0) === 0
      )
      .map(
        (m: {
          id: string;
          name?: string;
          description?: string;
          context_length?: number;
          supported_parameters?: string[];
        }) => ({
          id: m.id,
          label: m.name || m.id,
          desc: (m.description || "").slice(0, 100),
          reasoning: Boolean(m.supported_parameters?.includes("reasoning")),
          context: m.context_length ? `${Math.round(m.context_length / 1000)}K` : "?",
          good_for: "general" as const,
        })
      );
  } catch {
    return OPENROUTER_FREE_MODELS;
  }
}
