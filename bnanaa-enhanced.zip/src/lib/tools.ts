// ✅ VERIFIED 100-TOOL REGISTRY — exactly 100 tools, grouped by category.
export interface Tool {
  id: number;
  name: string;
  icon: string;
  desc: string;
}
export interface ToolCategory {
  name: string;
  color: string;
  tools: Tool[];
}

let _id = 0;
const t = (name: string, icon: string, desc: string): Tool => ({
  id: ++_id,
  name,
  icon,
  desc,
});

export const TOOL_CATEGORIES: ToolCategory[] = [
  {
    name: "Code Generation",
    color: "#facc15",
    tools: [
      t("Full-Stack Builder", "🏗️", "Complete apps with frontend + backend"),
      t("React Component Gen", "⚛️", "Production React components"),
      t("Next.js App Gen", "▲", "App-router pages & routes"),
      t("API Designer", "🔌", "REST & GraphQL endpoints"),
      t("Database Schema Gen", "🗄️", "SQL / Drizzle / Prisma schemas"),
      t("Auth Flow Builder", "🔐", "Login, JWT, OAuth flows"),
      t("Landing Page Gen", "🛬", "High-converting landing pages"),
      t("Dashboard Builder", "📊", "Admin panels & dashboards"),
      t("CLI Tool Gen", "⌨️", "Node/Python CLI utilities"),
      t("Regex Forge", "🔣", "Build & explain regex patterns"),
      t("Algorithm Writer", "🧮", "DSA implementations"),
      t("Test Suite Gen", "🧪", "Jest / Vitest / Pytest suites"),
    ],
  },
  {
    name: "Web & 3D Design",
    color: "#a78bfa",
    tools: [
      t("3D Scene Builder", "🎮", "Three.js / R3F scenes"),
      t("Shader Lab", "🌈", "GLSL shaders & effects"),
      t("Particle Engine", "✨", "Particle systems"),
      t("GSAP Animator", "🎬", "Scroll & timeline animations"),
      t("CSS Art Studio", "🎨", "Pure-CSS art & effects"),
      t("Glassmorphism Kit", "🪟", "Glass UI styles"),
      t("Color Palette Gen", "🎭", "Harmonious palettes"),
      t("Font Pairing", "🔤", "Typography combos"),
      t("SVG Icon Maker", "🖊️", "Inline SVG icons"),
      t("Responsive Grid", "📱", "Mobile-first layouts"),
      t("Dark Mode Kit", "🌙", "Theme switching systems"),
      t("Micro-interactions", "🫧", "Hover & tap effects"),
    ],
  },
  {
    name: "Research & Web",
    color: "#34d399",
    tools: [
      t("Live Web Search", "🌐", "Real DuckDuckGo search w/ sources"),
      t("Source Ranker", "🏆", "Rank result credibility"),
      t("Docs Summarizer", "📚", "Summarize documentation"),
      t("Trend Scanner", "📈", "Tech trend analysis"),
      t("Package Finder", "📦", "Best npm/pip packages"),
      t("API Discoverer", "🔭", "Find public APIs"),
      t("Comparison Engine", "⚖️", "X vs Y deep compares"),
      t("Fact Checker", "✅", "Cross-verify claims"),
      t("Citation Builder", "🔗", "Linked source citations"),
      t("News Digest", "📰", "Latest dev news"),
    ],
  },
  {
    name: "Debugging & Quality",
    color: "#f87171",
    tools: [
      t("Bug Hunter", "🐛", "Find & fix bugs"),
      t("Stack Trace Reader", "🧾", "Decode error traces"),
      t("Performance Profiler", "⚡", "Speed optimizations"),
      t("Memory Leak Finder", "🕳️", "Detect leaks"),
      t("Security Auditor", "🛡️", "Vulnerability scan"),
      t("Code Reviewer", "👀", "PR-style reviews"),
      t("Refactor Engine", "♻️", "Clean code rewrites"),
      t("Type Fixer", "🏷️", "TypeScript error solver"),
      t("Lint Doctor", "🩺", "ESLint rule fixes"),
      t("Edge Case Finder", "🧩", "Boundary condition checks"),
    ],
  },
  {
    name: "Data & AI",
    color: "#60a5fa",
    tools: [
      t("JSON Transformer", "🔄", "Reshape JSON data"),
      t("CSV Wrangler", "📑", "Parse & convert CSV"),
      t("SQL Query Builder", "🛢️", "Complex queries & joins"),
      t("Data Visualizer", "📉", "Charts & graphs"),
      t("Prompt Engineer", "🧠", "Craft LLM prompts"),
      t("RAG Architect", "🗂️", "Retrieval pipelines"),
      t("Embedding Helper", "🧬", "Vector search setups"),
      t("ML Model Picker", "🤖", "Choose right models"),
      t("Scraper Builder", "🕷️", "Web scraping scripts"),
      t("ETL Pipeline Gen", "🚰", "Extract-transform-load"),
    ],
  },
  {
    name: "DevOps & Deploy",
    color: "#fb923c",
    tools: [
      t("Dockerfile Gen", "🐳", "Container configs"),
      t("CI/CD Pipeline", "🔁", "GitHub Actions workflows"),
      t("Vercel Deployer", "▲", "Vercel configs"),
      t("Nginx Config", "🚦", "Reverse proxy setups"),
      t("Env Manager", "🔑", "Environment variables"),
      t("Monitoring Setup", "📡", "Logs & alerts"),
      t("Load Balancer", "🏗️", "Scaling strategies"),
      t("SSL Helper", "🔒", "HTTPS certificates"),
      t("Cron Scheduler", "⏰", "Scheduled jobs"),
      t("Backup Strategy", "💾", "Data backup plans"),
    ],
  },
  {
    name: "Content & Docs",
    color: "#e879f9",
    tools: [
      t("README Writer", "📖", "Beautiful READMEs"),
      t("API Docs Gen", "📜", "OpenAPI / Swagger docs"),
      t("Changelog Builder", "🗒️", "Release notes"),
      t("Tutorial Writer", "🎓", "Step-by-step guides"),
      t("Comment Generator", "💬", "Code documentation"),
      t("Blog Post Writer", "✍️", "Technical articles"),
      t("Email Composer", "📧", "Professional emails"),
      t("Pitch Deck Helper", "🎤", "Startup pitches"),
      t("Naming Wizard", "🏷️", "Project & variable names"),
      t("Translation Helper", "🌍", "i18n & l10n"),
    ],
  },
  {
    name: "Productivity Widgets",
    color: "#2dd4bf",
    tools: [
      t("Multi-Select Choice", "☑️", "Pick many options at once"),
      t("Custom Answer Input", "✏️", "Type your own option"),
      t("Copy-to-Clipboard", "📋", "One-tap copy cards"),
      t("File Download Card", "⬇️", "Download generated files"),
      t("Progress Tracker", "📶", "Live progress bars"),
      t("Interactive Checklist", "✔️", "Tickable task lists"),
      t("Data Table", "🧮", "Sortable tables"),
      t("Bar Chart Widget", "📊", "Inline charts"),
      t("Timeline Widget", "🛤️", "Step timelines"),
      t("Stat Cards", "🔢", "Metric displays"),
      t("Alert Banners", "🚨", "Info/warn/error notes"),
      t("Color Swatches", "🎨", "Clickable color chips"),
      t("Rating Stars", "⭐", "Star ratings"),
      t("Toggle Switch", "🎚️", "On/off states"),
      t("Badge Maker", "🏅", "Status badges"),
      t("Link Cards", "🔗", "Rich link previews"),
    ],
  },
  {
    name: "Utilities",
    color: "#94a3b8",
    tools: [
      t("Realtime Clock", "🕐", "Live date & time awareness"),
      t("Session Memory", "🧠", "Remembers context"),
      t("Token Counter", "🪙", "Usage tracking"),
      t("UUID Generator", "🆔", "Unique IDs"),
      t("Hash Calculator", "#️⃣", "MD5/SHA hashing"),
      t("Base64 Codec", "🔡", "Encode / decode"),
      t("JWT Decoder", "🎫", "Inspect tokens"),
      t("Markdown Renderer", "Ⓜ️", "Rich text formatting"),
      t("Diff Viewer", "↔️", "Compare code versions"),
      t("Unit Converter", "📏", "Sizes, times, bytes"),
    ],
  },
];

export const ALL_TOOLS: Tool[] = TOOL_CATEGORIES.flatMap((c) => c.tools);
export const TOOL_COUNT = ALL_TOOLS.length; // === 100, verified by check below

// Compile-time-ish sanity check used by the UI badge
export const TOOLS_VERIFIED = TOOL_COUNT === 100;
