"use client";

import { useState, useRef, useEffect, type ReactNode } from "react";
import { copyText, downloadFile } from "@/lib/client-utils";
import Widget, { type CodeBlockData } from "./widgets";
import { useAgent } from "@/store/agent-store";

const RUNNABLE = new Set([
  "javascript", "js", "typescript", "ts", "python", "py", "bash", "sh",
  "c", "cpp", "c++", "java", "go", "rust", "ruby", "php",
]);

interface TermLine {
  kind: "info" | "out" | "err" | "fix";
  text: string;
}

/* ---------- Live terminal panel (Piston execution + self-correction) ---------- */
function RunPanel({ block }: { block: CodeBlockData }) {
  const { settings } = useAgent();
  const [lines, setLines] = useState<TermLine[]>([]);
  const [running, setRunning] = useState(false);
  const [open, setOpen] = useState(false);
  const [fixedCode, setFixedCode] = useState<string | null>(null);
  const termRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    termRef.current?.scrollTo({ top: termRef.current.scrollHeight });
  }, [lines]);

  const run = async () => {
    setRunning(true);
    setOpen(true);
    setLines([{ kind: "info", text: `$ run ${block.filename}` }]);
    setFixedCode(null);
    try {
      const r = await fetch("/api/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: fixedCode || block.content,
          language: block.language,
          auto_fix: true,
          api_key: settings.apiKey,
          groq_key: settings.groqKey,
          provider: settings.provider,
          model: settings.model,
        }),
      });
      if (!r.ok || !r.body) throw new Error("execute failed");
      const reader = r.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const ls = buf.split("\n");
        buf = ls.pop() || "";
        for (const line of ls) {
          if (!line.startsWith("data: ")) continue;
          try {
            const d = JSON.parse(line.slice(6));
            if (d.status && d.detail)
              setLines((p) => [...p, { kind: d.status === "fixing" ? "fix" : "info", text: d.detail }]);
            if (d.result) {
              if (d.result.stdout)
                setLines((p) => [...p, { kind: "out", text: d.result.stdout }]);
              if (d.result.stderr)
                setLines((p) => [...p, { kind: "err", text: d.result.stderr }]);
              setLines((p) => [
                ...p,
                {
                  kind: d.result.ok ? "info" : "err",
                  text: d.result.ok
                    ? `✓ exit 0 (attempt ${d.result.attempt})`
                    : `✗ exit ${d.result.exitCode ?? "?"} (attempt ${d.result.attempt})`,
                },
              ]);
            }
            if (d.fixed_code) {
              setFixedCode(d.fixed_code);
              setLines((p) => [...p, { kind: "fix", text: "🔧 AI fixed the code — re-running…" }]);
            }
            if (d.done)
              setLines((p) => [
                ...p,
                {
                  kind: d.ok ? "info" : "err",
                  text: d.ok
                    ? `✅ Success in ${d.attempts} attempt${d.attempts > 1 ? "s (self-corrected)" : ""}`
                    : `❌ Failed after ${d.attempts} attempt(s)`,
                },
              ]);
            if (d.error) setLines((p) => [...p, { kind: "err", text: d.error }]);
          } catch {}
        }
      }
    } catch (e) {
      setLines((p) => [...p, { kind: "err", text: (e as Error).message }]);
    } finally {
      setRunning(false);
    }
  };

  return (
    <>
      <button
        onClick={run}
        disabled={running}
        className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all active:scale-95 ${
          running
            ? "bg-emerald-500/20 text-emerald-300 animate-pulse"
            : "bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/35"
        }`}
      >
        {running ? "⏳ Running…" : "▶ Run"}
      </button>
      {open && (
        <TerminalOut lines={lines} termRef={termRef} fixedCode={fixedCode} onClose={() => setOpen(false)} />
      )}
    </>
  );
}

function TerminalOut({
  lines,
  termRef,
  fixedCode,
  onClose,
}: {
  lines: TermLine[];
  termRef: React.RefObject<HTMLDivElement | null>;
  fixedCode: string | null;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-x-3 bottom-20 sm:absolute sm:inset-x-0 sm:bottom-auto sm:top-full sm:mt-1 z-20 rounded-xl border border-emerald-500/30 bg-black/95 shadow-2xl overflow-hidden animate-slide-in">
      <div className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border-b border-zinc-800">
        <span className="text-[10px] font-black tracking-widest text-emerald-300 uppercase">
          ⬛ Terminal — Piston sandbox
        </span>
        {fixedCode && (
          <span className="text-[9px] px-1.5 rounded-full bg-amber-500/20 text-amber-300 font-bold">
            🔧 self-corrected
          </span>
        )}
        <button onClick={onClose} className="ml-auto text-zinc-500 hover:text-zinc-200 text-[12px]">
          ✕
        </button>
      </div>
      <div ref={termRef} className="max-h-48 overflow-y-auto scroll-thin p-2.5 font-mono text-[11.5px] leading-relaxed space-y-0.5">
        {lines.map((l, i) => (
          <div
            key={i}
            className={`whitespace-pre-wrap break-words ${
              l.kind === "err"
                ? "text-red-300"
                : l.kind === "fix"
                  ? "text-amber-300"
                  : l.kind === "out"
                    ? "text-zinc-200"
                    : "text-emerald-400"
            }`}
          >
            {l.text}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Thinking process collapsible (CoT) ---------- */
export function ThinkingBox({ text, live }: { text: string; live?: boolean }) {
  const [open, setOpen] = useState(Boolean(live));
  useEffect(() => {
    if (!live) setOpen(false);
  }, [live]);
  return (
    <div className="my-2 rounded-xl border border-violet-500/25 bg-violet-950/20 overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-violet-500/10 transition-colors"
      >
        <span className={live ? "animate-pulse" : ""}>💭</span>
        <span className="text-[10px] font-black tracking-widest text-violet-300 uppercase">
          Thinking Process{live ? "…" : ""}
        </span>
        {live && (
          <span className="flex gap-0.5">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="w-1 h-1 rounded-full bg-violet-400 animate-bounce"
                style={{ animationDelay: `${i * 0.15}s` }}
              />
            ))}
          </span>
        )}
        <span className="ml-auto text-[10px] text-violet-400">{open ? "▲" : "▼"}</span>
      </button>
      {open && (
        <div className="px-3.5 pb-2.5 pt-1 text-[12px] text-violet-200/90 leading-relaxed whitespace-pre-wrap font-mono border-t border-violet-500/15">
          {text.trim()}
        </div>
      )}
    </div>
  );
}

/* ---------- Code block with working Copy + Download ---------- */
export function CodeBlock({ block }: { block: CodeBlockData }) {
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  return (
    <div className="my-2.5 rounded-xl border border-zinc-700/80 bg-[#0d0d10] relative">
      <div className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border-b border-zinc-800 rounded-t-xl">
        <span className="flex gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
          <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
          <span className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
        </span>
        <span className="text-[11px] font-mono text-zinc-400 truncate">
          {block.filename}
        </span>
        <span className="text-[10px] px-1.5 rounded bg-zinc-800 text-zinc-500">
          {block.language}
        </span>
        <div className="ml-auto flex gap-1.5">
          {RUNNABLE.has(block.language.toLowerCase()) && <RunPanel block={block} />}
          <button
            onClick={async () => {
              if (await copyText(block.content)) {
                setCopied(true);
                setTimeout(() => setCopied(false), 1600);
              }
            }}
            className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all active:scale-95 ${
              copied
                ? "bg-emerald-500/20 text-emerald-300"
                : "bg-zinc-800 text-zinc-300 hover:bg-zinc-700"
            }`}
          >
            {copied ? "✓ Copied" : "📋 Copy"}
          </button>
          <button
            onClick={() => {
              if (downloadFile(block.filename, block.content)) {
                setSaved(true);
                setTimeout(() => setSaved(false), 1600);
              }
            }}
            className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all active:scale-95 ${
              saved
                ? "bg-emerald-500/20 text-emerald-300"
                : "bg-zinc-800 text-zinc-300 hover:bg-zinc-700"
            }`}
          >
            {saved ? "✓ Saved" : "⬇ Download"}
          </button>
        </div>
      </div>
      <pre className="p-3 overflow-x-auto scroll-thin text-[12.5px] leading-relaxed text-zinc-200 font-mono max-h-96 overflow-y-auto">
        <code>{block.content}</code>
      </pre>
    </div>
  );
}

/* ---------- inline markdown ---------- */
function inline(text: string): ReactNode[] {
  const out: ReactNode[] = [];
  // **bold**, `code`, [text](url)
  const rx = /(\*\*([^*]+)\*\*)|(`([^`]+)`)|(\[([^\]]+)\]\((https?:\/\/[^)]+)\))/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let k = 0;
  while ((m = rx.exec(text)) !== null) {
    if (m.index > last) out.push(text.slice(last, m.index));
    if (m[2])
      out.push(
        <strong key={k++} className="font-bold text-zinc-50">
          {m[2]}
        </strong>
      );
    else if (m[4])
      out.push(
        <code
          key={k++}
          className="px-1 py-0.5 rounded bg-zinc-800 text-yellow-300 font-mono text-[0.9em]"
        >
          {m[4]}
        </code>
      );
    else if (m[6])
      out.push(
        <a
          key={k++}
          href={m[7]}
          target="_blank"
          rel="noopener noreferrer"
          className="text-yellow-400 underline underline-offset-2 hover:text-yellow-300"
        >
          {m[6]}
        </a>
      );
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function MdText({ text }: { text: string }) {
  const lines = text.split("\n");
  const out: ReactNode[] = [];
  let k = 0;
  for (const line of lines) {
    const t = line.trimEnd();
    if (!t.trim()) continue;
    if (t.startsWith("### "))
      out.push(
        <h4 key={k++} className="text-[14px] font-bold text-yellow-200 mt-3 mb-1">
          {inline(t.slice(4))}
        </h4>
      );
    else if (t.startsWith("## "))
      out.push(
        <h3 key={k++} className="text-[16px] font-extrabold text-yellow-300 mt-3 mb-1">
          {inline(t.slice(3))}
        </h3>
      );
    else if (t.startsWith("# "))
      out.push(
        <h2 key={k++} className="text-[18px] font-black text-yellow-300 mt-3 mb-1.5">
          {inline(t.slice(2))}
        </h2>
      );
    else if (/^[-*]\s+/.test(t))
      out.push(
        <div key={k++} className="flex gap-2 pl-1 my-0.5">
          <span className="text-yellow-500 shrink-0">•</span>
          <span>{inline(t.replace(/^[-*]\s+/, ""))}</span>
        </div>
      );
    else if (/^\d+\.\s+/.test(t)) {
      const num = t.match(/^(\d+)\./)?.[1];
      out.push(
        <div key={k++} className="flex gap-2 pl-1 my-0.5">
          <span className="text-yellow-500 font-bold shrink-0">{num}.</span>
          <span>{inline(t.replace(/^\d+\.\s+/, ""))}</span>
        </div>
      );
    } else
      out.push(
        <p key={k++} className="my-1">
          {inline(t)}
        </p>
      );
  }
  return <>{out}</>;
}

/* ---------- Segment parser: thinking | text | code | widget ---------- */
type Segment =
  | { type: "text"; text: string }
  | { type: "code"; block: CodeBlockData }
  | { type: "widget"; kind: string; params: string }
  | { type: "thinking"; text: string; open: boolean };

export function parseSegments(rawContent: string): {
  segments: Segment[];
  codeBlocks: CodeBlockData[];
} {
  const segments: Segment[] = [];
  const codeBlocks: CodeBlockData[] = [];

  // Extract <thinking>...</thinking> blocks (CoT). Unclosed tag = still streaming.
  const thinkBlocks: { text: string; open: boolean }[] = [];
  let content = "";
  {
    const rx = /<thinking>([\s\S]*?)(<\/thinking>|$)/g;
    let last = 0;
    let m: RegExpExecArray | null;
    while ((m = rx.exec(rawContent)) !== null) {
      content += rawContent.slice(last, m.index);
      const closed = m[2] === "</thinking>";
      const text = m[1].trim();
      if (text) {
        thinkBlocks.push({ text, open: !closed });
        content += `\u0001THINK${thinkBlocks.length - 1}\u0001`;
      }
      last = m.index + m[0].length;
    }
    content += rawContent.slice(last);
  }
  const codeRx = /```([\w+#.-]*):?([^\n]*)\n([\s\S]*?)(```|$)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let fileIdx = 1;

  const pushText = (text: string) => {
    // split out widgets + thinking markers from text
    const wrx =
      /\[WIDGET:([\w_]+):([^\]]*)\]|\[WIDGET:([\w_]+)\]|\u0001THINK(\d+)\u0001/g;
    let l = 0;
    let wm: RegExpExecArray | null;
    while ((wm = wrx.exec(text)) !== null) {
      if (wm.index > l) {
        const t = text.slice(l, wm.index);
        if (t.trim()) segments.push({ type: "text", text: t });
      }
      if (wm[4] !== undefined) {
        const tb = thinkBlocks[Number(wm[4])];
        if (tb) segments.push({ type: "thinking", text: tb.text, open: tb.open });
      } else {
        segments.push({
          type: "widget",
          kind: wm[1] || wm[3],
          params: wm[2] || "",
        });
      }
      l = wm.index + wm[0].length;
    }
    if (l < text.length) {
      const t = text.slice(l);
      if (t.trim()) segments.push({ type: "text", text: t });
    }
  };

  while ((m = codeRx.exec(content)) !== null) {
    if (m.index > last) pushText(content.slice(last, m.index));
    let lang = m[1] || "text";
    let fname = (m[2] || "").trim();
    const code = (m[3] || "").trimEnd();
    const lm: Record<string, string> = {
      js: "javascript",
      ts: "typescript",
      py: "python",
      jsx: "javascript",
      tsx: "typescript",
    };
    lang = lm[lang] || lang;
    if (!fname) {
      const em: Record<string, string> = {
        javascript: "js",
        typescript: "ts",
        python: "py",
        html: "html",
        css: "css",
        json: "json",
        bash: "sh",
      };
      fname = `file${fileIdx++}.${em[lang] || "txt"}`;
    }
    const block = { filename: fname, language: lang, content: code };
    codeBlocks.push(block);
    segments.push({ type: "code", block });
    last = m.index + m[0].length;
  }
  if (last < content.length) pushText(content.slice(last));
  return { segments, codeBlocks };
}

export default function Markdown({
  content,
  streaming = false,
}: {
  content: string;
  streaming?: boolean;
}) {
  const { segments, codeBlocks } = parseSegments(content);
  return (
    <div className="text-[13.5px] leading-relaxed text-zinc-200">
      {segments.map((s, i) => {
        if (s.type === "thinking")
          return <ThinkingBox key={i} text={s.text} live={s.open && streaming} />;
        if (s.type === "code") return <CodeBlock key={i} block={s.block} />;
        if (s.type === "widget")
          return streaming ? (
            <div
              key={i}
              className="my-2 h-10 rounded-xl bg-zinc-800/60 animate-shimmer-bg"
            />
          ) : (
            <Widget key={i} kind={s.kind} params={s.params} codeBlocks={codeBlocks} />
          );
        return <MdText key={i} text={s.text} />;
      })}
    </div>
  );
}
