"use client";

import { useEffect, useState } from "react";
import { useAgent } from "@/store/agent-store";
import { TOOL_COUNT, TOOLS_VERIFIED } from "@/lib/tools";

function LiveClock() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  if (!now) return <div className="h-9" />;
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 px-3 py-2">
      <div className="text-[15px] font-mono font-bold text-yellow-300 tabular-nums">
        {now.toLocaleTimeString("en-IN", { hour12: false })}
      </div>
      <div className="text-[10px] text-zinc-500">
        {now.toLocaleDateString("en-IN", {
          weekday: "short",
          day: "numeric",
          month: "short",
          year: "numeric",
        })}{" "}
        · IST · AI sees this live 🕐
      </div>
    </div>
  );
}

export default function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const {
    sessions,
    currentSession,
    selectSession,
    createSession,
    deleteSession,
    setShowSettings,
    activeTab,
    setActiveTab,
    totalTokens,
    loading,
    phase,
    hasKey,
    settings,
  } = useAgent();

  const tabs = [
    { id: "chat", label: "💬 Chat" },
    { id: "tools", label: `🧰 Tools` },
    { id: "files", label: "📁 Files" },
  ];

  return (
    <div className="flex flex-col h-full bg-zinc-950 border-r border-zinc-800/80">
      <div className="flex items-center gap-2.5 px-4 py-3.5 border-b border-zinc-800/80">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center text-lg shadow-[0_0_16px_rgba(250,204,21,0.3)]">
          🍌
        </div>
        <div className="min-w-0">
          <div className="font-black text-[15px] tracking-wide text-zinc-100 leading-none">
            BANANA <span className="text-yellow-400">AGENT</span>
          </div>
          <div className="text-[10px] text-zinc-500 mt-0.5 truncate">
            {TOOLS_VERIFIED ? `✅ ${TOOL_COUNT}/100 tools verified` : "⚠️ tool check failed"}
          </div>
        </div>
      </div>

      <div className="p-3 space-y-2.5">
        <LiveClock />
        <button
          onClick={() => {
            createSession();
            setActiveTab("chat");
            onNavigate?.();
          }}
          className="w-full rounded-xl bg-gradient-to-r from-yellow-400 to-amber-500 text-zinc-900 font-bold text-[13px] py-2.5 hover:brightness-110 active:scale-[0.98] transition-all"
        >
          ＋ New Session
        </button>
        <div className="grid grid-cols-3 gap-1.5">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => {
                setActiveTab(t.id);
                onNavigate?.();
              }}
              className={`rounded-lg py-1.5 text-[11px] font-bold transition-all ${
                activeTab === t.id
                  ? "bg-zinc-100 text-zinc-900"
                  : "bg-zinc-800/80 text-zinc-400 hover:text-zinc-200"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scroll-thin px-3 pb-2 space-y-1">
        <div className="text-[10px] font-bold tracking-widest text-zinc-600 uppercase px-1 pb-1">
          Sessions ({sessions.length})
        </div>
        {sessions.length === 0 && (
          <div className="text-[12px] text-zinc-600 px-1">No sessions yet</div>
        )}
        {sessions.map((s) => (
          <div
            key={s.id}
            className={`group flex items-center gap-2 rounded-lg px-2.5 py-2 cursor-pointer transition-all ${
              currentSession?.id === s.id
                ? "bg-yellow-500/10 border border-yellow-500/30"
                : "hover:bg-zinc-900 border border-transparent"
            }`}
            onClick={() => {
              selectSession(s);
              setActiveTab("chat");
              onNavigate?.();
            }}
          >
            <span className="text-[12px] text-zinc-300 truncate flex-1">
              {s.title || "New Session"}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                deleteSession(s.id);
              }}
              className="opacity-0 group-hover:opacity-100 text-zinc-600 hover:text-red-400 text-[12px] transition-all px-1"
              title="Delete"
            >
              ✕
            </button>
          </div>
        ))}
      </div>

      <div className="border-t border-zinc-800/80 p-3 space-y-2">
        <div className="flex items-center gap-2 text-[11px]">
          <span
            className={`w-2 h-2 rounded-full ${
              loading ? "bg-yellow-400 animate-pulse" : "bg-emerald-500"
            }`}
          />
          <span className="text-zinc-400 capitalize">{loading ? phase : "ready"}</span>
          <span className="ml-auto font-mono text-zinc-500">
            🪙 {totalTokens.toLocaleString()}
          </span>
        </div>
        <button
          onClick={() => setShowSettings(true)}
          className="w-full flex items-center gap-2 rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-[12px] text-zinc-300 hover:border-zinc-600 transition-all"
        >
          ⚙️ Settings
          <span
            className={`ml-auto text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
              hasKey() ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-300"
            }`}
          >
            {hasKey() ? settings.provider : "demo"}
          </span>
        </button>
      </div>
    </div>
  );
}
