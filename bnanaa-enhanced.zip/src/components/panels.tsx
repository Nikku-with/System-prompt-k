"use client";

import { useState } from "react";
import { useAgent } from "@/store/agent-store";
import { TOOL_CATEGORIES, TOOL_COUNT, TOOLS_VERIFIED } from "@/lib/tools";
import { copyText, downloadFile } from "@/lib/client-utils";
import { GROQ_MODELS, OPENROUTER_FREE_MODELS, type ModelInfo } from "@/lib/free-models";
import type { ReasoningEffort } from "@/lib/ai-providers";

/* ================= TOOLS PANEL ================= */
export function ToolsPanel() {
  const [q, setQ] = useState("");
  const query = q.toLowerCase();
  return (
    <div className="h-full overflow-y-auto scroll-thin">
      <div className="max-w-4xl mx-auto px-4 py-5">
        <div className="flex items-center gap-3 flex-wrap">
          <h2 className="text-xl font-black text-zinc-100">🧰 Tool Arsenal</h2>
          <span
            className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
              TOOLS_VERIFIED
                ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30"
                : "bg-red-500/15 text-red-300"
            }`}
          >
            {TOOLS_VERIFIED ? `✅ ${TOOL_COUNT}/100 VERIFIED` : `⚠️ ${TOOL_COUNT}/100`}
          </span>
        </div>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="🔍 Search 100 tools…"
          className="mt-3 w-full max-w-sm rounded-xl bg-zinc-900 border border-zinc-700 px-3.5 py-2 text-[13px] text-zinc-100 placeholder:text-zinc-500 focus:border-yellow-500/60 focus:outline-none"
        />
        <div className="mt-5 space-y-6">
          {TOOL_CATEGORIES.map((cat) => {
            const tools = cat.tools.filter(
              (t) =>
                !query ||
                t.name.toLowerCase().includes(query) ||
                t.desc.toLowerCase().includes(query)
            );
            if (!tools.length) return null;
            return (
              <div key={cat.name}>
                <div className="flex items-center gap-2 mb-2.5">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ background: cat.color }}
                  />
                  <h3 className="text-[13px] font-bold text-zinc-200">{cat.name}</h3>
                  <span className="text-[10px] text-zinc-500 font-mono">
                    {cat.tools.length} tools
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {tools.map((t) => (
                    <div
                      key={t.id}
                      className="flex items-start gap-2.5 rounded-xl border border-zinc-800 bg-zinc-900/60 px-3 py-2.5 hover:border-zinc-600 transition-colors"
                    >
                      <span className="text-lg">{t.icon}</span>
                      <div className="min-w-0">
                        <div className="text-[12.5px] font-semibold text-zinc-100 flex items-center gap-1.5">
                          {t.name}
                          <span className="text-[9px] text-zinc-600 font-mono">
                            #{String(t.id).padStart(3, "0")}
                          </span>
                        </div>
                        <div className="text-[11px] text-zinc-500 leading-snug">{t.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ================= FILES PANEL ================= */
export function FilesPanel() {
  const { files, saveFile, deleteFile, currentSession } = useAgent();
  const [sel, setSel] = useState<number | null>(null);
  const [draft, setDraft] = useState("");
  const [flash, setFlash] = useState("");

  const file = files.find((f) => f.id === sel) || null;

  const note = (s: string) => {
    setFlash(s);
    setTimeout(() => setFlash(""), 1500);
  };

  return (
    <div className="h-full flex min-h-0">
      <div className="w-56 shrink-0 border-r border-zinc-800/80 overflow-y-auto scroll-thin p-2.5 space-y-1">
        <div className="text-[10px] font-bold tracking-widest text-zinc-600 uppercase px-1 pb-1">
          Generated Files ({files.length})
        </div>
        {!currentSession && (
          <div className="text-[11px] text-zinc-600 px-1">Open a session first</div>
        )}
        {files.map((f) => (
          <button
            key={f.id}
            onClick={() => {
              setSel(f.id);
              setDraft(f.content);
            }}
            className={`w-full text-left rounded-lg px-2.5 py-2 text-[12px] truncate transition-all ${
              sel === f.id
                ? "bg-yellow-500/10 border border-yellow-500/30 text-yellow-200"
                : "text-zinc-300 hover:bg-zinc-900 border border-transparent"
            }`}
          >
            📄 {f.filename}
          </button>
        ))}
      </div>
      <div className="flex-1 flex flex-col min-w-0">
        {file ? (
          <>
            <div className="flex items-center gap-2 px-3 py-2 border-b border-zinc-800/80 flex-wrap">
              <span className="text-[13px] font-mono text-zinc-200 truncate">
                {file.filename}
              </span>
              <span className="text-[10px] px-1.5 rounded bg-zinc-800 text-zinc-500">
                {file.language}
              </span>
              {flash && (
                <span className="text-[11px] text-emerald-300 font-bold">{flash}</span>
              )}
              <div className="ml-auto flex gap-1.5">
                <button
                  onClick={async () => (await copyText(draft)) && note("✓ Copied")}
                  className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-zinc-800 text-zinc-300 hover:bg-zinc-700 active:scale-95 transition-all"
                >
                  📋 Copy
                </button>
                <button
                  onClick={() => downloadFile(file.filename, draft) && note("✓ Downloaded")}
                  className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-zinc-800 text-zinc-300 hover:bg-zinc-700 active:scale-95 transition-all"
                >
                  ⬇ Download
                </button>
                <button
                  onClick={async () => {
                    await saveFile(file.id, draft);
                    note("✓ Saved");
                  }}
                  className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 active:scale-95 transition-all"
                >
                  💾 Save
                </button>
                <button
                  onClick={() => {
                    deleteFile(file.id);
                    setSel(null);
                  }}
                  className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-red-500/15 text-red-300 hover:bg-red-500/25 active:scale-95 transition-all"
                >
                  🗑
                </button>
              </div>
            </div>
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              spellCheck={false}
              className="flex-1 bg-[#0d0d10] font-mono text-[12.5px] text-zinc-200 p-4 resize-none outline-none scroll-thin leading-relaxed"
            />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-zinc-600 text-sm">
            ← Select a file to view / edit / download
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= SETTINGS MODAL ================= */
export function SettingsModal() {
  const { settings, setSettings, showSettings, setShowSettings } = useAgent();
  const [draft, setDraft] = useState(settings);

  if (!showSettings) return null;
  const models: ModelInfo[] = draft.provider === "groq" ? GROQ_MODELS : OPENROUTER_FREE_MODELS;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={() => setShowSettings(false)}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-zinc-700 bg-zinc-900 p-5 space-y-4 animate-slide-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-black text-zinc-100">⚙️ Settings</h2>
          <button
            onClick={() => setShowSettings(false)}
            className="text-zinc-500 hover:text-zinc-200"
          >
            ✕
          </button>
        </div>

        <div>
          <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
            Provider
          </label>
          <div className="grid grid-cols-2 gap-2 mt-1.5">
            {(["groq", "openrouter"] as const).map((p) => (
              <button
                key={p}
                onClick={() =>
                  setDraft({
                    ...draft,
                    provider: p,
                    model: p === "groq" ? GROQ_MODELS[0].id : OPENROUTER_FREE_MODELS[0].id,
                  })
                }
                className={`rounded-xl py-2.5 text-[13px] font-bold transition-all ${
                  draft.provider === p
                    ? "bg-yellow-400 text-zinc-900"
                    : "bg-zinc-800 text-zinc-400 hover:text-zinc-200"
                }`}
              >
                {p === "groq" ? "⚡ Groq (free & fast)" : "🌐 OpenRouter"}
              </button>
            ))}
          </div>
        </div>

        {draft.provider === "groq" ? (
          <div>
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
              Groq API Key{" "}
              <a
                href="https://console.groq.com/keys"
                target="_blank"
                rel="noopener noreferrer"
                className="text-yellow-400 normal-case font-normal"
              >
                (get free key ↗)
              </a>
            </label>
            <input
              type="password"
              value={draft.groqKey}
              onChange={(e) => setDraft({ ...draft, groqKey: e.target.value })}
              placeholder="gsk_…"
              className="mt-1.5 w-full rounded-xl bg-zinc-950 border border-zinc-700 px-3 py-2.5 text-[13px] text-zinc-100 focus:border-yellow-500/60 focus:outline-none font-mono"
            />
          </div>
        ) : (
          <div>
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
              OpenRouter API Key{" "}
              <a
                href="https://openrouter.ai/keys"
                target="_blank"
                rel="noopener noreferrer"
                className="text-yellow-400 normal-case font-normal"
              >
                (get key ↗)
              </a>
            </label>
            <input
              type="password"
              value={draft.apiKey}
              onChange={(e) => setDraft({ ...draft, apiKey: e.target.value })}
              placeholder="sk-or-…"
              className="mt-1.5 w-full rounded-xl bg-zinc-950 border border-zinc-700 px-3 py-2.5 text-[13px] text-zinc-100 focus:border-yellow-500/60 focus:outline-none font-mono"
            />
          </div>
        )}

        <div>
          <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
            Model
          </label>
          <div className="mt-1.5 space-y-1.5 max-h-52 overflow-y-auto pr-0.5">
            {models.map((m: ModelInfo) => {
              const active = draft.model === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => setDraft({ ...draft, model: m.id })}
                  className={`w-full text-left rounded-xl border px-3 py-2 transition-all ${
                    active
                      ? "border-yellow-400/60 bg-yellow-400/8 text-zinc-100"
                      : "border-zinc-800 bg-zinc-950 text-zinc-300 hover:border-zinc-600"
                  }`}
                >
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[12px] font-bold">{m.label}</span>
                    {m.reasoning && (
                      <span className="text-[9px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-full px-1.5 py-0">
                        🧠 THINKING
                      </span>
                    )}
                    <span
                      className={`text-[9px] font-bold rounded-full px-1.5 py-0 ml-auto ${
                        m.good_for === "coding"
                          ? "bg-blue-500/20 text-blue-300 border border-blue-500/30"
                          : m.good_for === "fast"
                            ? "bg-green-500/20 text-green-300 border border-green-500/30"
                            : m.good_for === "agentic"
                              ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                              : "bg-zinc-700/40 text-zinc-400 border border-zinc-700"
                      }`}
                    >
                      {m.good_for} · {m.context}
                    </span>
                  </div>
                  <div className="text-[10px] text-zinc-500 mt-0.5 leading-tight truncate">{m.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Reasoning Effort — only visible when a thinking-capable model is selected */}
        {(() => {
          const sel = models.find((m: ModelInfo) => m.id === draft.model);
          if (!sel?.reasoning) return null;
          return (
            <div>
              <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                Thinking Depth{" "}
                <span className="normal-case font-normal text-zinc-600">
                  (more = slower but smarter)
                </span>
              </label>
              <div className="grid grid-cols-3 gap-2 mt-1.5">
                {(["low", "medium", "high"] as ReasoningEffort[]).map((e) => (
                  <button
                    key={e}
                    onClick={() => setDraft({ ...draft, reasoningEffort: e })}
                    className={`rounded-xl py-2 text-[12px] font-bold capitalize transition-all ${
                      draft.reasoningEffort === e
                        ? e === "high"
                          ? "bg-purple-500 text-white"
                          : e === "medium"
                            ? "bg-yellow-400 text-zinc-900"
                            : "bg-zinc-600 text-zinc-100"
                        : "bg-zinc-800 text-zinc-500 hover:text-zinc-300"
                    }`}
                  >
                    {e === "low" ? "⚡ Low" : e === "medium" ? "⚖️ Medium" : "🧠 High"}
                  </button>
                ))}
              </div>
            </div>
          );
        })()}

        <div className="rounded-xl bg-zinc-950/80 border border-zinc-800 px-3 py-2.5 text-[11px] text-zinc-500 leading-relaxed">
          🔒 Keys are stored only in your browser (localStorage) and sent directly to
          your chosen provider. No key? The app runs in 🍌 demo mode.
        </div>

        <button
          onClick={() => {
            setSettings(draft);
            setShowSettings(false);
          }}
          className="w-full rounded-xl bg-gradient-to-r from-yellow-400 to-amber-500 text-zinc-900 font-bold py-2.5 hover:brightness-110 active:scale-[0.98] transition-all"
        >
          Save Settings
        </button>
      </div>
    </div>
  );
}
