export interface User {
  id: number;
  auth_id: string;
  display_name: string;
  username: string;
  anon_id: string;
  avatar_config: string;
  bio: string;
  status_emoji: string;
  chat_theme: string;
  is_online: boolean;
  created_at: string;
}

export interface Message {
  id: number;
  sender_id: number;
  sender_name: string;
  sender_avatar: string;
  content: string;
  message_type: string;
  sticker_url: string | null;
  reply_to_id: number | null;
  reply_to_content: string | null;
  reply_to_name: string | null;
  channel_id: number | null;
  group_id: number | null;
  dm_id: number | null;
  tagged_users: string;
  reactions: string;
  is_pinned: boolean;
  created_at: string;
}

export interface Group {
  id: number;
  name: string;
  description: string;
  avatar_url: string;
  created_by: number;
  is_public: boolean;
  max_members: number;
  member_count: number;
  invite_code: string;
  settings: string;
  created_at: string;
}

export interface Channel {
  id: number;
  name: string;
  description: string;
  avatar_url: string;
  created_by: number;
  is_public: boolean;
  subscriber_count: number;
  invite_code: string;
  created_at: string;
}

export interface DM {
  id: number;
  user1_id: number;
  user2_id: number;
  updated_at: string;
  created_at: string;
}

export interface AvatarConfig {
  bgColor: string;
  skinColor: string;
  hairStyle: string;
  hairColor: string;
  eyeStyle: string;
  mouthStyle: string;
  accessory: string;
  outfit: string;
  outfitColor: string;
  facialHair: string;
  blush: boolean;
  sparkles: boolean;
}

export interface ChatTheme {
  id: string;
  name: string;
  emoji: string;
  bg: string;
  ownBubble: string;
  ownText: string;
  otherBubble: string;
  otherText: string;
  accent: string;
  pattern?: string;
}
