import type { ChatTheme } from './types';

export const CHAT_THEMES: ChatTheme[] = [
  {
    id: 'midnight',
    name: 'Midnight Pro',
    emoji: '🌙',
    bg: 'linear-gradient(180deg, #0B0F19 0%, #111827 100%)',
    ownBubble: 'linear-gradient(135deg, #3B82F6, #2563EB)',
    ownText: '#ffffff',
    otherBubble: '#1F2937',
    otherText: '#E5E7EB',
    accent: '#3B82F6',
    pattern: ''
  },
  {
    id: 'charcoal',
    name: 'Charcoal Pro',
    emoji: '⚡',
    bg: 'linear-gradient(180deg, #121214 0%, #1A1A1E 100%)',
    ownBubble: 'linear-gradient(135deg, #0D9488, #0F766E)',
    ownText: '#ffffff',
    otherBubble: '#27272A',
    otherText: '#ECECED',
    accent: '#0D9488',
    pattern: ''
  },
  {
    id: 'ocean',
    name: 'Deep Ocean',
    emoji: '🌊',
    bg: 'linear-gradient(180deg, #0C1222 0%, #0F1A2E 100%)',
    ownBubble: 'linear-gradient(135deg, #06B6D4, #0891B2)',
    ownText: '#ffffff',
    otherBubble: '#162032',
    otherText: '#D1D5DB',
    accent: '#06B6D4',
    pattern: 'radial-gradient(ellipse at 20% 80%, rgba(6,182,212,0.04) 0%, transparent 50%)'
  },
  {
    id: 'rose',
    name: 'Rose Gold',
    emoji: '🌹',
    bg: 'linear-gradient(180deg, #1A0A14 0%, #1F1018 100%)',
    ownBubble: 'linear-gradient(135deg, #F43F5E, #E11D48)',
    ownText: '#ffffff',
    otherBubble: '#2A1520',
    otherText: '#FECDD3',
    accent: '#F43F5E',
    pattern: ''
  },
  {
    id: 'emerald',
    name: 'Emerald Night',
    emoji: '💚',
    bg: 'linear-gradient(180deg, #071A12 0%, #0A2018 100%)',
    ownBubble: 'linear-gradient(135deg, #10B981, #059669)',
    ownText: '#ffffff',
    otherBubble: '#122A1E',
    otherText: '#D1FAE5',
    accent: '#10B981',
    pattern: ''
  },
  {
    id: 'amber',
    name: 'Amber Glow',
    emoji: '🔥',
    bg: 'linear-gradient(180deg, #1A1408 0%, #1F1A0C 100%)',
    ownBubble: 'linear-gradient(135deg, #F59E0B, #D97706)',
    ownText: '#1A1A1A',
    otherBubble: '#2A2410',
    otherText: '#FDE68A',
    accent: '#F59E0B',
    pattern: ''
  },
  {
    id: 'purple',
    name: 'Royal Purple',
    emoji: '👑',
    bg: 'linear-gradient(180deg, #130A20 0%, #1A1030 100%)',
    ownBubble: 'linear-gradient(135deg, #8B5CF6, #7C3AED)',
    ownText: '#ffffff',
    otherBubble: '#221838',
    otherText: '#DDD6FE',
    accent: '#8B5CF6',
    pattern: ''
  },
  {
    id: 'slate',
    name: 'Slate Executive',
    emoji: '💼',
    bg: 'linear-gradient(180deg, #0F172A 0%, #1E293B 100%)',
    ownBubble: 'linear-gradient(135deg, #2563EB, #1D4ED8)',
    ownText: '#ffffff',
    otherBubble: '#334155',
    otherText: '#E2E8F0',
    accent: '#2563EB',
    pattern: ''
  },
  {
    id: 'custom',
    name: 'Custom Theme',
    emoji: '🎨',
    bg: 'linear-gradient(180deg, #0B0F19 0%, #111827 100%)',
    ownBubble: 'linear-gradient(135deg, #3B82F6, #2563EB)',
    ownText: '#ffffff',
    otherBubble: '#1F2937',
    otherText: '#E5E7EB',
    accent: '#3B82F6',
    pattern: ''
  }
];

export const getTheme = (id: string, customTheme?: ChatTheme): ChatTheme => {
  if (id === 'custom' && customTheme) return customTheme;
  return CHAT_THEMES.find(t => t.id === id) || CHAT_THEMES[0];
};