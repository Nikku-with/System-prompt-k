export const SKIN_COLORS = ['#FFE0BD', '#FFCD94', '#F5C08A', '#E8A86D', '#D49A6A', '#C68642', '#8D5524', '#6B3A1F', '#4A2511', '#FFDBB4'];
export const HAIR_COLORS = ['#2C1B18', '#4A3728', '#8B6F47', '#D4A76A', '#E8C07A', '#F5D799', '#C41E3A', '#FF69B4', '#9B59B6', '#3498DB', '#2ECC71', '#1ABC9C', '#E74C3C', '#F39C12'];
export const BG_COLORS = ['#FFB3BA', '#BAFFC9', '#BAE1FF', '#FFFFBA', '#E8BAFF', '#FFD4BA', '#BAFFEE', '#FFC9DE', '#C9BAFF', '#BAFFD4', '#FFE4E1', '#E0F0FF', '#FFF0E0', '#F0FFE0', '#FFE0F0', '#E0FFE0'];
export const OUTFIT_COLORS = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9', '#F1948A', '#82E0AA'];

export const HAIR_STYLES = [
  { id: 'short', label: '💇 Short' },
  { id: 'long', label: '👩 Long' },
  { id: 'curly', label: '🧑‍🦱 Curly' },
  { id: 'bob', label: '👱 Bob' },
  { id: 'ponytail', label: '🧔 Ponytail' },
  { id: 'pigtails', label: '🎀 Pigtails' },
  { id: 'mohawk', label: '🧑‍🎤 Mohawk' },
  { id: 'bun', label: '👩‍🎤 Bun' },
  { id: 'wavy', label: '🌊 Wavy' },
  { id: 'spiky', label: '⚡ Spiky' },
  { id: 'braids', label: '🧖 Braids' },
  { id: 'none', label: '🦲 None' },
];

export const EYE_STYLES = [
  { id: 'round', label: '👀 Round' },
  { id: 'cat', label: '😺 Cat' },
  { id: 'sparkle', label: '✨ Sparkle' },
  { id: 'sleepy', label: '😴 Sleepy' },
  { id: 'wink', label: '😉 Wink' },
  { id: 'heart', label: '😍 Heart' },
  { id: 'star', label: '🌟 Star' },
  { id: 'anime', label: '🌸 Anime' },
];

export const MOUTH_STYLES = [
  { id: 'smile', label: '😊 Smile' },
  { id: 'grin', label: '😁 Grin' },
  { id: 'cat', label: '😺 Cat' },
  { id: 'open', label: '😃 Open' },
  { id: 'pout', label: '😗 Pout' },
  { id: 'tongue', label: '😜 Tongue' },
  { id: 'neutral', label: '😐 Neutral' },
  { id: 'smirk', label: '😏 Smirk' },
];

export const ACCESSORIES = [
  { id: 'none', label: '❌ None' },
  { id: 'glasses', label: '👓 Glasses' },
  { id: 'sunglasses', label: '😎 Sunglasses' },
  { id: 'bow', label: '🎀 Bow' },
  { id: 'crown', label: '👑 Crown' },
  { id: 'headband', label: '🏵️ Headband' },
  { id: 'cat_ears', label: '🐱 Cat Ears' },
  { id: 'horns', label: '😈 Horns' },
  { id: 'halo', label: '😇 Halo' },
  { id: 'flowers', label: '🌺 Flowers' },
  { id: 'beanie', label: '🧢 Beanie' },
  { id: 'tiara', label: '👸 Tiara' },
];

export const OUTFITS = [
  { id: 'tshirt', label: '👕 T-Shirt' },
  { id: 'hoodie', label: '🧥 Hoodie' },
  { id: 'dress', label: '👗 Dress' },
  { id: 'suit', label: '👔 Suit' },
  { id: 'overalls', label: '🩲 Overalls' },
  { id: 'crop_top', label: '👙 Crop Top' },
  { id: 'sweater', label: '🧣 Sweater' },
  { id: 'tank_top', label: '🏋️ Tank Top' },
];

export const FACIAL_HAIR = [
  { id: 'none', label: '❌ None' },
  { id: 'stubble', label: '🧔 Stubble' },
  { id: 'beard', label: '🧔 Beard' },
  { id: 'mustache', label: '🥸 Mustache' },
  { id: 'goatee', label: '🧔 Goatee' },
];

export const DEFAULT_AVATAR: import('./types').AvatarConfig = {
  bgColor: '#FFB3BA',
  skinColor: '#FFE0BD',
  hairStyle: 'short',
  hairColor: '#2C1B18',
  eyeStyle: 'round',
  mouthStyle: 'smile',
  accessory: 'none',
  outfit: 'tshirt',
  outfitColor: '#FF6B6B',
  facialHair: 'none',
  blush: true,
  sparkles: true,
};
