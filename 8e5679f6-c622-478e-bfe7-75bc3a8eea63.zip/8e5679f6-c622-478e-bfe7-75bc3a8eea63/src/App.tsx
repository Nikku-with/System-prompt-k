import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import supabase from './lib/supabase';
import { handleGoogleRedirect } from './lib/googleAuth';
import type { User } from './lib/types';
import WelcomeAnimation from './components/WelcomeAnimation';
import AuthPage from './components/AuthPage';
import AccountSetup from './components/AccountSetup';
import Dashboard from './components/Dashboard';

handleGoogleRedirect();

export default function App() {
  const [appState, setAppState] = useState<'loading' | 'welcome' | 'auth' | 'setup' | 'dashboard'>('loading');
  const [authId, setAuthId] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [hasSeenWelcome, setHasSeenWelcome] = useState(false);

  useEffect(() => {
    const init = async () => {
      const seen = localStorage.getItem('cutechat_welcome_seen');
      if (seen) setHasSeenWelcome(true);

      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setAuthId(session.user.id);
        await loadUser(session.user.id, !!seen);
      } else {
        setAppState(seen ? 'auth' : 'welcome');
      }
    };

    init();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        setAuthId(session.user.id);
        await loadUser(session.user.id, true);
      } else if (event === 'SIGNED_OUT') {
        setCurrentUser(null);
        setAuthId(null);
        setAppState('auth');
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const loadUser = async (aid: string, skipWelcome: boolean) => {
    try {
      const res = await fetch(`/api/users?auth_id=${aid}`);
      if (res.ok) {
        const user = await res.json();
        if (user && user.id) {
          setCurrentUser(user);
          setAppState('dashboard');
          return;
        }
      }
      setAppState(skipWelcome ? 'setup' : 'welcome');
    } catch {
      setAppState(skipWelcome ? 'setup' : 'welcome');
    }
  };

  const handleWelcomeComplete = () => {
    localStorage.setItem('cutechat_welcome_seen', 'true');
    setHasSeenWelcome(true);
    setAppState(authId ? 'setup' : 'auth');
  };

  const handleAuth = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user) {
      setAuthId(session.user.id);
      await loadUser(session.user.id, true);
    }
  };

  const handleSetupComplete = (user: User) => {
    setCurrentUser(user);
    setAppState('dashboard');
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setCurrentUser(null);
    setAuthId(null);
    setAppState('auth');
  };

  const handleUserUpdate = (user: User) => {
    setCurrentUser(user);
  };

  if (appState === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0B0F19]">
        <div className="text-center">
          <div className="text-4xl mb-3 animate-bounce">💬</div>
          <p className="text-sm text-gray-500">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <AnimatePresence mode="wait">
      {appState === 'welcome' && <WelcomeAnimation key="welcome" onComplete={handleWelcomeComplete} />}
      {appState === 'auth' && <AuthPage key="auth" onAuth={handleAuth} />}
      {appState === 'setup' && authId && <AccountSetup key="setup" authId={authId} onComplete={handleSetupComplete} />}
      {appState === 'dashboard' && currentUser && <Dashboard key="dashboard" user={currentUser} onLogout={handleLogout} onUserUpdate={handleUserUpdate} />}
    </AnimatePresence>
  );
}
