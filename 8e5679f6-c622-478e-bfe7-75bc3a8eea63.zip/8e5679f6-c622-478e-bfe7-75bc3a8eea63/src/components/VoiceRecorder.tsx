import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, Square, Send, X, Trash2 } from 'lucide-react';

interface Props {
  onSend: (audioBlob: Blob, duration: number) => void;
  onCancel: () => void;
  accentColor: string;
}

export default function VoiceRecorder({ onSend, onCancel, accentColor }: Props) {
  const [recording, setRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const timerRef = useRef<any>(null);
  const chunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRef.current = recorder;
      chunksRef.current = [];
      recorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setAudioBlob(blob);
        stream.getTracks().forEach(t => t.stop());
      };
      recorder.start();
      setRecording(true);
      setDuration(0);
      timerRef.current = setInterval(() => setDuration(d => d + 1), 1000);
    } catch {
      alert('Microphone access needed for voice notes');
    }
  };

  const stopRecording = () => {
    if (mediaRef.current?.state === 'recording') {
      mediaRef.current.stop();
    }
    clearInterval(timerRef.current);
    setRecording(false);
  };

  const handleSend = () => {
    if (audioBlob) {
      onSend(audioBlob, duration);
      setAudioBlob(null);
      setDuration(0);
    }
  };

  useEffect(() => {
    return () => { clearInterval(timerRef.current); if (mediaRef.current?.state === 'recording') mediaRef.current.stop(); };
  }, []);

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;

  return (
    <div className="flex items-center gap-3 px-4 py-3 bg-[#111827] border-t border-gray-800">
      {!recording && !audioBlob && (
        <>
          <button onClick={onCancel} className="text-gray-500 hover:text-gray-300"><X size={18} /></button>
          <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={startRecording} className="w-12 h-12 rounded-full flex items-center justify-center text-white relative recording-pulse" style={{ background: '#EF4444' }}>
            <Mic size={20} />
          </motion.button>
          <p className="text-xs text-gray-400">Tap to record</p>
        </>
      )}

      {recording && (
        <>
          <button onClick={() => { stopRecording(); onCancel(); }} className="text-gray-500 hover:text-red-400"><Trash2 size={18} /></button>
          <div className="flex-1 flex items-center gap-3">
            <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ duration: 1, repeat: Infinity }} className="w-3 h-3 rounded-full bg-red-500" />
            <span className="text-sm font-mono text-red-400">{formatTime(duration)}</span>
            <div className="flex-1 flex gap-0.5">
              {[...Array(20)].map((_, i) => <motion.div key={i} animate={{ height: [4, 8 + Math.random() * 12, 4] }} transition={{ duration: 0.5, delay: i * 0.05, repeat: Infinity }} className="w-1 rounded-full bg-red-400/50" />)}
            </div>
          </div>
          <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={stopRecording} className="w-10 h-10 rounded-full flex items-center justify-center bg-red-500 text-white"><Square size={14} /></motion.button>
        </>
      )}

      {!recording && audioBlob && (
        <>
          <button onClick={() => { setAudioBlob(null); onCancel(); }} className="text-gray-500 hover:text-red-400"><Trash2 size={18} /></button>
          <div className="flex-1 flex items-center gap-2">
            <span className="text-sm">🎤</span>
            <span className="text-xs text-gray-300">{formatTime(duration)} voice note</span>
          </div>
          <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={handleSend} className="w-10 h-10 rounded-full flex items-center justify-center text-white" style={{ background: accentColor }}><Send size={16} /></motion.button>
        </>
      )}
    </div>
  );
}
