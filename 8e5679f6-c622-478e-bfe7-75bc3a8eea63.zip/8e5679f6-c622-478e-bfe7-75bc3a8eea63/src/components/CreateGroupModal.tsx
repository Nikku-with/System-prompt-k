import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Sparkles, Users, Megaphone, Globe, Lock } from 'lucide-react';

interface Props { type: 'group' | 'channel'; userId: number; onClose: () => void; onCreated: () => void; }

export default function CreateGroupModal({ type, userId, onClose, onCreated }: Props) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [loading, setLoading] = useState(false);

  const handleCreate = async () => {
    if (!name.trim()) return;
    setLoading(true);
    try {
      const endpoint = type === 'group' ? '/api/groups' : '/api/channels';
      const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: name.trim(), description: description.trim(), created_by: userId, is_public: isPublic }) });
      if (res.ok) onCreated();
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <motion.div initial={{ scale: 0.92, y: 20 }} animate={{ scale: 1, y: 0 }} onClick={e => e.stopPropagation()} className="w-full max-w-sm bg-[#111827] rounded-2xl border border-gray-700/50 p-5 shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">{type === 'group' ? <Users size={18} className="text-blue-400" /> : <Megaphone size={18} className="text-amber-400" />} New {type === 'group' ? 'Group' : 'Channel'}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-300"><X size={18} /></button>
        </div>
        <div className="space-y-3">
          <div><label className="text-[9px] text-gray-500 font-bold uppercase">Name</label><input value={name} onChange={e => setName(e.target.value)} placeholder={type === 'group' ? 'My Group' : 'My Channel'} className="w-full mt-1 px-3 py-2.5 rounded-xl bg-gray-800/50 border border-gray-700/50 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500/30" maxLength={30} /></div>
          <div><label className="text-[9px] text-gray-500 font-bold uppercase">Description</label><textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="What's this about?" className="w-full mt-1 px-3 py-2.5 rounded-xl bg-gray-800/50 border border-gray-700/50 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500/30 resize-none h-14" maxLength={100} /></div>
          <div className="flex gap-2">
            <button onClick={() => setIsPublic(true)} className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${isPublic ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' : 'bg-gray-800/30 text-gray-500 border-gray-700/30'}`}><Globe size={13} /> Public</button>
            <button onClick={() => setIsPublic(false)} className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${!isPublic ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-gray-800/30 text-gray-500 border-gray-700/30'}`}><Lock size={13} /> Private</button>
          </div>
          <button onClick={handleCreate} disabled={!name.trim() || loading} className="w-full py-2.5 rounded-xl bg-blue-500 hover:bg-blue-600 text-white font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-50 transition-all shadow-lg shadow-blue-500/20"><Sparkles size={14} /> Create</button>
        </div>
      </motion.div>
    </motion.div>
  );
}
