import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { User, Group } from '../lib/types';
import AvatarRenderer from './AvatarRenderer';
import { ArrowLeft, Shield, Crown, UserX, UserMinus, Volume2, VolumeX, Edit3, Save, Trash2, Clock, MessageSquare, Pin, Users, Lock, Unlock, AlertTriangle, Check, X, ChevronRight, Settings, Ban } from 'lucide-react';

interface Props {
  group: Group;
  currentUser: User;
  allUsers: User[];
  onBack: () => void;
  onUpdate: () => void;
}

interface Member {
  id: number;
  group_id: number;
  user_id: number;
  role: string;
  joined_at: string;
}

interface GroupSettings {
  group_id: number;
  slow_mode: number;
  members_can_send: boolean;
  members_can_add: boolean;
  members_can_pin: boolean;
  members_can_edit_info: boolean;
  anti_spam: boolean;
  welcome_message: string;
  rules: string;
}

type Tab = 'members' | 'permissions' | 'settings' | 'info';

export default function GroupAdmin({ group, currentUser, allUsers, onBack, onUpdate }: Props) {
  const [tab, setTab] = useState<Tab>('members');
  const [members, setMembers] = useState<Member[]>([]);
  const [settings, setSettings] = useState<GroupSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [editName, setEditName] = useState(group.name);
  const [editDesc, setEditDesc] = useState(group.description);
  const [editRules, setEditRules] = useState('');
  const [editWelcome, setEditWelcome] = useState('');
  const [saving, setSaving] = useState(false);
  const [myRole, setMyRole] = useState('member');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [mRes, sRes] = await Promise.all([
        fetch(`/api/group-members?group_id=${group.id}`),
        fetch(`/api/group-settings?group_id=${group.id}`)
      ]);
      const mData = await mRes.json();
      const sData = await sRes.json();
      setMembers(Array.isArray(mData) ? mData : []);
      setSettings(sData);
      setEditRules(sData.rules || '');
      setEditWelcome(sData.welcome_message || '');
      const me = (Array.isArray(mData) ? mData : []).find((m: Member) => m.user_id === currentUser.id);
      setMyRole(me?.role || 'member');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const isAdmin = myRole === 'owner' || myRole === 'admin';
  const isOwner = myRole === 'owner';

  const getUser = (userId: number) => allUsers.find(u => u.id === userId);

  const changeRole = async (userId: number, newRole: string) => {
    await fetch('/api/group-members', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ group_id: group.id, user_id: userId, role: newRole })
    });
    fetchData();
  };

  const kickMember = async (userId: number) => {
    await fetch('/api/group-members', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ group_id: group.id, user_id: userId })
    });
    fetchData();
    onUpdate();
  };

  const saveGroupInfo = async () => {
    setSaving(true);
    await fetch('/api/groups', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: group.id, name: editName, description: editDesc })
    });
    setSaving(false);
    onUpdate();
  };

  const saveSettings = async (updates: Partial<GroupSettings>) => {
    const newSettings = { ...settings, ...updates, group_id: group.id };
    await fetch('/api/group-settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newSettings)
    });
    setSettings(newSettings as GroupSettings);
  };

  const saveRulesAndWelcome = async () => {
    setSaving(true);
    await saveSettings({ rules: editRules, welcome_message: editWelcome });
    setSaving(false);
  };

  const deleteGroup = async () => {
    if (!confirm('Delete this group? This cannot be undone!')) return;
    await fetch('/api/groups', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: group.id })
    });
    onBack();
    onUpdate();
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'owner': return <span className="px-1.5 py-0.5 rounded-md text-[8px] font-bold bg-amber-400/20 text-amber-300">OWNER</span>;
      case 'admin': return <span className="px-1.5 py-0.5 rounded-md text-[8px] font-bold bg-sky-400/20 text-sky-300">ADMIN</span>;
      default: return null;
    }
  };

  const ToggleSwitch = ({ value, onChange, label, desc }: { value: boolean; onChange: (v: boolean) => void; label: string; desc: string }) => (
    <div className="flex items-center justify-between py-2.5">
      <div><p className="text-xs font-bold text-white/70">{label}</p><p className="text-[10px] text-white/25">{desc}</p></div>
      <button onClick={() => onChange(!value)} className={`w-10 h-5.5 rounded-full transition-all relative ${value ? 'bg-sky-400' : 'bg-white/10'}`}>
        <motion.div animate={{ x: value ? 18 : 2 }} className="absolute top-0.5 w-4.5 h-4.5 rounded-full bg-white shadow-sm" style={{ width: 18, height: 18, top: 2 }} />
      </button>
    </div>
  );

  return (
    <div className="flex-1 flex flex-col h-full" style={{ background: 'linear-gradient(160deg, #0c1929 0%, #0a1520 100%)' }}>
      <div className="flex items-center gap-3 px-4 py-3 border-b" style={{ borderColor: 'rgba(56,189,248,0.08)' }}>
        <button onClick={onBack} className="text-white/40 hover:text-white/70"><ArrowLeft size={20} /></button>
        <Settings size={18} className="text-sky-400" />
        <h2 className="text-sm font-black text-white">Group Settings</h2>
        {!isAdmin && <span className="text-[9px] text-white/20 ml-auto">View only</span>}
      </div>

      {/* Tabs */}
      <div className="flex border-b" style={{ borderColor: 'rgba(56,189,248,0.06)' }}>
        {[
          { id: 'members' as Tab, icon: <Users size={12} />, label: 'Members' },
          { id: 'permissions' as Tab, icon: <Shield size={12} />, label: 'Perms' },
          { id: 'settings' as Tab, icon: <Settings size={12} />, label: 'Settings' },
          { id: 'info' as Tab, icon: <Edit3 size={12} />, label: 'Info' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`flex-1 py-2.5 text-[10px] font-bold flex items-center justify-center gap-1 border-b-2 transition-all ${tab === t.id ? 'text-sky-400 border-sky-400' : 'text-white/20 border-transparent'}`}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {loading ? (
          <div className="flex items-center justify-center py-12"><motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity }}><Settings size={20} className="text-sky-400" /></motion.div></div>
        ) : (
          <>
            {/* MEMBERS TAB */}
            {tab === 'members' && (
              <div className="space-y-1">
                <p className="text-[10px] text-white/30 font-bold uppercase tracking-wider mb-2">{members.length} Members</p>
                {members.sort((a, b) => {
                  const order: Record<string, number> = { owner: 0, admin: 1, member: 2 };
                  return (order[a.role] || 2) - (order[b.role] || 2);
                }).map(m => {
                  const u = getUser(m.user_id);
                  if (!u) return null;
                  return (
                    <div key={m.id} className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/[0.02] transition-all group">
                      <AvatarRenderer config={u.avatar_config} size={36} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs font-bold text-white/80 truncate">{u.display_name}</p>
                          {getRoleBadge(m.role)}
                        </div>
                        <p className="text-[9px] text-sky-400/40 font-mono">@{(u as any).username || u.anon_id}</p>
                      </div>
                      {/* Admin actions */}
                      {isAdmin && m.user_id !== currentUser.id && m.role !== 'owner' && (
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all">
                          {isOwner && m.role !== 'admin' && (
                            <button onClick={() => changeRole(m.user_id, 'admin')} className="w-7 h-7 rounded-lg flex items-center justify-center text-sky-400/50 hover:text-sky-400 hover:bg-sky-400/10 transition-all" title="Make Admin">
                              <Shield size={12} />
                            </button>
                          )}
                          {isOwner && m.role === 'admin' && (
                            <button onClick={() => changeRole(m.user_id, 'member')} className="w-7 h-7 rounded-lg flex items-center justify-center text-amber-400/50 hover:text-amber-400 hover:bg-amber-400/10 transition-all" title="Remove Admin">
                              <UserMinus size={12} />
                            </button>
                          )}
                          <button onClick={() => kickMember(m.user_id)} className="w-7 h-7 rounded-lg flex items-center justify-center text-red-400/50 hover:text-red-400 hover:bg-red-400/10 transition-all" title="Kick">
                            <UserX size={12} />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* PERMISSIONS TAB */}
            {tab === 'permissions' && settings && (
              <div className="space-y-1">
                <p className="text-[10px] text-white/30 font-bold uppercase tracking-wider mb-2">Member Permissions</p>
                <div className="bg-white/[0.02] rounded-2xl p-3 border border-white/[0.03] space-y-1">
                  <ToggleSwitch value={settings.members_can_send} onChange={v => isAdmin && saveSettings({ members_can_send: v })} label="Send Messages" desc="Members can send messages" />
                  <ToggleSwitch value={settings.members_can_add} onChange={v => isAdmin && saveSettings({ members_can_add: v })} label="Add Members" desc="Members can add new people" />
                  <ToggleSwitch value={settings.members_can_pin} onChange={v => isAdmin && saveSettings({ members_can_pin: v })} label="Pin Messages" desc="Members can pin messages" />
                  <ToggleSwitch value={settings.members_can_edit_info} onChange={v => isAdmin && saveSettings({ members_can_edit_info: v })} label="Edit Group Info" desc="Members can change name & desc" />
                  <ToggleSwitch value={settings.anti_spam} onChange={v => isAdmin && saveSettings({ anti_spam: v })} label="Anti-Spam" desc="Auto-filter spam messages" />
                </div>

                <p className="text-[10px] text-white/30 font-bold uppercase tracking-wider mt-4 mb-2">Slow Mode</p>
                <div className="bg-white/[0.02] rounded-2xl p-3 border border-white/[0.03]">
                  <div className="flex gap-2 flex-wrap">
                    {[0, 10, 30, 60, 300, 900].map(s => (
                      <button key={s} onClick={() => isAdmin && saveSettings({ slow_mode: s })} className={`px-3 py-1.5 rounded-xl text-[10px] font-bold transition-all ${settings.slow_mode === s ? 'bg-sky-400/20 text-sky-300 border border-sky-400/30' : 'bg-white/[0.03] text-white/30 border border-white/[0.03]'}`}>
                        {s === 0 ? 'Off' : s < 60 ? `${s}s` : `${s / 60}m`}
                      </button>
                    ))}
                  </div>
                  <p className="text-[9px] text-white/20 mt-2"><Clock size={9} className="inline" /> Members must wait between messages</p>
                </div>
              </div>
            )}

            {/* SETTINGS TAB */}
            {tab === 'settings' && (
              <div className="space-y-4">
                <div>
                  <p className="text-[10px] text-white/30 font-bold uppercase tracking-wider mb-2">Welcome Message</p>
                  <textarea value={editWelcome} onChange={e => setEditWelcome(e.target.value)} placeholder="Message shown to new members..." disabled={!isAdmin} className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.04] text-white text-xs placeholder-white/15 focus:outline-none focus:border-sky-400/30 resize-none h-20 disabled:opacity-50 transition-all" />
                </div>
                <div>
                  <p className="text-[10px] text-white/30 font-bold uppercase tracking-wider mb-2">Group Rules</p>
                  <textarea value={editRules} onChange={e => setEditRules(e.target.value)} placeholder="Set rules for the group..." disabled={!isAdmin} className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.04] text-white text-xs placeholder-white/15 focus:outline-none focus:border-sky-400/30 resize-none h-24 disabled:opacity-50 transition-all" />
                </div>
                {isAdmin && (
                  <motion.button whileTap={{ scale: 0.98 }} onClick={saveRulesAndWelcome} disabled={saving} className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-sky-400 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-lg shadow-sky-500/20">
                    {saving ? <Settings size={13} className="animate-spin" /> : <Save size={13} />} Save
                  </motion.button>
                )}

                {isOwner && (
                  <div className="pt-4 border-t border-white/[0.04]">
                    <button onClick={deleteGroup} className="w-full py-2.5 rounded-xl bg-red-500/10 text-red-400/70 text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-red-500/15 border border-red-500/10 transition-all">
                      <Trash2 size={13} /> Delete Group
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* INFO TAB */}
            {tab === 'info' && (
              <div className="space-y-4">
                <div>
                  <p className="text-[10px] text-white/30 font-bold uppercase tracking-wider mb-2">Group Name</p>
                  <input value={editName} onChange={e => setEditName(e.target.value)} disabled={!isAdmin} className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.04] text-white text-sm font-bold focus:outline-none focus:border-sky-400/30 disabled:opacity-50 transition-all" />
                </div>
                <div>
                  <p className="text-[10px] text-white/30 font-bold uppercase tracking-wider mb-2">Description</p>
                  <textarea value={editDesc} onChange={e => setEditDesc(e.target.value)} disabled={!isAdmin} className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.04] text-white text-xs focus:outline-none focus:border-sky-400/30 resize-none h-20 disabled:opacity-50 transition-all" />
                </div>
                <div className="bg-white/[0.02] rounded-xl p-3 border border-white/[0.03] space-y-2">
                  <div className="flex justify-between text-xs"><span className="text-white/30">Visibility</span><span className="text-white/60">{group.is_public ? '🌍 Public' : '🔒 Private'}</span></div>
                  <div className="flex justify-between text-xs"><span className="text-white/30">Members</span><span className="text-white/60">{group.member_count}/{group.max_members}</span></div>
                  <div className="flex justify-between text-xs"><span className="text-white/30">Invite Code</span><span className="text-white/60 font-mono">{group.invite_code}</span></div>
                  <div className="flex justify-between text-xs"><span className="text-white/30">Created</span><span className="text-white/60">{new Date(group.created_at).toLocaleDateString()}</span></div>
                </div>
                {isAdmin && (
                  <motion.button whileTap={{ scale: 0.98 }} onClick={saveGroupInfo} disabled={saving} className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-sky-400 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-lg shadow-sky-500/20">
                    {saving ? <Settings size={13} className="animate-spin" /> : <Save size={13} />} Save Info
                  </motion.button>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
