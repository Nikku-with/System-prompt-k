import React, { useState } from 'react';
import { motion } from 'framer-motion';
import type { User, Group, Channel, DM, Message } from '../lib/types';
import AvatarRenderer from './AvatarRenderer';
import { X, Forward, Search, Check, Users, Megaphone, MessageCircle } from 'lucide-react';

interface Props {
  message: Message;
  currentUser: User;
  groups: Group[];
  channels: Channel[];
  dms: DM[];
  allUsers: User[];
  onClose: () => void;
  onForwarded: () => void;
}

export default function ForwardModal({ message, currentUser, groups, channels, dms, allUsers, onClose, onForwarded }: Props) {
  const [search, setSearch] = useState('');
  const [sending, setSending] = useState<string | null>(null);

  const forward = async (targetType: string, targetId: number) => {
    setSending(`${targetType}_${targetId}`);
    await fetch('/api/forward', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message_ids: [message.id],
        target_type: targetType,
        target_id: targetId,
        sender_id: currentUser.id,
        sender_name: currentUser.display_name,
        sender_avatar: currentUser.avatar_config
      })
    });
    setSending(null);
    onForwarded();
  };

  const getDMPartner = (dm: DM) => {
    const pid = dm.user1_id === currentUser.id ? dm.user2_id : dm.user1_id;
    return allUsers.find(u => u.id === pid);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <motion.div initial={{ scale: 0.92, y: 20 }} animate={{ scale: 1, y: 0 }} onClick={e => e.stopPropagation()} className="w-full max-w-sm bg-[#111827] rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden max-h-[70vh] flex flex-col">
        <div className="p-4 border-b border-gray-700/50 flex items-center justify-between">
          <h2 className="text-sm font-bold text-white flex items-center gap-2"><Forward size={16} className="text-blue-400" /> Forward to...</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-300"><X size={18} /></button>
        </div>

        <div className="px-4 py-2"><div className="relative"><Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="w-full pl-9 pr-3 py-2 rounded-xl bg-gray-800/50 border border-gray-700/50 text-white text-xs placeholder-gray-500 focus:outline-none" /></div></div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {/* DMs */}
          {dms.filter(dm => { const p = getDMPartner(dm); return p?.display_name.toLowerCase().includes(search.toLowerCase()); }).map(dm => {
            const partner = getDMPartner(dm);
            const key = `dm_${dm.id}`;
            return (
              <button key={key} onClick={() => forward('dm', dm.id)} className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-gray-800/50 transition-all">
                <AvatarRenderer config={partner?.avatar_config || '{}'} size={32} />
                <div className="flex-1 text-left"><p className="text-xs font-semibold text-gray-200">{partner?.display_name}</p><p className="text-[9px] text-gray-500">DM</p></div>
                {sending === key ? <Check size={14} className="text-green-400" /> : <Forward size={14} className="text-gray-600" />}
              </button>
            );
          })}
          {/* Groups */}
          {groups.filter(g => g.name.toLowerCase().includes(search.toLowerCase())).map(g => {
            const key = `group_${g.id}`;
            return (
              <button key={key} onClick={() => forward('group', g.id)} className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-gray-800/50 transition-all">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center"><Users size={14} className="text-blue-400" /></div>
                <div className="flex-1 text-left"><p className="text-xs font-semibold text-gray-200">{g.name}</p><p className="text-[9px] text-gray-500">Group</p></div>
                {sending === key ? <Check size={14} className="text-green-400" /> : <Forward size={14} className="text-gray-600" />}
              </button>
            );
          })}
          {/* Channels */}
          {channels.filter(c => c.name.toLowerCase().includes(search.toLowerCase())).map(c => {
            const key = `channel_${c.id}`;
            return (
              <button key={key} onClick={() => forward('channel', c.id)} className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-gray-800/50 transition-all">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center"><Megaphone size={14} className="text-amber-400" /></div>
                <div className="flex-1 text-left"><p className="text-xs font-semibold text-gray-200">{c.name}</p><p className="text-[9px] text-gray-500">Channel</p></div>
                {sending === key ? <Check size={14} className="text-green-400" /> : <Forward size={14} className="text-gray-600" />}
              </button>
            );
          })}
        </div>

        <div className="p-3 border-t border-gray-700/50">
          <p className="text-[10px] text-gray-500 text-center truncate">“{message.content?.substring(0, 50) || 'Media'}”</p>
        </div>
      </motion.div>
    </motion.div>
  );
}
