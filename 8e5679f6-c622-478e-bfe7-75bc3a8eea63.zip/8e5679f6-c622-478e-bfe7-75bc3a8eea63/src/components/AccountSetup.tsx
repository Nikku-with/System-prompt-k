import React, { useState } from 'react';
import { motion } from 'framer-motion';
import AvatarCreator from './AvatarCreator';
import AvatarRenderer from './AvatarRenderer';
import type { AvatarConfig } from '../lib/types';
import { DEFAULT_AVATAR } from '../lib/avatarParts';
import { Sparkles, ArrowRight, AtSign, AlertCircle, Camera } from 'lucide-react';

const STATUS_EMOJIS = ['✨', '🌸', '💖', '🌟', '🦋', '🌺', '💜', '🎀', '😎', '🫧', '🌼', '💕', '🤩', '😉', '💝', '😘', '🫠', '😊', '🌈', '🌙'];

export default function AccountSetup({ authId, onComplete }: { authId: string; onComplete: (user: any) => void }) {
  const [step, setStep] = useState(0);
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');
  const [statusEmoji, setStatusEmoji] = useState('✨');
  const [avatarConfig, setAvatarConfig] = useState<AvatarConfig>(DEFAULT_AVATAR);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    setSaving(true); setError('');
    try {
      const clean = username.toLowerCase().replace(/[^a-z0-9_]/g, '_') || undefined;
      const res = await fetch('/api/users', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ auth_id: authId, display_name: displayName || undefined, username: clean, avatar_config: JSON.stringify(avatarConfig), bio, status_emoji: statusEmoji }) });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Something went wrong'); setSaving(false); return; }
      // Create profile
      await fetch('/api/profiles', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: data.id }) });
      onComplete(data);
    } catch { setError('Network error'); } finally { setSaving(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#0B0F19]">
      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="text-center mb-5">
          <h2 className="text-xl font-bold text-white">{step === 0 ? 'Create Your Profile' : step === 1 ? 'Design Your Avatar' : 'All Set!'}</h2>
          <div className="flex gap-2 justify-center mt-3">{[0, 1, 2].map(i => <div key={i} className={`h-1 rounded-full transition-all ${i <= step ? 'w-8 bg-blue-500' : 'w-4 bg-gray-700'}`} />)}</div>
        </div>

        <div className="bg-[#111827] rounded-2xl p-5 border border-gray-800/50">
          {step === 0 && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
              <div><label className="text-[9px] text-gray-500 font-bold uppercase">Display Name</label><input value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Your name" className="w-full mt-1 px-3 py-2.5 rounded-xl bg-gray-800/50 border border-gray-700/50 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500/30" maxLength={20} /></div>
              <div><label className="text-[9px] text-gray-500 font-bold uppercase flex items-center gap-1"><AtSign size={9} /> Username</label><div className="relative mt-1"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-400/40 text-xs">@</span><input value={username} onChange={e => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))} placeholder="pick_a_username" className="w-full pl-7 pr-3 py-2.5 rounded-xl bg-gray-800/50 border border-gray-700/50 text-white text-sm font-mono placeholder-gray-500 focus:outline-none focus:border-blue-500/30" maxLength={20} /></div><p className="text-gray-600 text-[9px] mt-1">People can find you by this</p></div>
              <div><label className="text-[9px] text-gray-500 font-bold uppercase">Bio</label><textarea value={bio} onChange={e => setBio(e.target.value)} placeholder="Tell us about yourself..." className="w-full mt-1 px-3 py-2.5 rounded-xl bg-gray-800/50 border border-gray-700/50 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500/30 resize-none h-16" maxLength={150} /></div>
              <div><label className="text-[9px] text-gray-500 font-bold uppercase">Status Emoji</label><div className="flex flex-wrap gap-1.5 mt-1">{STATUS_EMOJIS.map(e => <button key={e} onClick={() => setStatusEmoji(e)} className={`w-8 h-8 rounded-lg flex items-center justify-center text-base ${statusEmoji === e ? 'bg-blue-500/20 ring-1 ring-blue-400/40' : 'bg-gray-800/30 hover:bg-gray-800/50'}`}>{e}</button>)}</div></div>
              <button onClick={() => setStep(1)} className="w-full py-2.5 rounded-xl bg-blue-500 hover:bg-blue-600 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all">Next <ArrowRight size={14} /></button>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <AvatarCreator initial={avatarConfig} onSave={c => { setAvatarConfig(c); setStep(2); }} onCancel={() => setStep(0)} />
            </motion.div>
          )}

          {step === 2 && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4 text-center">
              <AvatarRenderer config={avatarConfig} size={80} className="mx-auto" />
              <div><p className="text-white font-bold">{statusEmoji} {displayName || 'Anonymous'}</p><p className="text-blue-400/50 text-xs font-mono">@{username || 'auto-generated'}</p></div>
              {error && <p className="text-red-400 text-xs bg-red-400/8 rounded-lg py-2 flex items-center justify-center gap-1"><AlertCircle size={12} /> {error}</p>}
              <div className="flex gap-2">
                <button onClick={() => setStep(1)} className="flex-1 py-2.5 rounded-xl bg-gray-800/50 text-gray-400 text-sm font-bold">Back</button>
                <button onClick={handleSave} disabled={saving} className="flex-1 py-2.5 rounded-xl bg-blue-500 text-white text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-50">{saving ? <Sparkles size={14} className="animate-spin" /> : <><Sparkles size={14} /> Start Chatting</>}</button>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
