import React, { useState, useEffect, useCallback } from 'react';
import { AnimatePresence } from 'framer-motion';
import type { User, Group, Channel, DM, Message } from '../lib/types';
import Sidebar from './Sidebar';
import ChatView from './ChatView';
import ExplorePanel from './ExplorePanel';
import ProfilePanel from './ProfilePanel';
import CreateGroupModal from './CreateGroupModal';
import UserSearch from './UserSearch';
import ThemePicker from './ThemePicker';
import MistiiChat from './MistiiChat';
import GroupAdmin from './GroupAdmin';
import SavedMessages from './SavedMessages';
import ForwardModal from './ForwardModal';
import { MessageCircleHeart } from 'lucide-react';

interface Props { user: User; onLogout: () => void; onUserUpdate: (user: User) => void; }

export default function Dashboard({ user, onLogout, onUserUpdate }: Props) {
  const [groups, setGroups] = useState<Group[]>([]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [dms, setDms] = useState<DM[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [activeChat, setActiveChat] = useState<{ type: 'group' | 'channel' | 'dm'; id: number; data: any } | null>(null);
  const [view, setView] = useState<'chat' | 'explore' | 'profile' | 'mistii' | 'groupadmin' | 'saved'>('chat');
  const [showCreateModal, setShowCreateModal] = useState<'group' | 'channel' | null>(null);
  const [showUserSearch, setShowUserSearch] = useState(false);
  const [showThemePicker, setShowThemePicker] = useState(false);
  const [forwardMsg, setForwardMsg] = useState<Message | null>(null);
  const [mobileShowChat, setMobileShowChat] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const [gRes, cRes, dRes, uRes] = await Promise.all([
        fetch(`/api/groups?user_id=${user.id}`), fetch(`/api/channels?user_id=${user.id}`),
        fetch(`/api/dms?user_id=${user.id}`), fetch('/api/users'),
      ]);
      const [gData, cData, dData, uData] = await Promise.all([gRes.json(), cRes.json(), dRes.json(), uRes.json()]);
      setGroups(Array.isArray(gData) ? gData : []); setChannels(Array.isArray(cData) ? cData : []);
      setDms(Array.isArray(dData) ? dData : []); setAllUsers(Array.isArray(uData) ? uData : []);
    } catch (err) { console.error(err); }
  }, [user.id]);

  useEffect(() => { fetchData(); const i = setInterval(fetchData, 10000); return () => clearInterval(i); }, [fetchData]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const join = params.get('join');
    if (join) {
      window.history.replaceState({}, '', window.location.pathname);
      const isGroup = join.startsWith('g_');
      const code = join.replace(/^[gc]_/, '');
      const endpoint = isGroup ? `/api/groups?invite_code=${code}` : `/api/channels?invite_code=${code}`;
      fetch(endpoint).then(r => r.json()).then(async item => {
        if (item?.id) {
          const memberEndpoint = isGroup ? '/api/group-members' : '/api/channel-subscribers';
          const body = isGroup ? { group_id: item.id, user_id: user.id } : { channel_id: item.id, user_id: user.id };
          await fetch(memberEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
          await fetchData();
          setActiveChat({ type: isGroup ? 'group' : 'channel', id: item.id, data: item });
          setView('chat'); setMobileShowChat(true);
        }
      }).catch(() => {});
    }
  }, [user.id]);

  const handleSelectGroup = (g: Group) => { setActiveChat({ type: 'group', id: g.id, data: g }); setView('chat'); setMobileShowChat(true); };
  const handleSelectChannel = (c: Channel) => { setActiveChat({ type: 'channel', id: c.id, data: c }); setView('chat'); setMobileShowChat(true); };
  const handleSelectDM = (dm: DM) => { setActiveChat({ type: 'dm', id: dm.id, data: dm }); setView('chat'); setMobileShowChat(true); };

  const handleDM = async (targetUserId: number) => {
    if (targetUserId === user.id) return;
    const res = await fetch('/api/dms', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user1_id: user.id, user2_id: targetUserId }) });
    const dm = await res.json(); await fetchData();
    setActiveChat({ type: 'dm', id: dm.id, data: dm }); setView('chat'); setMobileShowChat(true);
  };

  const handleJoinGroup = async (gid: number) => {
    await fetch('/api/group-members', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ group_id: gid, user_id: user.id }) });
    await fetchData();
    const g = groups.find(x => x.id === gid);
    if (g) handleSelectGroup(g); else { const r = await fetch(`/api/groups?id=${gid}`); const gd = await r.json(); if (gd?.id) handleSelectGroup(gd); }
  };

  const handleSubscribeChannel = async (cid: number) => {
    await fetch('/api/channel-subscribers', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ channel_id: cid, user_id: user.id }) });
    await fetchData();
  };

  const handleSaveMessage = async (msg: Message) => {
    const chatName = activeChat?.type === 'group' ? (activeChat.data as Group).name : activeChat?.type === 'channel' ? (activeChat.data as Channel).name : 'DM';
    await fetch('/api/saved-messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
      user_id: user.id, original_msg_id: msg.id, content: msg.content, message_type: msg.message_type,
      file_url: msg.sticker_url, sender_name: msg.sender_name, source_chat: chatName
    })});
  };

  const handleThemeSelect = async (themeId: string) => {
    await fetch('/api/users', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: user.id, chat_theme: themeId }) });
    onUserUpdate({ ...user, chat_theme: themeId }); setShowThemePicker(false);
  };

  return (
    <div className="h-screen flex bg-[#0B0F19]">
      <div className={`${mobileShowChat ? 'hidden md:flex' : 'flex'} w-full md:w-auto`}>
        <Sidebar user={user} dms={dms} groups={groups} channels={channels}
          activeChat={activeChat ? { type: activeChat.type, id: activeChat.id } : null}
          onSelectDM={handleSelectDM} onSelectGroup={handleSelectGroup} onSelectChannel={handleSelectChannel}
          onCreateGroup={() => setShowCreateModal('group')} onCreateChannel={() => setShowCreateModal('channel')}
          onExplore={() => { setView('explore'); setMobileShowChat(true); }}
          onProfile={() => { setView('profile'); setMobileShowChat(true); }}
          onLogout={onLogout} onSearchUsers={() => setShowUserSearch(true)}
          onMistii={() => { setView('mistii'); setMobileShowChat(true); }}
          onSaved={() => { setView('saved'); setMobileShowChat(true); }}
          allUsers={allUsers} />
      </div>

      <div className={`flex-1 ${!mobileShowChat ? 'hidden md:flex' : 'flex'}`}>
        {view === 'explore' ? <ExplorePanel userId={user.id} onBack={() => { setView('chat'); setMobileShowChat(false); }} onJoinGroup={handleJoinGroup} onSubscribeChannel={handleSubscribeChannel} />
        : view === 'profile' ? <ProfilePanel user={user} onBack={() => { setView('chat'); setMobileShowChat(false); }} onUpdate={(u) => onUserUpdate({ ...user, ...u } as User)} />
        : view === 'mistii' ? <MistiiChat user={user} onBack={() => { setView('chat'); setMobileShowChat(false); }} />
        : view === 'saved' ? <SavedMessages user={user} onBack={() => { setView('chat'); setMobileShowChat(false); }} />
        : view === 'groupadmin' && activeChat?.type === 'group' ? <GroupAdmin group={activeChat.data} currentUser={user} allUsers={allUsers} onBack={() => setView('chat')} onUpdate={fetchData} />
        : activeChat ? (
          <ChatView chatType={activeChat.type} chatId={activeChat.id} chatData={activeChat.data} currentUser={user} allUsers={allUsers}
            onBack={() => setMobileShowChat(false)} onDM={handleDM} onOpenThemes={() => setShowThemePicker(true)}
            onOpenAdmin={activeChat.type === 'group' ? () => setView('groupadmin') : undefined}
            onForward={setForwardMsg} onSave={handleSaveMessage} />
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center">
            <MessageCircleHeart size={48} className="mx-auto mb-4 text-gray-700" />
            <h3 className="text-base font-bold text-gray-500">Select a chat to start messaging</h3>
            <p className="text-sm text-gray-600 mt-1">or talk to Mistii ✨</p>
          </div>
        )}
      </div>

      <AnimatePresence>
        {showCreateModal && <CreateGroupModal type={showCreateModal} userId={user.id} onClose={() => setShowCreateModal(null)} onCreated={async () => { setShowCreateModal(null); await fetchData(); }} />}
        {showUserSearch && <UserSearch currentUserId={user.id} onDM={handleDM} onClose={() => setShowUserSearch(false)} onMistii={() => { setShowUserSearch(false); setView('mistii'); setMobileShowChat(true); }} />}
        {showThemePicker && <ThemePicker currentTheme={user.chat_theme || 'midnight'} onSelect={handleThemeSelect} onClose={() => setShowThemePicker(false)} />}
        {forwardMsg && <ForwardModal message={forwardMsg} currentUser={user} groups={groups} channels={channels} dms={dms} allUsers={allUsers} onClose={() => setForwardMsg(null)} onForwarded={() => setForwardMsg(null)} />}
      </AnimatePresence>
    </div>
  );
}
