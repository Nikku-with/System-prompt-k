import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { AvatarConfig } from '../lib/types';
import { SKIN_COLORS, HAIR_COLORS, BG_COLORS, OUTFIT_COLORS, HAIR_STYLES, EYE_STYLES, MOUTH_STYLES, ACCESSORIES, OUTFITS, FACIAL_HAIR, DEFAULT_AVATAR } from '../lib/avatarParts';
import AvatarRenderer from './AvatarRenderer';
import { Shuffle, ChevronLeft, ChevronRight, Sparkles, Check } from 'lucide-react';

interface Props {
  initial?: AvatarConfig;
  onSave: (config: AvatarConfig) => void;
  onCancel?: () => void;
}

const TABS = [
  { id: 'face', label: '😊 Face', icon: '😊' },
  { id: 'hair', label: '💇 Hair', icon: '💇' },
  { id: 'eyes', label: '👀 Eyes', icon: '👀' },
  { id: 'mouth', label: '👄 Mouth', icon: '👄' },
  { id: 'outfit', label: '👕 Outfit', icon: '👕' },
  { id: 'extras', label: '✨ Extras', icon: '✨' },
  { id: 'bg', label: '🎨 BG', icon: '🎨' },
];

export default function AvatarCreator({ initial, onSave, onCancel }: Props) {
  const [config, setConfig] = useState<AvatarConfig>(initial || DEFAULT_AVATAR);
  const [tab, setTab] = useState(0);

  const update = (key: keyof AvatarConfig, value: any) => setConfig(prev => ({ ...prev, [key]: value }));

  const randomize = () => {
    const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
    setConfig({
      bgColor: pick(BG_COLORS),
      skinColor: pick(SKIN_COLORS),
      hairStyle: pick(HAIR_STYLES).id,
      hairColor: pick(HAIR_COLORS),
      eyeStyle: pick(EYE_STYLES).id,
      mouthStyle: pick(MOUTH_STYLES).id,
      accessory: pick(ACCESSORIES).id,
      outfit: pick(OUTFITS).id,
      outfitColor: pick(OUTFIT_COLORS),
      facialHair: pick(FACIAL_HAIR).id,
      blush: Math.random() > 0.3,
      sparkles: Math.random() > 0.4,
    });
  };

  const ColorGrid = ({ colors, selected, onSelect }: { colors: string[], selected: string, onSelect: (c: string) => void }) => (
    <div className="grid grid-cols-8 gap-2">
      {colors.map(c => (
        <button key={c} onClick={() => onSelect(c)} className="w-8 h-8 rounded-full border-2 transition-all hover:scale-110" style={{ background: c, borderColor: selected === c ? '#FF6B9D' : 'transparent', boxShadow: selected === c ? '0 0 0 2px #FF6B9D' : 'none' }} />
      ))}
    </div>
  );

  const OptionGrid = ({ options, selected, onSelect }: { options: { id: string, label: string }[], selected: string, onSelect: (id: string) => void }) => (
    <div className="grid grid-cols-4 gap-2">
      {options.map(o => (
        <button key={o.id} onClick={() => onSelect(o.id)} className={`px-2 py-2 rounded-xl text-xs font-medium transition-all hover:scale-105 ${selected === o.id ? 'bg-pink-400 text-white shadow-lg shadow-pink-400/30' : 'bg-white/10 text-white/80 hover:bg-white/20'}`}>
          {o.label}
        </button>
      ))}
    </div>
  );

  const renderTab = () => {
    switch (TABS[tab].id) {
      case 'face': return <div className="space-y-4"><p className="text-xs text-white/60 font-medium">SKIN COLOR</p><ColorGrid colors={SKIN_COLORS} selected={config.skinColor} onSelect={c => update('skinColor', c)} /><p className="text-xs text-white/60 font-medium mt-3">FACIAL HAIR</p><OptionGrid options={FACIAL_HAIR} selected={config.facialHair} onSelect={v => update('facialHair', v)} /><label className="flex items-center gap-2 text-sm text-white/80"><input type="checkbox" checked={config.blush} onChange={e => update('blush', e.target.checked)} className="accent-pink-400" /> 🌸 Blush</label></div>;
      case 'hair': return <div className="space-y-4"><p className="text-xs text-white/60 font-medium">STYLE</p><OptionGrid options={HAIR_STYLES} selected={config.hairStyle} onSelect={v => update('hairStyle', v)} /><p className="text-xs text-white/60 font-medium mt-3">COLOR</p><ColorGrid colors={HAIR_COLORS} selected={config.hairColor} onSelect={c => update('hairColor', c)} /></div>;
      case 'eyes': return <div className="space-y-4"><p className="text-xs text-white/60 font-medium">EYE STYLE</p><OptionGrid options={EYE_STYLES} selected={config.eyeStyle} onSelect={v => update('eyeStyle', v)} /></div>;
      case 'mouth': return <div className="space-y-4"><p className="text-xs text-white/60 font-medium">MOUTH STYLE</p><OptionGrid options={MOUTH_STYLES} selected={config.mouthStyle} onSelect={v => update('mouthStyle', v)} /></div>;
      case 'outfit': return <div className="space-y-4"><p className="text-xs text-white/60 font-medium">OUTFIT</p><OptionGrid options={OUTFITS} selected={config.outfit} onSelect={v => update('outfit', v)} /><p className="text-xs text-white/60 font-medium mt-3">COLOR</p><ColorGrid colors={OUTFIT_COLORS} selected={config.outfitColor} onSelect={c => update('outfitColor', c)} /></div>;
      case 'extras': return <div className="space-y-4"><p className="text-xs text-white/60 font-medium">ACCESSORY</p><OptionGrid options={ACCESSORIES} selected={config.accessory} onSelect={v => update('accessory', v)} /><label className="flex items-center gap-2 text-sm text-white/80 mt-3"><input type="checkbox" checked={config.sparkles} onChange={e => update('sparkles', e.target.checked)} className="accent-pink-400" /> ✨ Sparkles</label></div>;
      case 'bg': return <div className="space-y-4"><p className="text-xs text-white/60 font-medium">BACKGROUND</p><ColorGrid colors={BG_COLORS} selected={config.bgColor} onSelect={c => update('bgColor', c)} /></div>;
      default: return null;
    }
  };

  return (
    <div className="flex flex-col items-center gap-4 w-full max-w-md mx-auto">
      <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="relative">
        <AvatarRenderer config={config} size={160} />
        <motion.button whileHover={{ rotate: 180 }} whileTap={{ scale: 0.9 }} onClick={randomize} className="absolute -right-2 -bottom-2 w-10 h-10 rounded-full bg-gradient-to-r from-pink-400 to-purple-400 flex items-center justify-center shadow-lg">
          <Shuffle size={18} className="text-white" />
        </motion.button>
      </motion.div>

      <div className="flex gap-1 overflow-x-auto w-full pb-1 scrollbar-hide">
        {TABS.map((t, i) => (
          <button key={t.id} onClick={() => setTab(i)} className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${i === tab ? 'bg-pink-400 text-white shadow-lg' : 'bg-white/10 text-white/60 hover:bg-white/20'}`}>
            {t.icon} {t.label.split(' ')[1]}
          </button>
        ))}
      </div>

      <div className="w-full bg-white/5 rounded-2xl p-4 min-h-[160px]">
        <AnimatePresence mode="wait">
          <motion.div key={tab} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.15 }}>
            {renderTab()}
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex gap-3 w-full">
        {onCancel && <button onClick={onCancel} className="flex-1 py-3 rounded-2xl bg-white/10 text-white/70 font-medium hover:bg-white/20 transition-all">Cancel</button>}
        <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => onSave(config)} className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-pink-400 to-purple-500 text-white font-bold shadow-lg shadow-pink-400/30 flex items-center justify-center gap-2">
          <Sparkles size={18} /> Save Avatar
        </motion.button>
      </div>
    </div>
  );
}
