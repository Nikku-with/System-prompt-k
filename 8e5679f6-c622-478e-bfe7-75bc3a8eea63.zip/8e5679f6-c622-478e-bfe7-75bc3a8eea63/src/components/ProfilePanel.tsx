import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import type { User, AvatarConfig } from '../lib/types';
import AvatarCreator from './AvatarCreator';
import AvatarRenderer from './AvatarRenderer';
import { CHAT_THEMES, getTheme } from '../lib/themes';
import { ArrowLeft, Edit3, Save, Sparkles, AtSign, Palette, Check, AlertCircle, Shield, Eye, EyeOff, Users, Heart, Calendar, MapPin, Globe, Lock, Bell, UserPlus, Camera, Clock, Plus } from 'lucide-react';

const STATUS_EMOJIS = ['✨', '🌸', '💖', '🌟', '🦋', '🌺', '💜', '🎀', '😎', '🫧', '🌼', '💕', '🤩', '😉', '💝', '😘', '🫠', '😊', '🌈', '🌙'];

interface ProfileData {
  birthday: string; pronouns: string; location: string; website: string; pfp_url: string;
  followers_count: number; following_count: number; friends_count: number;
  is_private: boolean; show_birthday: boolean; show_online: boolean; show_followers: boolean;
  allow_dms_from: string;
}

export default function ProfilePanel({ user, onBack, onUpdate }: { user: User; onBack: () => void; onUpdate: (updates: Partial<User>) => void }) {
  const [tab, setTab] = useState<'profile' | 'settings' | 'privacy' | 'theme' | 'avatar' | 'notes'>('profile');
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState(user.display_name);
  const [username, setUsername] = useState(user.username || user.anon_id);
  const [bio, setBio] = useState(user.bio);
  const [statusEmoji, setStatusEmoji] = useState(user.status_emoji);
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [birthday, setBirthday] = useState('');
  const [pronouns, setPronouns] = useState('');
  const [location, setLocation] = useState('');
  const [website, setWebsite] = useState('');
  const [saving, setSaving] = useState(false);
  const [usernameError, setUsernameError] = useState('');
  const [noteText, setNoteText] = useState('');
  const [notes, setNotes] = useState<any[]>([]);

  useEffect(() => {
    fetch(`/api/profiles?user_id=${user.id}`).then(r => r.json()).then(d => {
      setProfile(d); setBirthday(d.birthday || ''); setPronouns(d.pronouns || '');
      setLocation(d.location || ''); setWebsite(d.website || '');
    }).catch(() => {});
    fetch(`/api/notes?user_id=${user.id}`).then(r => r.json()).then(d => setNotes(Array.isArray(d) ? d : [])).catch(() => {});
  }, [user.id]);

  const handleSaveProfile = async () => {
    setSaving(true); setUsernameError('');
    const clean = username.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    const res = await fetch('/api/users', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: user.id, display_name: displayName, username: clean, bio, status_emoji: statusEmoji }) });
    const data = await res.json();
    if (!res.ok) { setUsernameError(data.error || 'Error'); setSaving(false); return; }
    await fetch('/api/profiles', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: user.id, birthday, pronouns, location, website }) });
    onUpdate({ display_name: displayName, username: clean, bio, status_emoji: statusEmoji });
    setEditing(false); setSaving(false);
  };

  const handlePrivacyUpdate = async (key: string, value: any) => {
    await fetch('/api/profiles', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: user.id, [key]: value }) });
    setProfile(prev => prev ? { ...prev, [key]: value } : prev);
  };

  const handleThemeChange = async (themeId: string) => {
    await fetch('/api/users', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: user.id, chat_theme: themeId }) });
    onUpdate({ chat_theme: themeId });
  };

  const handleAvatarSave = async (config: AvatarConfig) => {
    await fetch('/api/users', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: user.id, avatar_config: JSON.stringify(config) }) });
    onUpdate({ avatar_config: JSON.stringify(config) }); setTab('profile');
  };

  const postNote = async () => {
    if (!noteText.trim()) return;
    await fetch('/api/notes', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: user.id, content: noteText.trim(), note_type: 'text' }) });
    setNoteText('');
    const res = await fetch(`/api/notes?user_id=${user.id}`); setNotes(await res.json());
  };

  const Toggle = ({ value, onChange, label }: { value: boolean; onChange: (v: boolean) => void; label: string }) => (
    <div className="flex items-center justify-between py-2">
      <span className="text-xs text-gray-300">{label}</span>
      <button onClick={() => onChange(!value)} className={`w-9 h-5 rounded-full transition-all relative ${value ? 'bg-blue-500' : 'bg-gray-700'}`}>
        <motion.div animate={{ x: value ? 16 : 2 }} className="absolute top-0.5 w-4 h-4 rounded-full bg-white shadow-sm" />
      </button>
    </div>
  );

  if (tab === 'avatar') {
    let c: AvatarConfig; try { c = JSON.parse(user.avatar_config); } catch { c = {} as AvatarConfig; }
    return (
      <div className="flex-1 flex flex-col h-full bg-[#0B0F19] p-4 overflow-y-auto">
        <div className="flex items-center gap-3 mb-4"><button onClick={() => setTab('profile')} className="text-gray-500 hover:text-gray-300"><ArrowLeft size={20} /></button><h2 className="text-sm font-bold text-white">Edit Avatar</h2></div>
        <AvatarCreator initial={c} onSave={handleAvatarSave} onCancel={() => setTab('profile')} />
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0B0F19]">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-800/50">
        <button onClick={onBack} className="text-gray-500 hover:text-gray-300"><ArrowLeft size={20} /></button>
        <h2 className="text-sm font-bold text-white">Profile</h2>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-800/50 px-2">
        {[
          { id: 'profile' as const, label: 'Profile' },
          { id: 'privacy' as const, label: 'Privacy' },
          { id: 'theme' as const, label: 'Theme' },
          { id: 'notes' as const, label: 'Notes' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`flex-1 py-2 text-[10px] font-bold border-b-2 transition-all ${tab === t.id ? 'text-blue-400 border-blue-400' : 'text-gray-600 border-transparent'}`}>{t.label}</button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {tab === 'profile' && (
          <>
            {/* Avatar + PFP */}
            <div className="flex flex-col items-center">
              <button onClick={() => setTab('avatar')} className="relative group">
                <AvatarRenderer config={user.avatar_config} size={100} />
                <div className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center"><Camera size={20} className="text-white" /></div>
              </button>
              <p className="text-gray-600 text-[10px] mt-1">Tap to edit</p>
            </div>

            {/* Info card */}
            <div className="bg-gray-800/20 rounded-xl p-4 border border-gray-700/20 space-y-3">
              {editing ? (
                <>
                  <div><label className="text-[9px] text-gray-500 font-bold uppercase">Display Name</label><input value={displayName} onChange={e => setDisplayName(e.target.value)} className="w-full mt-1 px-3 py-2 rounded-lg bg-gray-800/50 border border-gray-700/50 text-white text-sm focus:outline-none focus:border-blue-500/30" maxLength={20} /></div>
                  <div><label className="text-[9px] text-gray-500 font-bold uppercase flex items-center gap-1"><AtSign size={9} /> Username</label><div className="relative mt-1"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-400/40 text-xs">@</span><input value={username} onChange={e => { setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '')); setUsernameError(''); }} className="w-full pl-7 pr-3 py-2 rounded-lg bg-gray-800/50 border border-gray-700/50 text-white text-sm font-mono focus:outline-none focus:border-blue-500/30" maxLength={20} /></div>{usernameError && <p className="text-red-400 text-[9px] mt-1 flex items-center gap-1"><AlertCircle size={9} /> {usernameError}</p>}</div>
                  <div><label className="text-[9px] text-gray-500 font-bold uppercase">Bio</label><textarea value={bio} onChange={e => setBio(e.target.value)} className="w-full mt-1 px-3 py-2 rounded-lg bg-gray-800/50 border border-gray-700/50 text-white text-sm focus:outline-none focus:border-blue-500/30 resize-none h-14" maxLength={150} /></div>
                  <div><label className="text-[9px] text-gray-500 font-bold uppercase">Status Emoji</label><div className="flex flex-wrap gap-1 mt-1">{STATUS_EMOJIS.map(e => <button key={e} onClick={() => setStatusEmoji(e)} className={`w-7 h-7 rounded flex items-center justify-center text-sm ${statusEmoji === e ? 'bg-blue-500/20 ring-1 ring-blue-400/40' : 'bg-gray-800/30 hover:bg-gray-800/50'}`}>{e}</button>)}</div></div>
                  <div className="grid grid-cols-2 gap-2">
                    <div><label className="text-[9px] text-gray-500 font-bold uppercase flex items-center gap-1"><Calendar size={9} /> Birthday</label><input type="date" value={birthday} onChange={e => setBirthday(e.target.value)} className="w-full mt-1 px-2 py-1.5 rounded-lg bg-gray-800/50 border border-gray-700/50 text-white text-xs focus:outline-none" /></div>
                    <div><label className="text-[9px] text-gray-500 font-bold uppercase">Pronouns</label><input value={pronouns} onChange={e => setPronouns(e.target.value)} placeholder="they/them" className="w-full mt-1 px-2 py-1.5 rounded-lg bg-gray-800/50 border border-gray-700/50 text-white text-xs focus:outline-none placeholder-gray-600" /></div>
                  </div>
                  <div><label className="text-[9px] text-gray-500 font-bold uppercase flex items-center gap-1"><MapPin size={9} /> Location</label><input value={location} onChange={e => setLocation(e.target.value)} placeholder="City, Country" className="w-full mt-1 px-3 py-1.5 rounded-lg bg-gray-800/50 border border-gray-700/50 text-white text-xs focus:outline-none placeholder-gray-600" /></div>
                  <div className="flex gap-2 pt-1">
                    <button onClick={() => setEditing(false)} className="flex-1 py-2 rounded-lg bg-gray-800/50 text-gray-400 text-xs font-bold">Cancel</button>
                    <button onClick={handleSaveProfile} disabled={saving} className="flex-1 py-2 rounded-lg bg-blue-500 text-white text-xs font-bold flex items-center justify-center gap-1 disabled:opacity-50">{saving ? <Sparkles size={12} className="animate-spin" /> : <Save size={12} />} Save</button>
                  </div>
                </>
              ) : (
                <>
                  <div className="text-center">
                    <h3 className="text-lg font-bold text-white">{user.status_emoji} {user.display_name}</h3>
                    <p className="text-sm text-blue-400/50 font-mono">@{user.username || user.anon_id}</p>
                    <p className="text-xs text-gray-400 mt-1">{user.bio || 'No bio yet'}</p>
                    <div className="flex items-center justify-center gap-3 mt-2 text-[10px] text-gray-500">
                      {profile?.pronouns && <span>{profile.pronouns}</span>}
                      {profile?.location && <span className="flex items-center gap-0.5"><MapPin size={9} /> {profile.location}</span>}
                      {profile?.birthday && <span className="flex items-center gap-0.5"><Calendar size={9} /> {profile.birthday}</span>}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-2">
                    <div className="text-center bg-gray-800/30 rounded-lg py-2"><p className="text-sm font-bold text-white">{profile?.friends_count || 0}</p><p className="text-[9px] text-gray-500">Friends</p></div>
                    <div className="text-center bg-gray-800/30 rounded-lg py-2"><p className="text-sm font-bold text-white">{profile?.followers_count || 0}</p><p className="text-[9px] text-gray-500">Followers</p></div>
                    <div className="text-center bg-gray-800/30 rounded-lg py-2"><p className="text-sm font-bold text-white">{profile?.following_count || 0}</p><p className="text-[9px] text-gray-500">Following</p></div>
                  </div>
                  <button onClick={() => setEditing(true)} className="w-full py-2 rounded-lg bg-gray-800/30 text-gray-400 text-xs font-bold hover:bg-gray-800/50 transition-all flex items-center justify-center gap-1"><Edit3 size={12} /> Edit Profile</button>
                </>
              )}
            </div>
          </>
        )}

        {tab === 'privacy' && profile && (
          <div className="space-y-3">
            <p className="text-[9px] text-gray-500 font-bold uppercase">Privacy Settings</p>
            <div className="bg-gray-800/20 rounded-xl p-3 border border-gray-700/20 space-y-1">
              <Toggle value={profile.is_private} onChange={v => handlePrivacyUpdate('is_private', v)} label="🔒 Private Account" />
              <Toggle value={profile.show_birthday} onChange={v => handlePrivacyUpdate('show_birthday', v)} label="🎂 Show Birthday" />
              <Toggle value={profile.show_online} onChange={v => handlePrivacyUpdate('show_online', v)} label="🟢 Show Online Status" />
              <Toggle value={profile.show_followers} onChange={v => handlePrivacyUpdate('show_followers', v)} label="👥 Show Followers Count" />
            </div>
            <p className="text-[9px] text-gray-500 font-bold uppercase mt-3">Who Can DM You</p>
            <div className="flex gap-2">
              {['everyone', 'friends', 'nobody'].map(opt => (
                <button key={opt} onClick={() => handlePrivacyUpdate('allow_dms_from', opt)} className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all border ${profile.allow_dms_from === opt ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' : 'bg-gray-800/30 text-gray-500 border-gray-700/30'}`}>{opt === 'everyone' ? '🌍 Everyone' : opt === 'friends' ? '👫 Friends' : '🚫 Nobody'}</button>
              ))}
            </div>
          </div>
        )}

        {tab === 'theme' && (
          <div className="space-y-3">
            <p className="text-[9px] text-gray-500 font-bold uppercase">Chat Theme</p>
            <div className="grid grid-cols-3 gap-2">
              {CHAT_THEMES.filter(t => t.id !== 'custom').map(t => (
                <button key={t.id} onClick={() => handleThemeChange(t.id)} className={`relative rounded-xl overflow-hidden border-2 transition-all ${user.chat_theme === t.id ? 'border-blue-400 shadow-lg shadow-blue-400/10' : 'border-gray-700/30 hover:border-gray-600/30'}`}>
                  <div className="h-16 p-2 flex flex-col justify-end gap-0.5" style={{ background: t.bg }}>
                    <div className="flex gap-1 items-end"><div className="w-3 h-3 rounded-full bg-white/10" /><div className="px-2 py-0.5 rounded-lg text-[6px]" style={{ background: t.otherBubble, color: t.otherText }}>hey</div></div>
                    <div className="flex justify-end"><div className="px-2 py-0.5 rounded-lg text-[6px]" style={{ background: t.ownBubble, color: t.ownText }}>hi!</div></div>
                  </div>
                  <div className="px-2 py-1.5 bg-black/30 flex items-center gap-1"><span className="text-[10px]">{t.emoji}</span><span className="text-[8px] font-bold text-gray-300">{t.name}</span></div>
                  {user.chat_theme === t.id && <div className="absolute top-1 right-1 w-3 h-3 rounded-full bg-blue-400 flex items-center justify-center"><Check size={7} className="text-white" /></div>}
                </button>
              ))}
            </div>
          </div>
        )}

        {tab === 'notes' && (
          <div className="space-y-3">
            <p className="text-[9px] text-gray-500 font-bold uppercase flex items-center gap-1"><Clock size={9} /> 24h Notes (Stories)</p>
            <div className="flex gap-2">
              <input value={noteText} onChange={e => setNoteText(e.target.value)} placeholder="What's on your mind?" className="flex-1 px-3 py-2 rounded-lg bg-gray-800/50 border border-gray-700/50 text-white text-xs focus:outline-none focus:border-blue-500/30 placeholder-gray-500" />
              <button onClick={postNote} disabled={!noteText.trim()} className="px-3 py-2 rounded-lg bg-blue-500 text-white text-xs font-bold disabled:opacity-30"><Plus size={14} /></button>
            </div>
            {notes.length === 0 ? (
              <div className="text-center py-6"><span className="text-2xl block mb-1">📝</span><p className="text-gray-600 text-xs">No notes yet — they disappear in 24h!</p></div>
            ) : notes.map(n => (
              <div key={n.id} className="bg-gray-800/20 rounded-lg p-3 border border-gray-700/20">
                <p className="text-xs text-gray-200">{n.content}</p>
                <p className="text-[9px] text-gray-600 mt-1 flex items-center gap-1"><Clock size={8} /> {new Date(n.created_at).toLocaleString()}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
