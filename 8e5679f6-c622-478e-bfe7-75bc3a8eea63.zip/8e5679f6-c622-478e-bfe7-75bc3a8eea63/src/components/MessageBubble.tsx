import React, { useState } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import type { Message, ChatTheme } from '../lib/types';
import AvatarRenderer from './AvatarRenderer';
import { Copy, Reply, AtSign, Pin, Trash2, Check, MoreHorizontal, SmilePlus, Forward, Bookmark, Edit3, EyeOff, Clock, Link2, Languages, CheckCheck, ListChecks } from 'lucide-react';

const QUICK_REACTIONS = ['❤️', '😂', '😮', '😢', '😍', '👍', '🔥', '✨', '🎉', '💀', '🥺', '👀'];

interface Props {
  message: Message; isOwn: boolean; theme: ChatTheme;
  onReply: (msg: Message) => void; onTag: (name: string) => void;
  onReact: (msgId: number, emoji: string) => void; onPin: (msgId: number) => void;
  onDelete: (msgId: number) => void; onDM?: (userId: number) => void;
  onForward?: (msg: Message) => void; onSave?: (msg: Message) => void;
  onEdit?: (msg: Message) => void; onTranslate?: (msgId: number) => void;
  onCopyLink?: (msgId: number) => void; onSelect?: () => void;
}

export default function MessageBubble({ message: msg, isOwn, theme, onReply, onTag, onReact, onPin, onDelete, onDM, onForward, onSave, onEdit, onTranslate, onCopyLink, onSelect }: Props) {
  const [showMenu, setShowMenu] = useState(false);
  const [showReactions, setShowReactions] = useState(false);
  const [copied, setCopied] = useState(false);
  const [spoilerRevealed, setSpoilerRevealed] = useState(false);

  const reactions: Record<string, number> = (() => { try { return JSON.parse(msg.reactions || '{}'); } catch { return {}; } })();
  const forwardInfo = (() => { try { const p = JSON.parse(msg.tagged_users || '[]'); return p.forwarded ? p : null; } catch { return null; } })();

  const isSpoiler = msg.message_type === 'spoiler';
  const isVoice = msg.message_type === 'voice';
  const isFile = msg.message_type === 'file';
  const isFullEmoji = /^[\p{Emoji}\s]{1,10}$/u.test(msg.content) && msg.message_type === 'text';
  const isSticker = msg.message_type === 'sticker' && msg.sticker_url;

  const copyText = () => { navigator.clipboard.writeText(msg.content); setCopied(true); setTimeout(() => setCopied(false), 1500); setShowMenu(false); };

  // Rich text: **bold** *italic* __underline__ ~~strike~~ `code` @mention #tag >quote [link](url)
  const renderContent = (text: string) => {
    return text.split(/(\*\*[^*]+\*\*|\*[^*]+\*|__[^_]+__|~~[^~]+~~|`[^`]+`|```[\s\S]+?```|@\w+|#\w+|>[^\n]+|\[([^\]]+)\]\(([^)]+)\))/g).map((part, i) => {
      if (!part) return null;
      if (part.startsWith('**') && part.endsWith('**')) return <strong key={i} className="font-bold">{part.slice(2, -2)}</strong>;
      if (part.startsWith('*') && part.endsWith('*')) return <em key={i}>{part.slice(1, -1)}</em>;
      if (part.startsWith('__') && part.endsWith('__')) return <u key={i}>{part.slice(2, -2)}</u>;
      if (part.startsWith('~~') && part.endsWith('~~')) return <s key={i} className="opacity-50">{part.slice(2, -2)}</s>;
      if (part.startsWith('```') && part.endsWith('```')) return <pre key={i} className="px-2 py-1 rounded bg-black/30 text-[11px] font-mono overflow-x-auto my-1" style={{ color: theme.accent }}>{part.slice(3, -3)}</pre>;
      if (part.startsWith('`') && part.endsWith('`')) return <code key={i} className="px-1 py-0.5 rounded bg-black/25 text-[11px] font-mono" style={{ color: theme.accent }}>{part.slice(1, -1)}</code>;
      if (part.startsWith('@')) return <span key={i} className="font-bold cursor-pointer hover:underline" style={{ color: theme.accent }}>{part}</span>;
      if (part.startsWith('#')) return <span key={i} className="font-semibold cursor-pointer hover:underline" style={{ color: theme.accent }}>{part}</span>;
      if (part.startsWith('>')) return <div key={i} className="border-l-2 pl-2 my-0.5 italic opacity-70" style={{ borderColor: theme.accent + '60' }}>{part.slice(1).trim()}</div>;
      // Hyperlinks
      const linkMatch = part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
      if (linkMatch) return <a key={i} href={linkMatch[2]} target="_blank" rel="noopener noreferrer" className="underline hover:opacity-80" style={{ color: theme.accent }}>{linkMatch[1]}</a>;
      // Auto-detect URLs
      if (/^https?:\/\/\S+/.test(part)) return <a key={i} href={part} target="_blank" rel="noopener noreferrer" className="underline hover:opacity-80" style={{ color: theme.accent }}>{part}</a>;
      return part;
    });
  };

  const timeStr = new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Swipe to reply
  const handleDragEnd = (_: any, info: PanInfo) => { if (info.offset.x < -50) onReply(msg); };

  return (
    <motion.div
      drag="x" dragConstraints={{ left: -70, right: 0 }} dragElastic={0.08} onDragEnd={handleDragEnd}
      initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
      className={`flex gap-2 group px-3 py-[2px] relative ${isOwn ? 'flex-row-reverse' : ''}`}
      onMouseLeave={() => { setShowMenu(false); setShowReactions(false); }}
    >
      {!isOwn && (
        <button onClick={() => onDM?.(msg.sender_id)} className="flex-shrink-0 self-end mb-4 hover:scale-105 transition-transform">
          <AvatarRenderer config={msg.sender_avatar} size={28} />
        </button>
      )}

      <div className={`max-w-[78%] relative flex flex-col ${isOwn ? 'items-end' : 'items-start'}`}>
        {!isOwn && <p className="text-[9px] font-semibold mb-[1px] px-1.5" style={{ color: theme.accent + '88' }}>{msg.sender_name}</p>}

        {forwardInfo && <div className="flex items-center gap-1 px-1.5 mb-[1px]"><Forward size={8} className="text-gray-500" /><p className="text-[8px] text-gray-500">Forwarded from {forwardInfo.from}</p></div>}

        {msg.reply_to_id && (
          <div className={`text-[9px] px-2.5 py-1 rounded-t-lg mb-0 flex items-center gap-1 max-w-full ${isOwn ? 'rounded-tr-none' : 'rounded-tl-none'}`} style={{ background: theme.accent + '0c', borderLeft: isOwn ? 'none' : `2px solid ${theme.accent}40`, borderRight: isOwn ? `2px solid ${theme.accent}40` : 'none' }}>
            <Reply size={7} style={{ color: theme.accent }} />
            <span className="font-bold" style={{ color: theme.accent + 'aa' }}>{msg.reply_to_name}</span>
            <span className="text-gray-500 truncate">{msg.reply_to_content}</span>
          </div>
        )}

        {/* Content */}
        {isSticker ? (
          <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 500 }} className="w-28 h-28 p-1">
            <img src={msg.sticker_url!} alt="sticker" className="w-full h-full object-contain" />
          </motion.div>
        ) : isFullEmoji ? (
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 500, damping: 12 }} className="text-4xl py-0.5 px-1">{msg.content}</motion.div>
        ) : isVoice ? (
          <div className={`px-3 py-2 rounded-2xl flex items-center gap-2 ${isOwn ? 'rounded-br-sm' : 'rounded-bl-sm'}`} style={{ background: isOwn ? theme.ownBubble : theme.otherBubble, minWidth: 160 }}>
            <span className="text-base">🎤</span>
            <div className="flex-1"><div className="h-[3px] rounded-full overflow-hidden" style={{ background: theme.accent + '20' }}><div className="h-full w-3/5 rounded-full" style={{ background: isOwn ? '#fff8' : theme.accent }} /></div><p className="text-[8px] mt-0.5 opacity-40">Voice note</p></div>
          </div>
        ) : isFile ? (
          <div className={`px-3 py-2 rounded-2xl flex items-center gap-2 ${isOwn ? 'rounded-br-sm' : 'rounded-bl-sm'}`} style={{ background: isOwn ? theme.ownBubble : theme.otherBubble, color: isOwn ? theme.ownText : theme.otherText }}>
            <span className="text-base">📎</span>
            <div className="min-w-0 flex-1"><p className="text-[11px] font-semibold truncate">{msg.content || 'File'}</p><p className="text-[8px] opacity-30">Tap to open</p></div>
          </div>
        ) : (
          <div
            className={`px-3 py-[7px] text-[13px] leading-[1.45] break-words relative ${isOwn ? 'rounded-2xl rounded-br-sm' : 'rounded-2xl rounded-bl-sm'}`}
            style={{ background: isOwn ? theme.ownBubble : theme.otherBubble, color: isOwn ? theme.ownText : theme.otherText, boxShadow: isOwn ? `0 1px 6px ${theme.accent}12` : 'none' }}
            onClick={() => isSpoiler && setSpoilerRevealed(!spoilerRevealed)}
          >
            <span className={isSpoiler && !spoilerRevealed ? 'spoiler-hidden' : ''}>
              {renderContent(msg.content)}
            </span>
          </div>
        )}

        {/* Reactions */}
        {Object.keys(reactions).length > 0 && (
          <div className="flex gap-0.5 mt-[2px] flex-wrap">
            {Object.entries(reactions).map(([emoji, count]) => (
              <button key={emoji} onClick={() => onReact(msg.id, emoji)} className="flex items-center gap-[2px] px-1.5 py-[1px] rounded-full text-[9px]" style={{ background: theme.accent + '10', border: `1px solid ${theme.accent}15` }}>
                <span>{emoji}</span><span className="font-semibold" style={{ color: theme.accent + '99' }}>{count as number}</span>
              </button>
            ))}
          </div>
        )}

        {/* Time + read receipts */}
        <div className={`flex items-center gap-1 mt-[1px] px-1 ${isOwn ? 'flex-row-reverse' : ''}`}>
          <p className="text-[8px] text-gray-500">{timeStr}</p>
          {msg.is_pinned && <span className="text-[8px]">📌</span>}
          {isOwn && <CheckCheck size={10} style={{ color: theme.accent + '60' }} />}
        </div>

        {/* Hover actions */}
        <div className={`absolute top-0 ${isOwn ? '-left-0.5 -translate-x-full' : '-right-0.5 translate-x-full'} opacity-0 group-hover:opacity-100 transition-all flex flex-col gap-[2px]`}>
          <button onClick={() => setShowReactions(!showReactions)} className="w-6 h-6 rounded-md flex items-center justify-center text-gray-600 hover:text-gray-300 hover:bg-white/5"><SmilePlus size={11} /></button>
          <button onClick={() => onReply(msg)} className="w-6 h-6 rounded-md flex items-center justify-center text-gray-600 hover:text-gray-300 hover:bg-white/5"><Reply size={11} /></button>
          <button onClick={() => setShowMenu(!showMenu)} className="w-6 h-6 rounded-md flex items-center justify-center text-gray-600 hover:text-gray-300 hover:bg-white/5"><MoreHorizontal size={11} /></button>
        </div>

        {/* Context menu - ALL features */}
        <AnimatePresence>
          {showMenu && (
            <motion.div initial={{ opacity: 0, scale: 0.92 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.92 }} className={`absolute z-50 ${isOwn ? 'right-0' : 'left-0'} top-full mt-1 rounded-xl border shadow-2xl py-1 min-w-[170px]`} style={{ background: '#111827f0', borderColor: '#1f293780', backdropFilter: 'blur(20px)' }}>
              <button onClick={copyText} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2">{copied ? <Check size={11} className="text-green-400" /> : <Copy size={11} />} {copied ? 'Copied!' : 'Copy text'}</button>
              <button onClick={() => { onReply(msg); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2"><Reply size={11} /> Reply</button>
              {onForward && <button onClick={() => { onForward(msg); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2"><Forward size={11} /> Forward</button>}
              {onSave && <button onClick={() => { onSave(msg); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2"><Bookmark size={11} /> Save</button>}
              {isOwn && onEdit && <button onClick={() => { onEdit(msg); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2"><Edit3 size={11} /> Edit</button>}
              <button onClick={() => { onTag(msg.sender_name); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2"><AtSign size={11} /> Mention</button>
              {onTranslate && <button onClick={() => { onTranslate(msg.id); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2"><Languages size={11} /> Translate</button>}
              {onCopyLink && <button onClick={() => { onCopyLink(msg.id); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2"><Link2 size={11} /> Copy link</button>}
              {onSelect && <button onClick={() => { onSelect(); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2"><ListChecks size={11} /> Select</button>}
              <div className="h-px mx-2 my-0.5 bg-gray-700/30" />
              <button onClick={() => { onPin(msg.id); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2"><Pin size={11} /> {msg.is_pinned ? 'Unpin' : 'Pin'}</button>
              {!isOwn && onDM && <button onClick={() => { onDM(msg.sender_id); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-white/5 flex items-center gap-2">💬 DM</button>}
              {isOwn && <button onClick={() => { onDelete(msg.id); setShowMenu(false); }} className="w-full px-3 py-[6px] text-[11px] text-red-400 hover:bg-red-400/5 flex items-center gap-2"><Trash2 size={11} /> Delete for all</button>}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Reaction picker */}
        <AnimatePresence>
          {showReactions && (
            <motion.div initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.85 }} className={`absolute z-50 ${isOwn ? 'right-0' : 'left-0'} top-full mt-1 rounded-xl border shadow-2xl p-1 flex gap-[2px] flex-wrap max-w-[230px]`} style={{ background: '#111827f0', borderColor: '#1f293780' }}>
              {QUICK_REACTIONS.map(e => (
                <motion.button key={e} whileHover={{ scale: 1.35, y: -3 }} whileTap={{ scale: 0.8 }} onClick={() => { onReact(msg.id, e); setShowReactions(false); }} className="w-7 h-7 rounded-lg flex items-center justify-center text-sm hover:bg-white/10">{e}</motion.button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
