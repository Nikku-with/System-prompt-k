import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import type { Group, Channel } from '../lib/types';
import { Search, Users, Megaphone, ArrowLeft, UserPlus, Sparkles, Globe } from 'lucide-react';

interface Props {
  userId: number;
  onBack: () => void;
  onJoinGroup: (groupId: number) => void;
  onSubscribeChannel: (channelId: number) => void;
}

export default function ExplorePanel({ userId, onBack, onJoinGroup, onSubscribeChannel }: Props) {
  const [tab, setTab] = useState<'groups' | 'channels'>('groups');
  const [groups, setGroups] = useState<Group[]>([]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAll = async () => {
      setLoading(true);
      try {
        const [gRes, cRes] = await Promise.all([fetch('/api/groups'), fetch('/api/channels')]);
        const [gData, cData] = await Promise.all([gRes.json(), cRes.json()]);
        setGroups(Array.isArray(gData) ? gData.filter((g: Group) => g.is_public) : []);
        setChannels(Array.isArray(cData) ? cData.filter((c: Channel) => c.is_public) : []);
      } catch (err) { console.error(err); }
      finally { setLoading(false); }
    };
    fetchAll();
  }, []);

  const filtered = tab === 'groups'
    ? groups.filter(g => g.name.toLowerCase().includes(search.toLowerCase()))
    : channels.filter(c => c.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex-1 flex flex-col h-full" style={{ background: 'linear-gradient(160deg, #0c1929 0%, #0a1520 100%)' }}>
      <div className="flex items-center gap-3 px-4 py-3 border-b" style={{ borderColor: 'rgba(56,189,248,0.06)' }}>
        <button onClick={onBack} className="text-white/40 hover:text-white/70"><ArrowLeft size={20} /></button>
        <Globe size={20} style={{ color: '#38bdf8' }} />
        <h2 className="text-sm font-black text-white">Explore</h2>
      </div>

      <div className="px-4 py-3 space-y-3">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/15" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="w-full pl-9 pr-3 py-2.5 rounded-xl text-white text-xs placeholder-white/20 focus:outline-none transition-all" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(56,189,248,0.08)' }} />
        </div>
        <div className="flex gap-2">
          <button onClick={() => setTab('groups')} className="flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all border" style={{ background: tab === 'groups' ? 'rgba(56,189,248,0.1)' : 'rgba(255,255,255,0.02)', borderColor: tab === 'groups' ? 'rgba(56,189,248,0.2)' : 'rgba(255,255,255,0.04)', color: tab === 'groups' ? '#38bdf8' : 'rgba(255,255,255,0.3)' }}>
            <Users size={14} /> Groups
          </button>
          <button onClick={() => setTab('channels')} className="flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all border" style={{ background: tab === 'channels' ? 'rgba(251,191,36,0.1)' : 'rgba(255,255,255,0.02)', borderColor: tab === 'channels' ? 'rgba(251,191,36,0.2)' : 'rgba(255,255,255,0.04)', color: tab === 'channels' ? '#fbbf24' : 'rgba(255,255,255,0.3)' }}>
            <Megaphone size={14} /> Channels
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
        {loading ? (
          <div className="flex items-center justify-center py-12"><motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity }}><Sparkles size={24} style={{ color: '#38bdf8' }} /></motion.div></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-white/15"><p className="text-3xl mb-2">🔍</p><p className="text-sm">Nothing found</p></div>
        ) : (
          filtered.map((item: any) => (
            <motion.div key={item.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl p-4 border transition-all" style={{ background: 'rgba(255,255,255,0.02)', borderColor: 'rgba(56,189,248,0.05)' }}>
              <div className="flex items-start gap-3">
                <div className="w-11 h-11 rounded-xl flex items-center justify-center text-lg flex-shrink-0 border" style={{ background: 'linear-gradient(135deg, rgba(56,189,248,0.08), rgba(251,191,36,0.05))', borderColor: 'rgba(56,189,248,0.06)' }}>
                  {item.name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-black text-white truncate">{item.name}</h3>
                  <p className="text-[10px] text-white/25">{item.description || 'No description'}</p>
                  <p className="text-[10px] text-white/15 mt-1">{tab === 'groups' ? `${item.member_count} members` : `${item.subscriber_count} subscribers`}</p>
                </div>
                <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => tab === 'groups' ? onJoinGroup(item.id) : onSubscribeChannel(item.id)} className="px-3 py-1.5 rounded-xl text-white text-xs font-bold flex items-center gap-1 shadow-lg" style={{ background: 'linear-gradient(135deg, #38bdf8, #fbbf24)', boxShadow: '0 2px 10px rgba(56,189,248,0.2)' }}>
                  <UserPlus size={12} /> Join
                </motion.button>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
