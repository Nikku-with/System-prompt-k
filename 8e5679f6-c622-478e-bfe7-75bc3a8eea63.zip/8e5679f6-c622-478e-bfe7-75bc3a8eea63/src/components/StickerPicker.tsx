import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, TrendingUp, Sparkles } from 'lucide-react';

interface Sticker {
  id: string;
  title: string;
  url: string;
  preview: string;
}

const CATEGORIES = [
  { q: 'trending', label: '🔥 Trending', type: 'trending' },
  { q: 'cute', label: '🌸 Cute' },
  { q: 'love heart', label: '💖 Love' },
  { q: 'happy', label: '😊 Happy' },
  { q: 'sad cry', label: '😢 Sad' },
  { q: 'angry', label: '😤 Angry' },
  { q: 'cat kawaii', label: '😺 Kawaii' },
  { q: 'dance party', label: '💃 Dance' },
  { q: 'hello hi wave', label: '👋 Hi' },
  { q: 'thank you', label: '🙏 Thanks' },
  { q: 'cool sunglasses', label: '😎 Cool' },
  { q: 'sparkle magic', label: '✨ Magic' },
];

export default function StickerPicker({ onSelect, onClose }: { onSelect: (url: string) => void, onClose: () => void }) {
  const [stickers, setStickers] = useState<Sticker[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState(0);

  const fetchStickers = async (query: string, type?: string) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ q: query });
      if (type) params.set('type', type);
      const res = await fetch(`/api/stickers?${params}`);
      const data = await res.json();
      setStickers(Array.isArray(data) ? data : []);
    } catch {
      setStickers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const cat = CATEGORIES[activeCategory];
    fetchStickers(cat.q, (cat as any).type);
  }, [activeCategory]);

  useEffect(() => {
    if (search.length > 2) {
      const t = setTimeout(() => fetchStickers(search), 500);
      return () => clearTimeout(t);
    }
  }, [search]);

  return (
    <motion.div initial={{ opacity: 0, y: 20, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.95 }} className="absolute bottom-full left-0 right-0 mb-2 bg-[#1a0e2e]/95 backdrop-blur-xl rounded-2xl border border-white/10 shadow-2xl overflow-hidden" style={{ height: '360px' }}>
      <div className="p-3 border-b border-white/5">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-bold text-white/80 flex items-center gap-1"><Sparkles size={14} className="text-pink-400" /> Stickers</h3>
          <button onClick={onClose} className="text-white/40 hover:text-white/70"><X size={16} /></button>
        </div>
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search stickers..." className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-xs placeholder-white/30 focus:outline-none focus:border-pink-400/30" />
        </div>
      </div>

      <div className="flex gap-1 px-3 py-2 overflow-x-auto scrollbar-hide border-b border-white/5">
        {CATEGORIES.map((cat, i) => (
          <button key={cat.q} onClick={() => { setActiveCategory(i); setSearch(''); }} className={`px-2.5 py-1 rounded-lg text-xs whitespace-nowrap transition-all ${i === activeCategory ? 'bg-pink-400/20 text-pink-300' : 'text-white/40 hover:text-white/60 hover:bg-white/5'}`}>
            {cat.label}
          </button>
        ))}
      </div>

      <div className="overflow-y-auto p-3" style={{ height: 'calc(100% - 120px)' }}>
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity }} className="text-pink-400"><Sparkles size={24} /></motion.div>
          </div>
        ) : stickers.length === 0 ? (
          <p className="text-center text-white/30 text-xs mt-8">No stickers found 😢</p>
        ) : (
          <div className="grid grid-cols-4 gap-2">
            {stickers.map(s => (
              <motion.button key={s.id} whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => onSelect(s.url)} className="aspect-square rounded-xl bg-white/5 p-1 hover:bg-white/10 transition-all overflow-hidden">
                <img src={s.preview || s.url} alt={s.title} className="w-full h-full object-contain" loading="lazy" />
              </motion.button>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}
