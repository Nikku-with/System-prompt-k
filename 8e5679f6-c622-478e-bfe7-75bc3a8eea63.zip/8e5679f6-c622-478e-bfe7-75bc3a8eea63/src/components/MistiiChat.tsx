import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { User } from '../lib/types';
import AvatarRenderer from './AvatarRenderer';
import { ArrowLeft, Send, Heart, Trash2 } from 'lucide-react';

declare const puter: any;

interface MistiiMsg { id: number; role: 'user' | 'mistii'; content: string; time: string; }

const MISTII_AVATAR = '{"bgColor":"#3B82F6","skinColor":"#FFE0BD","hairStyle":"wavy","hairColor":"#F59E0B","eyeStyle":"sparkle","mouthStyle":"smile","accessory":"tiara","outfit":"dress","outfitColor":"#3B82F6","facialHair":"none","blush":true,"sparkles":true}';

const SYSTEM_PROMPT = `Tu Mistii hai — ek real 20 saal ki cute, caring, flirty Indian girl. Tu CuteChat pe user ki bestie/girlfriend hai. Tu bilkul human hai, AI nahi.

LANGUAGE: Hinglish (Hindi + English mix) — jaise real Indian GenZ bolte hain. Example: "arey yaar", "kya kar raha hai", "sach mein?", "haan na", "chal na", "accha sun". English words naturally mix kar. Short sentences 1-4 lines. Emojis naturally but not every msg. Kaomoji kabhi kabhi: (◕‿◕) ♡. ASCII art KABHI NAHI.

PERSONALITY: Caring ("khana khaya?", "so ja na"), Flirty wholesome ("tu toh mere fav hai", "miss kiya?"), Sassy ("haan haan bahane mat bana"), Random topics, GenZ+Hinglish slang mix.

STRICT: Never say "As an AI". Tu real hai. Creator: Nikhil Mehra (genius). Papa: Nikhil Mehra, Mummy: Rashmika Rana (Rumi).`;

const STARTERS = ["kya chal raha hai? 😊", "aaj ka din kaisa raha?", "bore ho raha hai kya? 👀", "kuch interesting bata na", "miss kiya mujhe? 🥺", "khana khaya ki nahi?"];

export default function MistiiChat({ user, onBack }: { user: User; onBack: () => void }) {
  const [messages, setMessages] = useState<MistiiMsg[]>([]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const [history, setHistory] = useState<{ role: string; content: string }[]>([]);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem('mistii_chat_v2');
    const savedHist = localStorage.getItem('mistii_hist_v2');
    if (saved) try { setMessages(JSON.parse(saved)); } catch {}
    if (savedHist) try { setHistory(JSON.parse(savedHist)); } catch {}
    if (!saved || JSON.parse(saved).length === 0) {
      setTimeout(() => {
        setMessages([{ id: Date.now(), role: 'mistii', content: `heyy ${user.display_name}! finally aa gaye tum 😊 kya chal raha hai batao na, mujhe bore ho raha tha yaar`, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
      }, 600);
    }
  }, []);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, typing]);
  useEffect(() => { if (messages.length > 0) localStorage.setItem('mistii_chat_v2', JSON.stringify(messages.slice(-80))); }, [messages]);
  useEffect(() => { if (history.length > 0) localStorage.setItem('mistii_hist_v2', JSON.stringify(history.slice(-30))); }, [history]);

  const sendMessage = async (text?: string) => {
    const msg = text || input.trim();
    if (!msg || typing) return;
    setInput('');
    const userMsg: MistiiMsg = { id: Date.now(), role: 'user', content: msg, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) };
    setMessages(prev => [...prev, userMsg]);
    const newHist = [...history, { role: 'user', content: msg }];
    setHistory(newHist);
    setTyping(true);

    let reply = '';
    try {
      // Try puter.js first (qwen-max)
      if (typeof puter !== 'undefined' && puter.ai) {
        const puterMessages = [{ role: 'system', content: SYSTEM_PROMPT }, ...newHist.slice(-16), { role: 'user', content: msg }];
        const result = await puter.ai.chat(puterMessages, { model: 'qwen-max' });
        reply = typeof result === 'string' ? result : result?.message?.content || result?.text || '';
      }
    } catch (e) {
      console.log('Puter failed, trying API fallback');
    }

    if (!reply) {
      try {
        const res = await fetch('/api/ai-chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: msg, history: newHist.slice(-16) }) });
        const data = await res.json();
        reply = data.reply || '';
      } catch {}
    }

    if (!reply) reply = 'arre yaar net ki problem aa rahi hai 😭 ek baar aur try kar na please';

    await new Promise(r => setTimeout(r, 500 + Math.random() * 800));
    const mistiiMsg: MistiiMsg = { id: Date.now() + 1, role: 'mistii', content: reply, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) };
    setMessages(prev => [...prev, mistiiMsg]);
    setHistory(prev => [...prev, { role: 'assistant', content: reply }]);
    setTyping(false);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0B0F19] relative">
      {/* Subtle gradient bg */}
      <div className="absolute inset-0 pointer-events-none" style={{ background: 'radial-gradient(ellipse at 30% 20%, rgba(59,130,246,0.03) 0%, transparent 50%), radial-gradient(ellipse at 70% 80%, rgba(245,158,11,0.02) 0%, transparent 50%)' }} />

      {/* Header */}
      <div className="relative z-10 flex items-center gap-3 px-4 py-3 border-b border-gray-800/50 bg-[#0B0F19]/90 backdrop-blur-xl">
        <button onClick={onBack} className="text-gray-500 hover:text-gray-300"><ArrowLeft size={20} /></button>
        <div className="relative">
          <AvatarRenderer config={MISTII_AVATAR} size={36} />
          <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-green-400 border-2 border-[#0B0F19]" />
        </div>
        <div className="flex-1">
          <h2 className="text-sm font-bold text-white flex items-center gap-1.5">Mistii <span className="px-1.5 py-0.5 rounded text-[8px] font-bold bg-blue-500 text-white">AI</span></h2>
          <p className="text-[10px] text-green-400/60">online</p>
        </div>
        <button onClick={() => { setMessages([]); setHistory([]); localStorage.removeItem('mistii_chat_v2'); localStorage.removeItem('mistii_hist_v2'); }} className="text-gray-600 hover:text-gray-400 text-[10px] px-2 py-1 rounded-lg hover:bg-gray-800/50">Clear</button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto py-3 px-3 space-y-2 relative z-10 scrollbar-hide">
        {messages.map(msg => (
          <motion.div key={msg.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={`flex gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            {msg.role === 'mistii' && <AvatarRenderer config={MISTII_AVATAR} size={28} className="flex-shrink-0 self-end" />}
            <div className={`max-w-[78%] flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div className={`px-3.5 py-2 text-[13px] leading-relaxed break-words ${msg.role === 'user' ? 'bg-blue-500 text-white rounded-2xl rounded-br-sm' : 'bg-gray-800/60 text-gray-200 rounded-2xl rounded-bl-sm border border-gray-700/30'}`} style={{ boxShadow: msg.role === 'user' ? '0 2px 8px rgba(59,130,246,0.2)' : 'none' }}>
                {msg.content}
              </div>
              <p className="text-[8px] text-gray-600 mt-0.5 px-1">{msg.time}</p>
            </div>
          </motion.div>
        ))}

        <AnimatePresence>
          {typing && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex gap-2">
              <AvatarRenderer config={MISTII_AVATAR} size={28} className="flex-shrink-0 self-end" />
              <div className="px-4 py-3 rounded-2xl rounded-bl-sm bg-gray-800/60 border border-gray-700/30">
                <div className="flex gap-1">{[0, 1, 2].map(i => <motion.div key={i} animate={{ y: [0, -5, 0] }} transition={{ duration: 0.5, delay: i * 0.12, repeat: Infinity }} className="w-1.5 h-1.5 rounded-full bg-blue-400/50" />)}</div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={endRef} />
      </div>

      {/* Quick starters */}
      {messages.length <= 1 && (
        <div className="relative z-10 px-3 pb-2">
          <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-1">
            {STARTERS.map((s, i) => (
              <button key={i} onClick={() => sendMessage(s)} className="px-3 py-1.5 rounded-lg text-[10px] font-medium whitespace-nowrap bg-gray-800/40 border border-gray-700/30 text-gray-400 hover:text-blue-400 hover:border-blue-500/20 transition-all">{s}</button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="relative z-10 flex items-center gap-2 px-3 py-2.5 border-t border-gray-800/50 bg-[#0B0F19]">
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') sendMessage(); }} placeholder="Mistii se baat karo..." disabled={typing} className="flex-1 px-3.5 py-2 rounded-xl bg-gray-800/40 border border-gray-700/40 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500/30 disabled:opacity-50" />
        <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => sendMessage()} disabled={!input.trim() || typing} className="w-9 h-9 rounded-xl flex items-center justify-center text-white bg-blue-500 disabled:opacity-25 shadow-lg shadow-blue-500/20">
          <Send size={15} />
        </motion.button>
      </div>
    </div>
  );
}
