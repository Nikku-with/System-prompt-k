import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CHAT_THEMES } from '../lib/themes';
import { X, Palette, Check } from 'lucide-react';

interface Props {
  currentTheme: string;
  onSelect: (themeId: string) => void;
  onClose: () => void;
}

export default function ThemePicker({ currentTheme, onSelect, onClose }: Props) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }} onClick={e => e.stopPropagation()} className="w-full max-w-md bg-[#1a0e2e]/98 backdrop-blur-xl rounded-3xl border border-white/10 p-5 shadow-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-black text-white flex items-center gap-2">
            <Palette size={20} className="text-pink-400" /> Chat Themes
          </h2>
          <button onClick={onClose} className="text-white/30 hover:text-white/60 transition-all"><X size={20} /></button>
        </div>
        <p className="text-white/30 text-xs mb-4">Pick a vibe for your chats ✨</p>
        <div className="grid grid-cols-2 gap-3 overflow-y-auto pr-1 flex-1">
          {CHAT_THEMES.map(theme => (
            <motion.button key={theme.id} whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} onClick={() => onSelect(theme.id)} className={`relative rounded-2xl overflow-hidden border-2 transition-all ${currentTheme === theme.id ? 'border-pink-400 shadow-lg shadow-pink-400/20' : 'border-white/5 hover:border-white/15'}`}>
              {/* Mini chat preview */}
              <div className="h-28 p-2.5 flex flex-col justify-end gap-1" style={{ background: theme.bg }}>
                {theme.pattern && <div className="absolute inset-0" style={{ background: theme.pattern }} />}
                <div className="flex gap-1.5 items-end relative z-10">
                  <div className="w-4 h-4 rounded-full bg-white/10 flex-shrink-0" />
                  <div className="px-2.5 py-1 rounded-xl rounded-bl-sm text-[8px] max-w-[70%]" style={{ background: theme.otherBubble, color: theme.otherText, border: '1px solid rgba(255,255,255,0.05)' }}>hey cutie! 🌸</div>
                </div>
                <div className="flex gap-1.5 items-end justify-end relative z-10">
                  <div className="px-2.5 py-1 rounded-xl rounded-br-sm text-[8px] max-w-[70%]" style={{ background: theme.ownBubble, color: theme.ownText }}>hiii ✨💖</div>
                </div>
                <div className="flex gap-1.5 items-end relative z-10">
                  <div className="w-4 h-4 rounded-full bg-white/10 flex-shrink-0" />
                  <div className="px-2.5 py-1 rounded-xl rounded-bl-sm text-[8px] max-w-[70%]" style={{ background: theme.otherBubble, color: theme.otherText, border: '1px solid rgba(255,255,255,0.05)' }}>love this theme!</div>
                </div>
              </div>
              <div className="px-3 py-2 bg-black/40 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm">{theme.emoji}</span>
                  <span className="text-[10px] font-bold text-white/80">{theme.name}</span>
                </div>
                {currentTheme === theme.id && <Check size={12} className="text-pink-400" />}
              </div>
            </motion.button>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}
