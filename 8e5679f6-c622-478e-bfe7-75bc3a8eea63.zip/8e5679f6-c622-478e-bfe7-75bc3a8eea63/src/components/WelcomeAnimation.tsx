import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, MessageCircleHeart, Users, Heart, Star, Bot } from 'lucide-react';

const features = [
  { icon: <Bot size={24} />, title: 'Mistii AI', desc: 'Your cute AI bestie who never sleeps', color: '#3B82F6' },
  { icon: <MessageCircleHeart size={24} />, title: 'Rich Chat', desc: 'Voice, files, stickers, spoilers & more', color: '#F59E0B' },
  { icon: <Users size={24} />, title: 'Groups & Channels', desc: 'Full Telegram-style admin tools', color: '#10B981' },
  { icon: <Heart size={24} />, title: 'Custom Everything', desc: 'Themes, avatars, usernames', color: '#F43F5E' },
  { icon: <Star size={24} />, title: 'Saved Messages', desc: 'Forward & bookmark anything', color: '#8B5CF6' },
];

export default function WelcomeAnimation({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const [showFeatures, setShowFeatures] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setStep(1), 600);
    const t2 = setTimeout(() => setStep(2), 1400);
    const t3 = setTimeout(() => setShowFeatures(true), 2000);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden bg-[#0B0F19]">
      <AnimatePresence>
        {step >= 0 && (
          <motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: 'spring', stiffness: 200 }} className="mb-6">
            <div className="w-20 h-20 rounded-2xl bg-blue-500 flex items-center justify-center shadow-2xl shadow-blue-500/30"><span className="text-3xl">💬</span></div>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {step >= 1 && <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-3xl font-bold text-white mb-1">CuteChat</motion.h1>}
      </AnimatePresence>
      <AnimatePresence>
        {step >= 2 && <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-gray-500 text-sm mb-8">The chat app that gets you ✨</motion.p>}
      </AnimatePresence>
      <AnimatePresence>
        {showFeatures && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col gap-2 mb-8 max-w-sm w-full px-6">
            {features.map((f, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: i % 2 === 0 ? -30 : 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }} className="flex items-center gap-3 bg-gray-800/30 rounded-xl px-4 py-3 border border-gray-700/30">
                <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: f.color + '15', color: f.color }}>{f.icon}</div>
                <div><p className="text-white text-sm font-semibold">{f.title}</p><p className="text-gray-500 text-[10px]">{f.desc}</p></div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showFeatures && (
          <motion.button initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} onClick={onComplete} className="px-8 py-3 rounded-xl bg-blue-500 hover:bg-blue-600 text-white font-bold flex items-center gap-2 shadow-lg shadow-blue-500/25 transition-all">
            <Sparkles size={16} /> Get Started
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
