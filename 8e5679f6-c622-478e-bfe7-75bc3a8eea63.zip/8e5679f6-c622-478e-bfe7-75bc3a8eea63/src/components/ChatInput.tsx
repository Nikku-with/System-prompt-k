import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Smile, Sticker, X, Reply, Mic, Paperclip, EyeOff, Clock, Image } from 'lucide-react';
import StickerPicker from './StickerPicker';
import EmojiPicker from './EmojiPicker';
import VoiceRecorder from './VoiceRecorder';
import type { Message } from '../lib/types';

// Quick reply templates
const QUICK_TEMPLATES = ['👍', '❤️', 'Thanks!', 'Got it', 'Sure!', 'lol', 'On my way', 'brb'];

interface Props {
  onSend: (content: string, type?: string, stickerUrl?: string) => void;
  onSendVoice?: (blob: Blob, duration: number) => void;
  onSendFile?: (file: File, isSpoiler?: boolean, isTimer?: boolean, timerViews?: number) => void;
  replyTo: Message | null;
  onCancelReply: () => void;
  disabled?: boolean;
  accentColor?: string;
  draft?: string;
  onDraftChange?: (text: string) => void;
  onSchedule?: () => void;
}

export default function ChatInput({ onSend, onSendVoice, onSendFile, replyTo, onCancelReply, disabled, accentColor = '#3B82F6', draft, onDraftChange, onSchedule }: Props) {
  const [text, setText] = useState(draft || '');
  const [showStickers, setShowStickers] = useState(false);
  const [showEmojis, setShowEmojis] = useState(false);
  const [showVoice, setShowVoice] = useState(false);
  const [showAttach, setShowAttach] = useState(false);
  const [showQuick, setShowQuick] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync draft
  useEffect(() => { if (draft !== undefined && draft !== text) setText(draft); }, [draft]);
  useEffect(() => { onDraftChange?.(text); }, [text]);

  const handleSend = () => {
    if (!text.trim()) return;
    if (text.startsWith('||') && text.endsWith('||') && text.length > 4) {
      onSend(text.slice(2, -2), 'spoiler');
    } else {
      onSend(text.trim());
    }
    setText('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  if (showVoice) {
    return <VoiceRecorder onSend={(blob, dur) => { onSendVoice?.(blob, dur); setShowVoice(false); }} onCancel={() => setShowVoice(false)} accentColor={accentColor} />;
  }

  return (
    <div className="relative">
      <AnimatePresence>
        {showStickers && <StickerPicker onSelect={url => { onSend('', 'sticker', url); setShowStickers(false); }} onClose={() => setShowStickers(false)} />}
        {showEmojis && <EmojiPicker onSelect={e => { setText(prev => prev + e); setShowEmojis(false); inputRef.current?.focus(); }} onClose={() => setShowEmojis(false)} />}
      </AnimatePresence>

      {/* Attach menu */}
      <AnimatePresence>
        {showAttach && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} className="absolute bottom-full left-10 mb-1 bg-[#1F2937] rounded-xl border border-gray-700/50 shadow-2xl py-1 min-w-[170px] z-50">
            <button onClick={() => { const i = document.createElement('input'); i.type = 'file'; i.accept = '*/*'; i.onchange = (e: any) => { const f = e.target.files?.[0]; if (f && onSendFile) onSendFile(f); }; i.click(); setShowAttach(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-gray-700/40 flex items-center gap-2"><Paperclip size={12} /> Any file</button>
            <button onClick={() => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*,video/*'; i.onchange = (e: any) => { const f = e.target.files?.[0]; if (f && onSendFile) onSendFile(f); }; i.click(); setShowAttach(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-gray-700/40 flex items-center gap-2"><Image size={12} /> Photo/Video</button>
            <button onClick={() => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.onchange = (e: any) => { const f = e.target.files?.[0]; if (f && onSendFile) onSendFile(f, true); }; i.click(); setShowAttach(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-gray-700/40 flex items-center gap-2"><EyeOff size={12} /> Spoiler media</button>
            <button onClick={() => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.onchange = (e: any) => { const f = e.target.files?.[0]; if (f && onSendFile) onSendFile(f, false, true, 1); }; i.click(); setShowAttach(false); }} className="w-full px-3 py-[6px] text-[11px] text-gray-300 hover:bg-gray-700/40 flex items-center gap-2"><Clock size={12} /> Timer (1x view)</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quick replies */}
      <AnimatePresence>
        {showQuick && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} className="absolute bottom-full right-2 mb-1 bg-[#1F2937] rounded-xl border border-gray-700/50 shadow-2xl p-2 z-50 flex flex-wrap gap-1 max-w-[200px]">
            {QUICK_TEMPLATES.map(t => (
              <button key={t} onClick={() => { onSend(t); setShowQuick(false); }} className="px-2 py-1 rounded-lg text-[10px] bg-gray-800/50 text-gray-300 hover:bg-gray-700/50 transition-all border border-gray-700/30">{t}</button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reply bar */}
      <AnimatePresence>
        {replyTo && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} className="flex items-center gap-2 px-3 py-1.5 border-t border-gray-800/30" style={{ background: 'rgba(0,0,0,0.3)' }}>
            <Reply size={12} style={{ color: accentColor }} />
            <div className="flex-1 min-w-0"><p className="text-[9px] font-bold" style={{ color: accentColor }}>{replyTo.sender_name}</p><p className="text-[10px] text-gray-500 truncate">{replyTo.content || '🌟'}</p></div>
            <button onClick={onCancelReply} className="text-gray-600 hover:text-gray-400"><X size={13} /></button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input bar */}
      <div className="flex items-center gap-1 px-2 py-2 border-t border-gray-800/30" style={{ background: 'rgba(11,15,25,0.95)' }}>
        <button onClick={() => { setShowAttach(!showAttach); setShowEmojis(false); setShowStickers(false); setShowQuick(false); }} className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${showAttach ? 'text-blue-400 bg-blue-400/10' : 'text-gray-500 hover:text-gray-300'}`}><Paperclip size={16} /></button>
        <button onClick={() => { setShowEmojis(!showEmojis); setShowStickers(false); setShowAttach(false); setShowQuick(false); }} className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${showEmojis ? 'text-blue-400 bg-blue-400/10' : 'text-gray-500 hover:text-gray-300'}`}><Smile size={16} /></button>
        <button onClick={() => { setShowStickers(!showStickers); setShowEmojis(false); setShowAttach(false); setShowQuick(false); }} className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${showStickers ? 'text-amber-400 bg-amber-400/10' : 'text-gray-500 hover:text-gray-300'}`}><Sticker size={16} /></button>

        <input ref={inputRef} value={text} onChange={e => setText(e.target.value)} onKeyDown={handleKeyDown} placeholder="Message..." disabled={disabled}
          className="flex-1 px-3 py-[7px] rounded-xl bg-gray-800/30 border border-gray-700/30 text-white text-[13px] placeholder-gray-500 focus:outline-none focus:border-blue-500/20 transition-all disabled:opacity-40" />

        {onSchedule && <button onClick={onSchedule} className="w-7 h-7 rounded-lg flex items-center justify-center text-gray-600 hover:text-amber-400 transition-all" title="Schedule"><Clock size={14} /></button>}
        <button onClick={() => setShowQuick(!showQuick)} className="w-7 h-7 rounded-lg flex items-center justify-center text-gray-600 hover:text-gray-300 transition-all" title="Quick replies">⚡</button>

        {text.trim() ? (
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={handleSend} className="w-8 h-8 rounded-xl flex items-center justify-center text-white" style={{ background: accentColor }}><Send size={14} /></motion.button>
        ) : (
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => setShowVoice(true)} className="w-8 h-8 rounded-xl flex items-center justify-center text-gray-400 hover:text-red-400 hover:bg-red-400/10 transition-all"><Mic size={16} /></motion.button>
        )}
      </div>
    </div>
  );
}
