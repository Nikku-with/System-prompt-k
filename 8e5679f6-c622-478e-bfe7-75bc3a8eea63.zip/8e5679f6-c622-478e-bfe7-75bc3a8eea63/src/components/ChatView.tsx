import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { Message, User, Group, Channel, DM, ChatTheme } from '../lib/types';
import { getTheme } from '../lib/themes';
import MessageBubble from './MessageBubble';
import ChatInput from './ChatInput';
import AvatarRenderer from './AvatarRenderer';
import { Users, Megaphone, Pin, Check, ArrowLeft, Palette, Copy, Share2, Settings, Search, X, ChevronDown, Clock, Zap, CheckCheck } from 'lucide-react';

interface Props {
  chatType: 'group' | 'channel' | 'dm';
  chatId: number;
  chatData: Group | Channel | DM | null;
  currentUser: User;
  allUsers: User[];
  onBack: () => void;
  onDM: (userId: number) => void;
  onOpenThemes: () => void;
  onOpenAdmin?: () => void;
  onForward?: (msg: Message) => void;
  onSave?: (msg: Message) => void;
}

export default function ChatView({ chatType, chatId, chatData, currentUser, allUsers, onBack, onDM, onOpenThemes, onOpenAdmin, onForward, onSave }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [editingMsg, setEditingMsg] = useState<Message | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [showInvite, setShowInvite] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showPinned, setShowPinned] = useState(false);
  const [showScrollDown, setShowScrollDown] = useState(false);
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [smartReplies, setSmartReplies] = useState<string[]>([]);
  const [showSchedule, setShowSchedule] = useState(false);
  const [scheduleDate, setScheduleDate] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const pollRef = useRef<any>(null);
  const draftKey = `draft_${chatType}_${chatId}`;

  const theme = getTheme(currentUser.chat_theme || 'midnight');

  // Draft messages - save unsent text locally
  const [draft, setDraft] = useState(() => localStorage.getItem(draftKey) || '');
  useEffect(() => { if (draft) localStorage.setItem(draftKey, draft); else localStorage.removeItem(draftKey); }, [draft, draftKey]);

  const fetchMessages = useCallback(async () => {
    try {
      const param = chatType === 'group' ? 'group_id' : chatType === 'channel' ? 'channel_id' : 'dm_id';
      const res = await fetch(`/api/messages?${param}=${chatId}`);
      const data = await res.json();
      setMessages(Array.isArray(data) ? data : []);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }, [chatType, chatId]);

  useEffect(() => {
    setMessages([]); setLoading(true); setReplyTo(null); setEditingMsg(null);
    setSelectMode(false); setSelectedIds(new Set()); setSmartReplies([]);
    fetchMessages();
    pollRef.current = setInterval(fetchMessages, 3000);
    return () => clearInterval(pollRef.current);
  }, [fetchMessages]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  // Scroll detection for scroll-to-bottom button
  const handleScroll = () => {
    const el = scrollContainerRef.current;
    if (el) setShowScrollDown(el.scrollHeight - el.scrollTop - el.clientHeight > 200);
  };

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

  // ===== FEATURE: Send Message (with draft clearing) =====
  const sendMessage = async (content: string, type = 'text', stickerUrl?: string) => {
    const body: any = {
      sender_id: currentUser.id, sender_name: currentUser.display_name,
      sender_avatar: currentUser.avatar_config, content, message_type: type,
      sticker_url: stickerUrl || null,
    };
    if (chatType === 'group') body.group_id = chatId;
    if (chatType === 'channel') body.channel_id = chatId;
    if (chatType === 'dm') body.dm_id = chatId;
    if (replyTo) {
      body.reply_to_id = replyTo.id;
      body.reply_to_content = replyTo.content || 'Sticker';
      body.reply_to_name = replyTo.sender_name;
    }
    if (showSchedule && scheduleDate) {
      body.scheduled_at = scheduleDate;
      setShowSchedule(false); setScheduleDate('');
    }
    try {
      await fetch('/api/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      setReplyTo(null); setDraft(''); localStorage.removeItem(draftKey);
      fetchMessages();
    } catch (err) { console.error(err); }
  };

  // ===== FEATURE: Edit Message =====
  const handleEdit = async (msg: Message) => { setEditingMsg(msg); };
  const saveEdit = async (newContent: string) => {
    if (!editingMsg) return;
    await fetch('/api/messages', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: editingMsg.id, content: newContent }) });
    setEditingMsg(null); fetchMessages();
  };

  // ===== FEATURE: Reactions =====
  const handleReact = async (msgId: number, emoji: string) => {
    const msg = messages.find(m => m.id === msgId); if (!msg) return;
    const reactions = (() => { try { return JSON.parse(msg.reactions || '{}'); } catch { return {}; } })();
    reactions[emoji] = (reactions[emoji] || 0) + 1;
    await fetch('/api/messages', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: msgId, reactions: JSON.stringify(reactions) }) });
    fetchMessages();
  };

  // ===== FEATURE: Pin (multiple pins supported) =====
  const handlePin = async (msgId: number) => {
    const msg = messages.find(m => m.id === msgId); if (!msg) return;
    await fetch('/api/messages', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: msgId, is_pinned: !msg.is_pinned }) });
    fetchMessages();
  };

  // ===== FEATURE: Delete for all =====
  const handleDelete = async (msgId: number) => {
    await fetch('/api/messages', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: msgId }) });
    fetchMessages();
  };

  // ===== FEATURE: Bulk delete/forward =====
  const handleBulkDelete = async () => {
    if (selectedIds.size === 0) return;
    await fetch('/api/messages', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ bulk_ids: [...selectedIds] }) });
    setSelectMode(false); setSelectedIds(new Set()); fetchMessages();
  };

  const handleBulkForward = () => {
    if (selectedIds.size === 0 || !onForward) return;
    const firstMsg = messages.find(m => selectedIds.has(m.id));
    if (firstMsg) onForward(firstMsg);
    setSelectMode(false); setSelectedIds(new Set());
  };

  const toggleSelect = (id: number) => {
    const s = new Set(selectedIds);
    if (s.has(id)) s.delete(id); else s.add(id);
    setSelectedIds(s);
  };

  // ===== FEATURE: AI Smart Reply =====
  const fetchSmartReplies = async (lastMsg: string) => {
    try {
      const res = await fetch('/api/ai-tools', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'smart_reply', text: lastMsg }) });
      const data = await res.json();
      if (data.replies) setSmartReplies(data.replies);
    } catch { setSmartReplies([]); }
  };

  useEffect(() => {
    if (messages.length > 0) {
      const last = messages[messages.length - 1];
      if (last.sender_id !== currentUser.id && last.message_type === 'text') {
        fetchSmartReplies(last.content);
      } else { setSmartReplies([]); }
    }
  }, [messages]);

  // ===== FEATURE: Copy Message Link =====
  const copyMessageLink = (msgId: number) => {
    const base = window.location.origin;
    navigator.clipboard.writeText(`${base}?msg=${msgId}`);
  };

  // ===== FEATURE: Translate =====
  const handleTranslate = async (msgId: number) => {
    const msg = messages.find(m => m.id === msgId); if (!msg) return;
    try {
      const res = await fetch('/api/ai-tools', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'translate', text: msg.content, target_lang: 'English' }) });
      const data = await res.json();
      if (data.translated) alert(`Translation:\n${data.translated}`);
    } catch {}
  };

  // In-chat search filter
  const displayMessages = searchQuery
    ? messages.filter(m => m.content.toLowerCase().includes(searchQuery.toLowerCase()))
    : messages;

  const pinnedMessages = messages.filter(m => m.is_pinned);

  const getChatTitle = () => {
    if (chatType === 'dm') {
      const dm = chatData as DM;
      const partnerId = dm.user1_id === currentUser.id ? dm.user2_id : dm.user1_id;
      return allUsers.find(u => u.id === partnerId)?.display_name || 'Unknown';
    }
    return (chatData as Group | Channel)?.name || 'Chat';
  };

  const getChatSubtitle = () => {
    if (chatType === 'group') return `${(chatData as Group)?.member_count || 0} members`;
    if (chatType === 'channel') return `${(chatData as Channel)?.subscriber_count || 0} subscribers`;
    const dm = chatData as DM;
    const pid = dm?.user1_id === currentUser.id ? dm?.user2_id : dm?.user1_id;
    const p = allUsers.find(u => u.id === pid);
    return `@${(p as any)?.username || p?.anon_id || '?'}`;
  };

  const getInviteLink = () => {
    const code = (chatData as any)?.invite_code || '';
    return `${window.location.origin}?join=${chatType === 'group' ? 'g' : 'c'}_${code}`;
  };

  return (
    <div className="flex-1 flex flex-col h-full relative overflow-hidden">
      <div className="absolute inset-0" style={{ background: theme.bg }} />
      {theme.pattern && <div className="absolute inset-0" style={{ background: theme.pattern }} />}

      {/* ===== HEADER ===== */}
      <div className="relative z-10 flex items-center gap-2 px-3 py-2.5 border-b border-gray-800/30 backdrop-blur-xl" style={{ background: 'rgba(0,0,0,0.4)' }}>
        <button onClick={onBack} className="md:hidden text-gray-500 hover:text-gray-300"><ArrowLeft size={18} /></button>
        <div className="w-9 h-9 rounded-xl flex items-center justify-center overflow-hidden" style={{ background: theme.accent + '18' }}>
          {chatType === 'group' ? <Users size={16} style={{ color: theme.accent }} /> : chatType === 'channel' ? <Megaphone size={16} style={{ color: theme.accent }} /> : (() => {
            const dm = chatData as DM; const pid = dm?.user1_id === currentUser.id ? dm?.user2_id : dm?.user1_id;
            return <AvatarRenderer config={allUsers.find(u => u.id === pid)?.avatar_config || '{}'} size={36} />;
          })()}
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="text-sm font-bold text-white truncate">{getChatTitle()}</h2>
          <p className="text-[9px]" style={{ color: theme.accent + '70' }}>{getChatSubtitle()}</p>
        </div>
        <div className="flex gap-0.5">
          <button onClick={() => setShowSearch(!showSearch)} className="w-7 h-7 rounded-lg flex items-center justify-center text-gray-500 hover:text-gray-300 transition-all"><Search size={14} /></button>
          <button onClick={onOpenThemes} className="w-7 h-7 rounded-lg flex items-center justify-center text-gray-500 hover:text-gray-300 transition-all"><Palette size={14} /></button>
          {chatType !== 'dm' && <button onClick={() => { navigator.clipboard.writeText(getInviteLink()); setCopiedLink(true); setTimeout(() => setCopiedLink(false), 1500); }} className="w-7 h-7 rounded-lg flex items-center justify-center text-gray-500 hover:text-gray-300 transition-all">{copiedLink ? <Check size={14} className="text-green-400" /> : <Share2 size={14} />}</button>}
          {onOpenAdmin && chatType === 'group' && <button onClick={onOpenAdmin} className="w-7 h-7 rounded-lg flex items-center justify-center text-gray-500 hover:text-gray-300 transition-all"><Settings size={14} /></button>}
          {pinnedMessages.length > 0 && <button onClick={() => setShowPinned(!showPinned)} className="w-7 h-7 rounded-lg flex items-center justify-center text-gray-500 hover:text-gray-300 transition-all relative"><Pin size={14} /><span className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full text-[7px] text-white flex items-center justify-center font-bold" style={{ background: theme.accent }}>{pinnedMessages.length}</span></button>}
        </div>
      </div>

      {/* ===== IN-CHAT SEARCH ===== */}
      <AnimatePresence>
        {showSearch && (
          <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="relative z-10 overflow-hidden border-b border-gray-800/30" style={{ background: 'rgba(0,0,0,0.3)' }}>
            <div className="flex items-center gap-2 px-3 py-2">
              <Search size={13} className="text-gray-500" />
              <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search in chat..." autoFocus className="flex-1 bg-transparent text-white text-xs placeholder-gray-500 focus:outline-none" />
              {searchQuery && <span className="text-[9px] text-gray-500">{displayMessages.length} found</span>}
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="text-gray-500 hover:text-gray-300"><X size={14} /></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== PINNED MESSAGES PANEL ===== */}
      <AnimatePresence>
        {showPinned && pinnedMessages.length > 0 && (
          <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="relative z-10 overflow-hidden border-b border-gray-800/30 max-h-32 overflow-y-auto" style={{ background: 'rgba(0,0,0,0.35)' }}>
            <div className="px-3 py-2 space-y-1">
              <p className="text-[9px] text-gray-500 font-bold uppercase flex items-center gap-1"><Pin size={9} /> Pinned ({pinnedMessages.length})</p>
              {pinnedMessages.map(m => (
                <div key={m.id} className="flex items-center gap-2 px-2 py-1 rounded-lg bg-white/[0.03]">
                  <span className="text-[10px] font-semibold" style={{ color: theme.accent }}>{m.sender_name}</span>
                  <span className="text-[10px] text-gray-400 truncate flex-1">{m.content}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== BULK SELECT BAR ===== */}
      <AnimatePresence>
        {selectMode && (
          <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="relative z-10 overflow-hidden border-b border-gray-800/30" style={{ background: 'rgba(0,0,0,0.4)' }}>
            <div className="flex items-center gap-2 px-3 py-2">
              <span className="text-xs text-gray-300">{selectedIds.size} selected</span>
              <div className="flex-1" />
              <button onClick={handleBulkForward} className="px-2 py-1 rounded text-[10px] bg-blue-500/10 text-blue-400 font-bold">Forward</button>
              <button onClick={handleBulkDelete} className="px-2 py-1 rounded text-[10px] bg-red-500/10 text-red-400 font-bold">Delete</button>
              <button onClick={() => { setSelectMode(false); setSelectedIds(new Set()); }} className="text-gray-500 hover:text-gray-300"><X size={14} /></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== MESSAGES ===== */}
      <div ref={scrollContainerRef} onScroll={handleScroll} className="flex-1 overflow-y-auto py-2 space-y-0.5 scrollbar-hide relative z-10">
        {loading ? (
          <div className="flex items-center justify-center h-full"><span className="text-2xl animate-pulse">💬</span></div>
        ) : displayMessages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full">
            <span className="text-4xl mb-2">💬</span>
            <p className="text-sm font-semibold text-gray-500">{searchQuery ? 'No results' : 'No messages yet'}</p>
            <p className="text-xs text-gray-600 mt-0.5">{searchQuery ? 'Try a different search' : 'Say something!'}</p>
          </div>
        ) : (
          displayMessages.map(msg => (
            <div key={msg.id} className={`flex items-start ${selectMode ? 'cursor-pointer' : ''}`} onClick={() => selectMode && toggleSelect(msg.id)}>
              {selectMode && (
                <div className="flex items-center justify-center w-8 flex-shrink-0 self-center">
                  <div className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-all ${selectedIds.has(msg.id) ? 'bg-blue-500 border-blue-500' : 'border-gray-600'}`}>
                    {selectedIds.has(msg.id) && <Check size={10} className="text-white" />}
                  </div>
                </div>
              )}
              <div className="flex-1">
                <MessageBubble
                  message={msg} isOwn={msg.sender_id === currentUser.id} theme={theme}
                  onReply={setReplyTo} onTag={() => {}} onReact={handleReact} onPin={handlePin}
                  onDelete={handleDelete} onDM={chatType !== 'dm' ? onDM : undefined}
                  onForward={onForward} onSave={onSave} onEdit={handleEdit}
                  onTranslate={handleTranslate} onCopyLink={copyMessageLink}
                  onSelect={() => { setSelectMode(true); toggleSelect(msg.id); }}
                />
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* ===== SCROLL TO BOTTOM ===== */}
      <AnimatePresence>
        {showScrollDown && (
          <motion.button initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }} onClick={scrollToBottom} className="absolute bottom-20 right-4 z-20 w-9 h-9 rounded-full flex items-center justify-center shadow-lg" style={{ background: theme.accent }}>
            <ChevronDown size={16} className="text-white" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* ===== AI SMART REPLIES ===== */}
      <AnimatePresence>
        {smartReplies.length > 0 && !replyTo && !editingMsg && (
          <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="relative z-10 flex gap-1.5 px-3 py-1.5 overflow-x-auto scrollbar-hide" style={{ background: 'rgba(0,0,0,0.2)' }}>
            <Zap size={11} className="text-amber-400 flex-shrink-0 mt-1" />
            {smartReplies.map((r, i) => (
              <button key={i} onClick={() => sendMessage(r)} className="px-2.5 py-1 rounded-lg text-[10px] font-medium whitespace-nowrap border transition-all hover:border-blue-500/30 hover:text-blue-300" style={{ background: 'rgba(255,255,255,0.03)', borderColor: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.5)' }}>{r}</button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== SCHEDULE PANEL ===== */}
      <AnimatePresence>
        {showSchedule && (
          <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="relative z-10 overflow-hidden border-t border-gray-800/30" style={{ background: 'rgba(0,0,0,0.4)' }}>
            <div className="flex items-center gap-2 px-3 py-2">
              <Clock size={13} className="text-amber-400" />
              <input type="datetime-local" value={scheduleDate} onChange={e => setScheduleDate(e.target.value)} className="flex-1 bg-transparent text-white text-xs focus:outline-none" />
              <button onClick={() => setShowSchedule(false)} className="text-gray-500 hover:text-gray-300"><X size={14} /></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== EDIT MODE ===== */}
      <AnimatePresence>
        {editingMsg && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }} className="relative z-10 border-t border-gray-800/30" style={{ background: 'rgba(0,0,0,0.4)' }}>
            <div className="px-3 py-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] text-amber-400 font-bold">Editing message</span>
                <button onClick={() => setEditingMsg(null)} className="text-gray-500 hover:text-gray-300"><X size={14} /></button>
              </div>
              <form onSubmit={e => { e.preventDefault(); const input = (e.target as HTMLFormElement).elements.namedItem('editInput') as HTMLInputElement; saveEdit(input.value); }} className="flex gap-2">
                <input name="editInput" defaultValue={editingMsg.content} className="flex-1 px-3 py-2 rounded-lg bg-gray-800/50 border border-gray-700/50 text-white text-sm focus:outline-none focus:border-blue-500/30" autoFocus />
                <button type="submit" className="px-3 py-2 rounded-lg bg-blue-500 text-white text-xs font-bold">Save</button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== INPUT ===== */}
      {!editingMsg && (
        <div className="relative z-10">
          <ChatInput
            onSend={sendMessage} replyTo={replyTo} onCancelReply={() => setReplyTo(null)}
            accentColor={theme.accent} draft={draft} onDraftChange={setDraft}
            onSchedule={() => setShowSchedule(!showSchedule)}
          />
        </div>
      )}
    </div>
  );
}
