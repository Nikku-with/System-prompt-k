import React, { useState } from 'react';
import { motion } from 'framer-motion';
import type { User, Group, Channel, DM } from '../lib/types';
import AvatarRenderer from './AvatarRenderer';
import { MessageCircle, Users, Megaphone, Plus, Search, LogOut, Sparkles, Bookmark } from 'lucide-react';

type Tab = 'dms' | 'groups' | 'channels';

interface Props {
  user: User; dms: DM[]; groups: Group[]; channels: Channel[];
  activeChat: { type: string; id: number } | null;
  onSelectDM: (dm: DM) => void; onSelectGroup: (group: Group) => void; onSelectChannel: (channel: Channel) => void;
  onCreateGroup: () => void; onCreateChannel: () => void; onExplore: () => void;
  onProfile: () => void; onLogout: () => void; onSearchUsers: () => void;
  onMistii: () => void; onSaved: () => void; allUsers: User[];
}

const MISTII_AVATAR = '{"bgColor":"#3B82F6","skinColor":"#FFE0BD","hairStyle":"wavy","hairColor":"#F59E0B","eyeStyle":"sparkle","mouthStyle":"smile","accessory":"tiara","outfit":"dress","outfitColor":"#3B82F6","facialHair":"none","blush":true,"sparkles":true}';

export default function Sidebar({ user, dms, groups, channels, activeChat, onSelectDM, onSelectGroup, onSelectChannel, onCreateGroup, onCreateChannel, onExplore, onProfile, onLogout, onSearchUsers, onMistii, onSaved, allUsers }: Props) {
  const [tab, setTab] = useState<Tab>('groups');
  const [search, setSearch] = useState('');

  const getDMPartner = (dm: DM) => {
    const pid = dm.user1_id === user.id ? dm.user2_id : dm.user1_id;
    return allUsers.find(u => u.id === pid);
  };

  const f = search.toLowerCase();
  const filteredGroups = groups.filter(g => g.name.toLowerCase().includes(f));
  const filteredChannels = channels.filter(c => c.name.toLowerCase().includes(f));
  const filteredDMs = dms.filter(dm => { const p = getDMPartner(dm); return p?.display_name.toLowerCase().includes(f) || (p as any)?.username?.toLowerCase().includes(f); });

  return (
    <div className="w-[280px] h-full flex flex-col bg-[#0B0F19] border-r border-gray-800/50">
      {/* Header */}
      <div className="p-3 border-b border-gray-800/50">
        <div className="flex items-center gap-2.5 mb-3">
          <button onClick={onProfile} className="hover:scale-105 transition-transform">
            <AvatarRenderer config={user.avatar_config} size={38} />
          </button>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-white truncate">{user.status_emoji} {user.display_name}</p>
            <p className="text-[10px] text-blue-400/50 font-mono truncate">@{user.username || user.anon_id}</p>
          </div>
          <button onClick={onLogout} className="w-7 h-7 rounded-lg flex items-center justify-center text-gray-600 hover:text-gray-400 hover:bg-gray-800/50 transition-all"><LogOut size={14} /></button>
        </div>

        {/* Saved Messages + Mistii */}
        <div className="flex gap-2 mb-2.5">
          <motion.button whileTap={{ scale: 0.97 }} onClick={onSaved} className="flex-1 flex items-center gap-2 px-2.5 py-2 rounded-xl bg-gray-800/30 border border-gray-700/30 hover:bg-gray-800/50 transition-all">
            <Bookmark size={13} className="text-blue-400" />
            <span className="text-[10px] font-semibold text-gray-400">Saved</span>
          </motion.button>
          <motion.button whileTap={{ scale: 0.97 }} onClick={onMistii} className="flex-1 flex items-center gap-2 px-2.5 py-2 rounded-xl border hover:border-blue-500/20 transition-all" style={{ background: 'linear-gradient(135deg, rgba(59,130,246,0.08), rgba(245,158,11,0.05))', borderColor: 'rgba(59,130,246,0.1)' }}>
            <Sparkles size={13} className="text-amber-400" />
            <span className="text-[10px] font-semibold text-gray-400">Mistii AI</span>
          </motion.button>
        </div>

        <div className="flex gap-1.5">
          <div className="relative flex-1">
            <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-600" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="w-full pl-8 pr-2 py-1.5 rounded-lg bg-gray-800/30 border border-gray-700/30 text-white text-[11px] placeholder-gray-600 focus:outline-none focus:border-blue-500/30 transition-all" />
          </div>
          <button onClick={onSearchUsers} className="w-7 h-7 rounded-lg flex items-center justify-center bg-blue-500/10 border border-blue-500/15 text-blue-400/60 hover:text-blue-400 transition-all" title="Find people"><Search size={13} /></button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-800/50">
        {[
          { id: 'dms' as Tab, icon: <MessageCircle size={12} />, label: 'DMs', count: dms.length },
          { id: 'groups' as Tab, icon: <Users size={12} />, label: 'Groups', count: groups.length },
          { id: 'channels' as Tab, icon: <Megaphone size={12} />, label: 'Channels', count: channels.length },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`flex-1 py-2 text-[10px] font-bold flex items-center justify-center gap-1 border-b-2 transition-all ${tab === t.id ? 'text-blue-400 border-blue-400' : 'text-gray-600 border-transparent hover:text-gray-400'}`}>
            {t.icon} {t.label}
            {t.count > 0 && <span className="px-1 rounded text-[8px] bg-blue-500/10 text-blue-400/60">{t.count}</span>}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto py-1 scrollbar-hide">
        {tab === 'dms' && (
          <>
            <button onClick={onSearchUsers} className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-gray-800/30 transition-all text-gray-600 hover:text-blue-400">
              <div className="w-8 h-8 rounded-lg bg-blue-500/8 flex items-center justify-center border border-blue-500/10"><Plus size={14} /></div>
              <span className="text-[11px] font-semibold">New Message</span>
            </button>
            {filteredDMs.length === 0 && dms.length === 0 ? (
              <div className="text-center py-8"><span className="text-xl block mb-1">💌</span><p className="text-gray-600 text-[11px]">No conversations yet</p></div>
            ) : filteredDMs.map(dm => {
              const p = getDMPartner(dm);
              return (
                <button key={dm.id} onClick={() => onSelectDM(dm)} className={`w-full flex items-center gap-2.5 px-3 py-2 transition-all ${activeChat?.type === 'dm' && activeChat.id === dm.id ? 'bg-blue-500/8 border-r-2 border-blue-400' : 'hover:bg-gray-800/20'}`}>
                  <AvatarRenderer config={p?.avatar_config || '{}'} size={34} />
                  <div className="flex-1 min-w-0 text-left">
                    <p className="text-[12px] font-semibold text-gray-200 truncate">{p?.status_emoji} {p?.display_name || 'Unknown'}</p>
                    <p className="text-[9px] text-gray-600 font-mono">@{(p as any)?.username || p?.anon_id}</p>
                  </div>
                </button>
              );
            })}
          </>
        )}

        {tab === 'groups' && (
          <>
            <button onClick={onCreateGroup} className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-gray-800/30 transition-all text-gray-600 hover:text-blue-400">
              <div className="w-8 h-8 rounded-lg bg-blue-500/8 flex items-center justify-center border border-blue-500/10"><Plus size={14} /></div>
              <span className="text-[11px] font-semibold">Create Group</span>
            </button>
            <button onClick={onExplore} className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-gray-800/30 transition-all text-gray-600 hover:text-emerald-400">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/8 flex items-center justify-center border border-emerald-500/10"><Search size={14} /></div>
              <span className="text-[11px] font-semibold">Explore</span>
            </button>
            {filteredGroups.map(g => (
              <button key={g.id} onClick={() => onSelectGroup(g)} className={`w-full flex items-center gap-2.5 px-3 py-2 transition-all ${activeChat?.type === 'group' && activeChat.id === g.id ? 'bg-blue-500/8 border-r-2 border-blue-400' : 'hover:bg-gray-800/20'}`}>
                <div className="w-8 h-8 rounded-lg bg-gray-800/50 flex items-center justify-center text-sm font-bold text-gray-400 border border-gray-700/30">{g.name.charAt(0)}</div>
                <div className="flex-1 min-w-0 text-left">
                  <p className="text-[12px] font-semibold text-gray-200 truncate">{g.name}</p>
                  <p className="text-[9px] text-gray-600">{g.member_count} members</p>
                </div>
              </button>
            ))}
          </>
        )}

        {tab === 'channels' && (
          <>
            <button onClick={onCreateChannel} className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-gray-800/30 transition-all text-gray-600 hover:text-amber-400">
              <div className="w-8 h-8 rounded-lg bg-amber-500/8 flex items-center justify-center border border-amber-500/10"><Plus size={14} /></div>
              <span className="text-[11px] font-semibold">Create Channel</span>
            </button>
            <button onClick={onExplore} className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-gray-800/30 transition-all text-gray-600 hover:text-blue-400">
              <div className="w-8 h-8 rounded-lg bg-blue-500/8 flex items-center justify-center border border-blue-500/10"><Search size={14} /></div>
              <span className="text-[11px] font-semibold">Explore</span>
            </button>
            {filteredChannels.map(ch => (
              <button key={ch.id} onClick={() => onSelectChannel(ch)} className={`w-full flex items-center gap-2.5 px-3 py-2 transition-all ${activeChat?.type === 'channel' && activeChat.id === ch.id ? 'bg-amber-500/8 border-r-2 border-amber-400' : 'hover:bg-gray-800/20'}`}>
                <div className="w-8 h-8 rounded-lg bg-gray-800/50 flex items-center justify-center border border-gray-700/30"><Megaphone size={13} className="text-amber-400/50" /></div>
                <div className="flex-1 min-w-0 text-left">
                  <p className="text-[12px] font-semibold text-gray-200 truncate">{ch.name}</p>
                  <p className="text-[9px] text-gray-600">{ch.subscriber_count} subs</p>
                </div>
              </button>
            ))}
          </>
        )}
      </div>
    </div>
  );
}
