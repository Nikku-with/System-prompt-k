import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

const EMOJI_CATEGORIES = [
  { label: '😊 Smileys', emojis: ['😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😜', '🤪', '😝', '🤑', '🤗', '🤭', '🫢', '🫣', '🤔', '🫡', '🤐', '🤨', '😐', '😑', '😶', '🫥', '😏', '😒', '🙄', '😬', '🫨', '😮', '😤', '😠', '😡', '🤬', '😢', '😭', '😩', '😱', '🥵', '🥶', '😳', '🤯', '🤠', '🥳', '🥸', '😎', '🤓', '🧐'] },
  { label: '💖 Hearts', emojis: ['❤️', '🩷', '🧡', '💛', '💚', '💙', '💜', '🤎', '🖤', '🩶', '🤍', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '❣️', '💌', '💔'] },
  { label: '👋 Gestures', emojis: ['👋', '🤚', '🖐️', '✋', '🖖', '🫡', '🫢', '🫣', '🫤', '👌', '🤌', '🤏', '✌️', '🤞', '🫠', '🤟', '🤘', '🤙', '👈', '👉', '👆', '👇', '☝️', '👍', '👎', '✊', '👊', '🤛', '🤜', '👏', '🙌', '🫦', '👐', '🤲', '🤝', '🙏'] },
  { label: '🌸 Nature', emojis: ['🌸', '🌹', '🌺', '🌻', '🌼', '🌷', '🌿', '☘️', '🍀', '🍃', '🍂', '🍁', '🍄', '🪷', '🌾', '💐', '🪴', '🪻', '🪹', '🪺', '🌞', '🌝', '🌛', '🌜', '⭐', '🌟', '💫', '✨', '🌈', '☀️', '⛅', '🌤️', '🌥️'] },
  { label: '🐱 Animals', emojis: ['🐱', '🐶', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🐒', '🐔', '🐧', '🐦', '🦅', '🦉', '🦇', '🐺', '🐴', '🦄', '🐝', '🪱', '🦋', '🐌', '🐛', '🐞'] },
  { label: '🍔 Food', emojis: ['🍔', '🍕', '🌮', '🌯', '🍜', '🍣', '🍰', '🍩', '🍦', '🍧', '🍓', '🍑', '🍉', '🍎', '🍊', '🍋', '🍌', '🥝', '🍇', '🫐', '🍒', '🥭', '🍍', '🥥', '🍵', '☕', '🧃', '🧁', '🍪', '🍫', '🍬', '🍭'] },
  { label: '🎉 Fun', emojis: ['🎉', '🎊', '🎈', '🎆', '🎇', '🧨', '🎵', '🎶', '🎤', '🎧', '🎸', '🎹', '🎺', '🎻', '🥁', '🎮', '🎲', '🧩', '🎭', '🔮', '🪩', '🎀', '💎', '👑', '🪄', '🎯', '🌟'] },
];

export default function EmojiPicker({ onSelect, onClose }: { onSelect: (emoji: string) => void, onClose: () => void }) {
  const [catIdx, setCatIdx] = useState(0);

  return (
    <motion.div initial={{ opacity: 0, y: 20, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.95 }} className="absolute bottom-full left-0 right-0 mb-2 bg-[#1a0e2e]/95 backdrop-blur-xl rounded-2xl border border-white/10 shadow-2xl overflow-hidden" style={{ height: '320px' }}>
      <div className="flex items-center justify-between p-3 border-b border-white/5">
        <h3 className="text-sm font-bold text-white/80">😊 Emojis</h3>
        <button onClick={onClose} className="text-white/40 hover:text-white/70"><X size={16} /></button>
      </div>
      <div className="flex gap-1 px-3 py-2 overflow-x-auto scrollbar-hide border-b border-white/5">
        {EMOJI_CATEGORIES.map((cat, i) => (
          <button key={i} onClick={() => setCatIdx(i)} className={`px-2.5 py-1 rounded-lg text-xs whitespace-nowrap transition-all ${i === catIdx ? 'bg-pink-400/20 text-pink-300' : 'text-white/40 hover:text-white/60'}`}>
            {cat.label}
          </button>
        ))}
      </div>
      <div className="overflow-y-auto p-3" style={{ height: 'calc(100% - 90px)' }}>
        <div className="grid grid-cols-8 gap-1">
          {EMOJI_CATEGORIES[catIdx].emojis.map((e, i) => (
            <motion.button key={i} whileHover={{ scale: 1.3 }} whileTap={{ scale: 0.9 }} onClick={() => onSelect(e)} className="w-9 h-9 rounded-lg flex items-center justify-center text-xl hover:bg-white/10 transition-all">
              {e}
            </motion.button>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
