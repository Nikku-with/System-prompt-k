import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { User } from '../lib/types';
import AvatarRenderer from './AvatarRenderer';
import { Search, X, MessageCircle, AtSign, Sparkles, UserPlus } from 'lucide-react';

const MISTII_AVATAR = '{"bgColor":"#3B82F6","skinColor":"#FFE0BD","hairStyle":"wavy","hairColor":"#F59E0B","eyeStyle":"sparkle","mouthStyle":"smile","accessory":"tiara","outfit":"dress","outfitColor":"#3B82F6","facialHair":"none","blush":true,"sparkles":true}';

interface Props {
  currentUserId: number;
  onDM: (userId: number) => void;
  onClose: () => void;
  onMistii?: () => void;
}

export default function UserSearch({ currentUserId, onDM, onClose, onMistii }: Props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const showMistii = !query || 'mistii'.includes(query.toLowerCase());

  useEffect(() => {
    if (query.length < 2) { setResults([]); setSearched(false); return; }
    const timer = setTimeout(async () => {
      setLoading(true); setSearched(true);
      try {
        const res = await fetch(`/api/users?search=${encodeURIComponent(query)}`);
        const data = await res.json();
        setResults(Array.isArray(data) ? data.filter((u: User) => u.id !== currentUserId) : []);
      } catch { setResults([]); }
      finally { setLoading(false); }
    }, 400);
    return () => clearTimeout(timer);
  }, [query, currentUserId]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <motion.div initial={{ scale: 0.92, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.92, y: 20 }} onClick={e => e.stopPropagation()} className="w-full max-w-sm bg-[#111827] rounded-2xl border border-gray-700/50 shadow-2xl overflow-hidden">
        <div className="p-4 border-b border-gray-800/50">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-white flex items-center gap-2"><Search size={14} className="text-blue-400" /> Find People</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-300"><X size={18} /></button>
          </div>
          <div className="relative">
            <AtSign size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-400/40" />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="search username or name..." autoFocus className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-gray-800/50 border border-gray-700/50 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500/30" />
          </div>
        </div>

        <div className="max-h-72 overflow-y-auto p-2">
          {/* Mistii AI always on top */}
          {showMistii && onMistii && (
            <button onClick={() => { onMistii(); onClose(); }} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-gray-800/50 transition-all group">
              <AvatarRenderer config={MISTII_AVATAR} size={36} />
              <div className="flex-1 text-left">
                <p className="text-sm font-bold text-white flex items-center gap-1">Mistii <span className="px-1 py-0 rounded text-[7px] font-bold bg-blue-500 text-white">AI</span></p>
                <p className="text-[10px] text-green-400/50">always online</p>
              </div>
              <span className="text-xs text-gray-500 group-hover:text-blue-400 transition-all">Chat →</span>
            </button>
          )}

          {loading ? (
            <div className="flex items-center justify-center py-8"><Sparkles size={18} className="text-blue-400 animate-spin" /></div>
          ) : results.length === 0 ? (
            <div className="text-center py-6">
              {searched ? <><span className="text-xl block mb-1">😔</span><p className="text-gray-500 text-xs">No one found</p></> : <><span className="text-xl block mb-1">🔍</span><p className="text-gray-500 text-xs">Type to search users</p></>}
            </div>
          ) : (
            results.map((u, i) => (
              <motion.div key={u.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-gray-800/50 transition-all group">
                <AvatarRenderer config={u.avatar_config} size={36} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-200 truncate">{u.status_emoji} {u.display_name}</p>
                  <p className="text-[10px] text-blue-400/40 font-mono">@{u.username || u.anon_id}</p>
                </div>
                <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => { onDM(u.id); onClose(); }} className="px-2.5 py-1.5 rounded-lg bg-blue-500 text-white text-[10px] font-bold flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all shadow-lg shadow-blue-500/20">
                  <MessageCircle size={10} /> DM
                </motion.button>
              </motion.div>
            ))
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
