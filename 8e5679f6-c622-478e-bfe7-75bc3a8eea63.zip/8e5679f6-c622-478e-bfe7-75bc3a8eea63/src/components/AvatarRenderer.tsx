import React from 'react';
import type { AvatarConfig } from '../lib/types';
import { DEFAULT_AVATAR } from '../lib/avatarParts';

interface Props {
  config: AvatarConfig | string;
  size?: number;
  className?: string;
}

export default function AvatarRenderer({ config, size = 48, className = '' }: Props) {
  let c: AvatarConfig;
  if (typeof config === 'string') {
    try { c = JSON.parse(config); } catch { c = DEFAULT_AVATAR; }
  } else {
    c = config || DEFAULT_AVATAR;
  }
  if (!c.bgColor) c = { ...DEFAULT_AVATAR, ...c };

  const s = size;
  const cx = s / 2;
  const cy = s / 2;
  const headR = s * 0.32;
  const eyeY = cy - headR * 0.1;
  const eyeSpacing = headR * 0.35;
  const mouthY = cy + headR * 0.3;

  const renderHair = () => {
    const hc = c.hairColor || '#2C1B18';
    switch (c.hairStyle) {
      case 'long': return <><ellipse cx={cx} cy={cy - headR * 0.3} rx={headR * 1.15} ry={headR * 0.9} fill={hc} /><rect x={cx - headR * 1.1} y={cy} width={headR * 2.2} height={headR * 1.2} rx={headR * 0.3} fill={hc} /></>;
      case 'curly': return <><ellipse cx={cx} cy={cy - headR * 0.35} rx={headR * 1.2} ry={headR * 0.95} fill={hc} />{[...Array(8)].map((_, i) => <circle key={i} cx={cx + Math.cos(i * 0.8) * headR * 1.05} cy={cy - headR * 0.2 + Math.sin(i * 0.8) * headR * 0.7} r={headR * 0.25} fill={hc} />)}</>;
      case 'bob': return <><ellipse cx={cx} cy={cy - headR * 0.25} rx={headR * 1.1} ry={headR * 0.85} fill={hc} /><rect x={cx - headR * 1.05} y={cy - headR * 0.1} width={headR * 2.1} height={headR * 0.6} rx={headR * 0.2} fill={hc} /></>;
      case 'ponytail': return <><ellipse cx={cx} cy={cy - headR * 0.35} rx={headR * 1.05} ry={headR * 0.8} fill={hc} /><ellipse cx={cx + headR * 0.9} cy={cy - headR * 0.1} rx={headR * 0.3} ry={headR * 0.7} fill={hc} /></>;
      case 'pigtails': return <><ellipse cx={cx} cy={cy - headR * 0.35} rx={headR * 1.05} ry={headR * 0.8} fill={hc} /><ellipse cx={cx - headR * 1} cy={cy + headR * 0.1} rx={headR * 0.25} ry={headR * 0.6} fill={hc} /><ellipse cx={cx + headR * 1} cy={cy + headR * 0.1} rx={headR * 0.25} ry={headR * 0.6} fill={hc} /></>;
      case 'mohawk': return <rect x={cx - headR * 0.15} y={cy - headR * 1.3} width={headR * 0.3} height={headR * 1} rx={headR * 0.1} fill={hc} />;
      case 'bun': return <><ellipse cx={cx} cy={cy - headR * 0.35} rx={headR * 1.05} ry={headR * 0.8} fill={hc} /><circle cx={cx} cy={cy - headR * 1.1} r={headR * 0.35} fill={hc} /></>;
      case 'wavy': return <><ellipse cx={cx} cy={cy - headR * 0.3} rx={headR * 1.15} ry={headR * 0.9} fill={hc} />{[0, 1, 2].map(i => <ellipse key={i} cx={cx - headR * 0.8 + i * headR * 0.8} cy={cy + headR * 0.4} rx={headR * 0.3} ry={headR * 0.5} fill={hc} />)}</>;
      case 'spiky': return <>{[...Array(7)].map((_, i) => <polygon key={i} points={`${cx + Math.cos((i / 7) * Math.PI * 2 - Math.PI / 2) * headR * 0.6},${cy - headR * 0.2 + Math.sin((i / 7) * Math.PI * 2 - Math.PI / 2) * headR * 0.6} ${cx + Math.cos((i / 7) * Math.PI * 2 - Math.PI / 2) * headR * 1.4},${cy - headR * 0.2 + Math.sin((i / 7) * Math.PI * 2 - Math.PI / 2) * headR * 1.4} ${cx + Math.cos(((i + 0.5) / 7) * Math.PI * 2 - Math.PI / 2) * headR * 0.8},${cy - headR * 0.2 + Math.sin(((i + 0.5) / 7) * Math.PI * 2 - Math.PI / 2) * headR * 0.8}`} fill={hc} />)}</>;
      case 'braids': return <><ellipse cx={cx} cy={cy - headR * 0.35} rx={headR * 1.05} ry={headR * 0.8} fill={hc} />{[-1, 1].map(d => <g key={d}>{[0, 1, 2, 3].map(i => <ellipse key={i} cx={cx + d * headR * 0.85} cy={cy + i * headR * 0.35} rx={headR * 0.18} ry={headR * 0.15} fill={hc} opacity={1 - i * 0.15} />)}</g>)}</>;
      case 'none': return null;
      default: return <ellipse cx={cx} cy={cy - headR * 0.4} rx={headR * 1.05} ry={headR * 0.7} fill={hc} />;
    }
  };

  const renderEyes = () => {
    const eSize = headR * 0.12;
    switch (c.eyeStyle) {
      case 'cat': return <>{[-1, 1].map(d => <path key={d} d={`M${cx + d * eyeSpacing - eSize * 1.2},${eyeY + eSize * 0.5} Q${cx + d * eyeSpacing},${eyeY - eSize * 1.5} ${cx + d * eyeSpacing + eSize * 1.2},${eyeY + eSize * 0.5}`} fill="#333" />)}</>;
      case 'sparkle': return <>{[-1, 1].map(d => <g key={d}><circle cx={cx + d * eyeSpacing} cy={eyeY} r={eSize * 1.3} fill="#333" /><circle cx={cx + d * eyeSpacing - eSize * 0.3} cy={eyeY - eSize * 0.4} r={eSize * 0.5} fill="#fff" /><circle cx={cx + d * eyeSpacing + eSize * 0.4} cy={eyeY + eSize * 0.2} r={eSize * 0.25} fill="#fff" /></g>)}</>;
      case 'sleepy': return <>{[-1, 1].map(d => <path key={d} d={`M${cx + d * eyeSpacing - eSize},${eyeY} Q${cx + d * eyeSpacing},${eyeY + eSize * 0.8} ${cx + d * eyeSpacing + eSize},${eyeY}`} stroke="#333" strokeWidth={eSize * 0.5} fill="none" strokeLinecap="round" />)}</>;
      case 'wink': return <><circle cx={cx - eyeSpacing} cy={eyeY} r={eSize * 1.1} fill="#333" /><path d={`M${cx + eyeSpacing - eSize},${eyeY} Q${cx + eyeSpacing},${eyeY - eSize} ${cx + eyeSpacing + eSize},${eyeY}`} stroke="#333" strokeWidth={eSize * 0.5} fill="none" strokeLinecap="round" /></>;
      case 'heart': return <>{[-1, 1].map(d => <text key={d} x={cx + d * eyeSpacing} y={eyeY + eSize * 0.5} fontSize={eSize * 3} textAnchor="middle" fill="#FF6B9D">❤</text>)}</>;
      case 'star': return <>{[-1, 1].map(d => <text key={d} x={cx + d * eyeSpacing} y={eyeY + eSize * 0.5} fontSize={eSize * 3} textAnchor="middle">⭐</text>)}</>;
      case 'anime': return <>{[-1, 1].map(d => <g key={d}><ellipse cx={cx + d * eyeSpacing} cy={eyeY} rx={eSize * 1.5} ry={eSize * 1.8} fill="#333" /><ellipse cx={cx + d * eyeSpacing} cy={eyeY} rx={eSize * 1.2} ry={eSize * 1.5} fill={c.bgColor || '#FFB3BA'} /><circle cx={cx + d * eyeSpacing} cy={eyeY + eSize * 0.2} r={eSize * 0.8} fill="#333" /><circle cx={cx + d * eyeSpacing - eSize * 0.3} cy={eyeY - eSize * 0.3} r={eSize * 0.4} fill="#fff" /></g>)}</>;
      default: return <>{[-1, 1].map(d => <circle key={d} cx={cx + d * eyeSpacing} cy={eyeY} r={eSize * 1.1} fill="#333" />)}</>;
    }
  };

  const renderMouth = () => {
    const mw = headR * 0.3;
    switch (c.mouthStyle) {
      case 'grin': return <path d={`M${cx - mw},${mouthY} Q${cx},${mouthY + mw * 1.2} ${cx + mw},${mouthY}`} stroke="#333" strokeWidth={headR * 0.06} fill="none" strokeLinecap="round" />;
      case 'cat': return <path d={`M${cx - mw * 0.8},${mouthY} L${cx},${mouthY + mw * 0.3} L${cx + mw * 0.8},${mouthY}`} stroke="#333" strokeWidth={headR * 0.06} fill="none" strokeLinecap="round" />;
      case 'open': return <ellipse cx={cx} cy={mouthY + mw * 0.2} rx={mw * 0.5} ry={mw * 0.4} fill="#333" />;
      case 'pout': return <circle cx={cx} cy={mouthY + mw * 0.1} r={mw * 0.25} fill="#FF6B9D" />;
      case 'tongue': return <><path d={`M${cx - mw},${mouthY} Q${cx},${mouthY + mw} ${cx + mw},${mouthY}`} stroke="#333" strokeWidth={headR * 0.06} fill="none" /><ellipse cx={cx} cy={mouthY + mw * 0.6} rx={mw * 0.3} ry={mw * 0.25} fill="#FF6B9D" /></>;
      case 'neutral': return <line x1={cx - mw * 0.6} y1={mouthY} x2={cx + mw * 0.6} y2={mouthY} stroke="#333" strokeWidth={headR * 0.06} strokeLinecap="round" />;
      case 'smirk': return <path d={`M${cx - mw * 0.3},${mouthY} Q${cx + mw * 0.3},${mouthY + mw * 0.6} ${cx + mw * 0.8},${mouthY - mw * 0.1}`} stroke="#333" strokeWidth={headR * 0.06} fill="none" strokeLinecap="round" />;
      default: return <path d={`M${cx - mw},${mouthY} Q${cx},${mouthY + mw * 0.8} ${cx + mw},${mouthY}`} stroke="#333" strokeWidth={headR * 0.06} fill="none" strokeLinecap="round" />;
    }
  };

  const renderAccessory = () => {
    switch (c.accessory) {
      case 'glasses': return <><rect x={cx - eyeSpacing - headR * 0.18} y={eyeY - headR * 0.12} width={headR * 0.36} height={headR * 0.24} rx={headR * 0.04} fill="none" stroke="#555" strokeWidth={headR * 0.04} /><rect x={cx + eyeSpacing - headR * 0.18} y={eyeY - headR * 0.12} width={headR * 0.36} height={headR * 0.24} rx={headR * 0.04} fill="none" stroke="#555" strokeWidth={headR * 0.04} /><line x1={cx - eyeSpacing + headR * 0.18} y1={eyeY} x2={cx + eyeSpacing - headR * 0.18} y2={eyeY} stroke="#555" strokeWidth={headR * 0.04} /></>;
      case 'sunglasses': return <><rect x={cx - eyeSpacing - headR * 0.2} y={eyeY - headR * 0.14} width={headR * 0.4} height={headR * 0.28} rx={headR * 0.06} fill="#333" /><rect x={cx + eyeSpacing - headR * 0.2} y={eyeY - headR * 0.14} width={headR * 0.4} height={headR * 0.28} rx={headR * 0.06} fill="#333" /><line x1={cx - eyeSpacing + headR * 0.2} y1={eyeY} x2={cx + eyeSpacing - headR * 0.2} y2={eyeY} stroke="#333" strokeWidth={headR * 0.05} /></>;
      case 'bow': return <><circle cx={cx + headR * 0.7} cy={cy - headR * 0.7} r={headR * 0.15} fill="#FF6B9D" /><ellipse cx={cx + headR * 0.5} cy={cy - headR * 0.7} rx={headR * 0.2} ry={headR * 0.1} fill="#FF6B9D" /><ellipse cx={cx + headR * 0.9} cy={cy - headR * 0.7} rx={headR * 0.2} ry={headR * 0.1} fill="#FF6B9D" /></>;
      case 'crown': return <polygon points={`${cx - headR * 0.5},${cy - headR * 0.8} ${cx - headR * 0.3},${cy - headR * 1.2} ${cx},${cy - headR * 0.9} ${cx + headR * 0.3},${cy - headR * 1.2} ${cx + headR * 0.5},${cy - headR * 0.8}`} fill="#FFD700" stroke="#DAA520" strokeWidth={headR * 0.02} />;
      case 'cat_ears': return <>{[-1, 1].map(d => <polygon key={d} points={`${cx + d * headR * 0.5},${cy - headR * 0.6} ${cx + d * headR * 0.9},${cy - headR * 1.3} ${cx + d * headR * 1.1},${cy - headR * 0.6}`} fill={c.skinColor || '#FFE0BD'} stroke="#333" strokeWidth={headR * 0.02} />)}</>;
      case 'horns': return <>{[-1, 1].map(d => <polygon key={d} points={`${cx + d * headR * 0.4},${cy - headR * 0.7} ${cx + d * headR * 0.6},${cy - headR * 1.3} ${cx + d * headR * 0.8},${cy - headR * 0.7}`} fill="#C0392B" />)}</>;
      case 'halo': return <ellipse cx={cx} cy={cy - headR * 1.1} rx={headR * 0.6} ry={headR * 0.15} fill="none" stroke="#FFD700" strokeWidth={headR * 0.06} />;
      case 'flowers': return <>{[-0.7, 0, 0.7].map((off, i) => <circle key={i} cx={cx + off * headR * 0.8} cy={cy - headR * 0.85 - Math.abs(off) * headR * 0.15} r={headR * 0.12} fill={['#FF6B9D', '#FFD700', '#FF6B9D'][i]} />)}</>;
      case 'headband': return <rect x={cx - headR * 1.05} y={cy - headR * 0.55} width={headR * 2.1} height={headR * 0.12} rx={headR * 0.06} fill="#FF6B9D" />;
      case 'beanie': return <><ellipse cx={cx} cy={cy - headR * 0.5} rx={headR * 1.1} ry={headR * 0.6} fill="#5B6EAE" /><rect x={cx - headR * 1.1} y={cy - headR * 0.5} width={headR * 2.2} height={headR * 0.2} rx={headR * 0.1} fill="#4A5A9E" /></>;
      case 'tiara': return <><path d={`M${cx - headR * 0.5},${cy - headR * 0.75} Q${cx - headR * 0.25},${cy - headR * 1.1} ${cx},${cy - headR * 0.85} Q${cx + headR * 0.25},${cy - headR * 1.1} ${cx + headR * 0.5},${cy - headR * 0.75}`} fill="none" stroke="#C0A0FF" strokeWidth={headR * 0.05} /><circle cx={cx} cy={cy - headR * 0.9} r={headR * 0.06} fill="#FF69B4" /></>;
      default: return null;
    }
  };

  const renderOutfit = () => {
    const oc = c.outfitColor || '#FF6B6B';
    const bodyY = cy + headR * 0.65;
    switch (c.outfit) {
      case 'hoodie': return <><path d={`M${cx - headR * 0.9},${bodyY + headR * 0.8} Q${cx - headR * 1},${bodyY} ${cx - headR * 0.3},${bodyY} L${cx + headR * 0.3},${bodyY} Q${cx + headR * 1},${bodyY} ${cx + headR * 0.9},${bodyY + headR * 0.8}`} fill={oc} /><path d={`M${cx - headR * 0.15},${bodyY} L${cx},${bodyY + headR * 0.4} L${cx + headR * 0.15},${bodyY}`} fill="none" stroke={oc} strokeWidth={headR * 0.04} filter="brightness(0.85)" /></>;
      case 'dress': return <path d={`M${cx - headR * 0.3},${bodyY} Q${cx},${bodyY - headR * 0.1} ${cx + headR * 0.3},${bodyY} L${cx + headR * 1},${bodyY + headR * 1} L${cx - headR * 1},${bodyY + headR * 1} Z`} fill={oc} />;
      case 'suit': return <><path d={`M${cx - headR * 0.8},${bodyY + headR * 0.8} L${cx - headR * 0.4},${bodyY} L${cx + headR * 0.4},${bodyY} L${cx + headR * 0.8},${bodyY + headR * 0.8}`} fill="#2C3E50" /><line x1={cx} y1={bodyY} x2={cx} y2={bodyY + headR * 0.7} stroke="#fff" strokeWidth={headR * 0.03} /></>;
      case 'overalls': return <><rect x={cx - headR * 0.7} y={bodyY} width={headR * 1.4} height={headR * 0.8} rx={headR * 0.1} fill={oc} /><rect x={cx - headR * 0.2} y={bodyY + headR * 0.15} width={headR * 0.4} height={headR * 0.3} rx={headR * 0.05} fill={oc} opacity={0.7} /></>;
      case 'sweater': return <path d={`M${cx - headR * 0.85},${bodyY + headR * 0.8} Q${cx - headR * 0.9},${bodyY} ${cx - headR * 0.3},${bodyY} L${cx + headR * 0.3},${bodyY} Q${cx + headR * 0.9},${bodyY} ${cx + headR * 0.85},${bodyY + headR * 0.8}`} fill={oc} />;
      default: return <path d={`M${cx - headR * 0.7},${bodyY + headR * 0.7} L${cx - headR * 0.35},${bodyY} L${cx + headR * 0.35},${bodyY} L${cx + headR * 0.7},${bodyY + headR * 0.7}`} fill={oc} />;
    }
  };

  const renderBlush = () => {
    if (!c.blush) return null;
    return <>{[-1, 1].map(d => <ellipse key={d} cx={cx + d * eyeSpacing * 1.3} cy={eyeY + headR * 0.25} rx={headR * 0.12} ry={headR * 0.08} fill="#FF9AA2" opacity={0.5} />)}</>;
  };

  const renderSparkles = () => {
    if (!c.sparkles) return null;
    return <>{[[cx - headR * 1.2, cy - headR * 0.8], [cx + headR * 1.1, cy - headR * 0.6], [cx + headR * 1.3, cy + headR * 0.2]].map(([x, y], i) => <text key={i} x={x} y={y} fontSize={headR * 0.25} opacity={0.7}>✨</text>)}</>;
  };

  return (
    <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} className={className} style={{ borderRadius: '50%', background: c.bgColor || '#FFB3BA' }}>
      {renderOutfit()}
      {renderHair()}
      <circle cx={cx} cy={cy} r={headR} fill={c.skinColor || '#FFE0BD'} />
      {renderEyes()}
      {renderMouth()}
      {renderBlush()}
      {renderAccessory()}
      {renderSparkles()}
    </svg>
  );
}
