import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import type { User } from '../lib/types';
import { ArrowLeft, Bookmark, Trash2, Search, FileText, Image, Mic, Sparkles } from 'lucide-react';

interface SavedMsg {
  id: number;
  content: string;
  message_type: string;
  file_url: string | null;
  sender_name: string;
  source_chat: string;
  created_at: string;
}

export default function SavedMessages({ user, onBack }: { user: User; onBack: () => void }) {
  const [messages, setMessages] = useState<SavedMsg[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetchSaved = async () => {
    try {
      const res = await fetch(`/api/saved-messages?user_id=${user.id}`);
      const data = await res.json();
      setMessages(Array.isArray(data) ? data : []);
    } catch { setMessages([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchSaved(); }, []);

  const deleteSaved = async (id: number) => {
    await fetch('/api/saved-messages', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    fetchSaved();
  };

  const filtered = messages.filter(m => m.content.toLowerCase().includes(search.toLowerCase()) || m.sender_name.toLowerCase().includes(search.toLowerCase()));

  const getIcon = (type: string) => {
    if (type === 'voice') return <Mic size={14} className="text-red-400" />;
    if (type === 'file') return <FileText size={14} className="text-blue-400" />;
    if (type === 'sticker') return <span className="text-sm">🌟</span>;
    return <FileText size={14} className="text-gray-400" />;
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0B0F19]">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-800">
        <button onClick={onBack} className="text-gray-500 hover:text-gray-300"><ArrowLeft size={20} /></button>
        <Bookmark size={18} className="text-blue-400" />
        <h2 className="text-sm font-bold text-white">Saved Messages</h2>
        <span className="ml-auto text-[10px] text-gray-500">{messages.length} saved</span>
      </div>

      <div className="px-4 py-2">
        <div className="relative">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search saved..." className="w-full pl-9 pr-3 py-2 rounded-xl bg-gray-800/50 border border-gray-700/50 text-white text-xs placeholder-gray-500 focus:outline-none focus:border-blue-500/30" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
        {loading ? (
          <div className="flex items-center justify-center py-12"><Sparkles size={20} className="text-blue-400 animate-spin" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12"><Bookmark size={40} className="mx-auto mb-3 text-gray-700" /><p className="text-gray-500 text-sm">No saved messages yet</p><p className="text-gray-600 text-xs mt-1">Forward or save messages to find them here</p></div>
        ) : (
          filtered.map(msg => (
            <motion.div key={msg.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="bg-gray-800/30 rounded-xl p-3 border border-gray-700/30 group hover:border-gray-600/30 transition-all">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-gray-700/50 flex items-center justify-center flex-shrink-0">{getIcon(msg.message_type)}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-semibold text-blue-400">{msg.sender_name}</span>
                    {msg.source_chat && <span className="text-[9px] text-gray-600">from {msg.source_chat}</span>}
                  </div>
                  <p className="text-xs text-gray-300 break-words">{msg.content || 'Media'}</p>
                  <p className="text-[9px] text-gray-600 mt-1">{new Date(msg.created_at).toLocaleDateString()}</p>
                </div>
                <button onClick={() => deleteSaved(msg.id)} className="opacity-0 group-hover:opacity-100 text-gray-600 hover:text-red-400 transition-all"><Trash2 size={13} /></button>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
