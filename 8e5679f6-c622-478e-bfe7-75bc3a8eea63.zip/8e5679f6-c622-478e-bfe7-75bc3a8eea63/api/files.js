import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { file_name, file_type, file_size, file_data, sender_id, chat_type, chat_id, is_voice, is_timer, timer_views, is_spoiler } = req.body;
      const { data, error } = await supabase.from('files').insert({
        file_name, file_type, file_size: file_size || 0, file_data: file_data || '',
        sender_id, chat_type: chat_type || 'dm', chat_id: chat_id || 0,
        is_voice: is_voice || false, is_timer: is_timer || false,
        timer_views: timer_views || 0, views_count: 0, is_spoiler: is_spoiler || false
      }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'GET') {
      const { id, chat_type, chat_id } = req.query;
      if (id) {
        const { data, error } = await supabase.from('files').select('*').eq('id', parseInt(id)).single();
        if (error) throw error;
        // Handle timer views
        if (data.is_timer && data.views_count >= data.timer_views) {
          return res.status(410).json({ error: 'This media has expired' });
        }
        if (data.is_timer) {
          await supabase.from('files').update({ views_count: data.views_count + 1 }).eq('id', data.id);
        }
        return res.status(200).json(data);
      }
      if (chat_type && chat_id) {
        const { data, error } = await supabase.from('files').select('*').eq('chat_type', chat_type).eq('chat_id', parseInt(chat_id)).order('created_at', { ascending: false }).limit(50);
        if (error) throw error;
        return res.status(200).json(data);
      }
      return res.status(400).json({ error: 'Missing params' });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Files API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
