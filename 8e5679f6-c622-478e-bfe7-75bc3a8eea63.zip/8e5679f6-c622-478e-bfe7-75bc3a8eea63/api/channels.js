import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id, id, invite_code, search } = req.query;
      if (id) {
        const { data, error } = await supabase.from('channels').select('*').eq('id', parseInt(id)).single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (invite_code) {
        const { data, error } = await supabase.from('channels').select('*').eq('invite_code', invite_code).single();
        if (error && error.code === 'PGRST116') return res.status(404).json({ error: 'Channel not found' });
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (search) {
        const { data, error } = await supabase.from('channels').select('*').ilike('name', `%${search}%`).eq('is_public', true).order('subscriber_count', { ascending: false }).limit(20);
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (user_id) {
        const { data: subs } = await supabase.from('channel_subscribers').select('channel_id').eq('user_id', parseInt(user_id));
        const chIds = (subs || []).map(s => s.channel_id);
        if (chIds.length === 0) return res.status(200).json([]);
        const { data, error } = await supabase.from('channels').select('*').in('id', chIds);
        if (error) throw error;
        return res.status(200).json(data);
      }
      const { data, error } = await supabase.from('channels').select('*').order('subscriber_count', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { name, description, avatar_url, created_by, is_public } = req.body;
      const invite_code = 'ch_' + Math.random().toString(36).substring(2, 8);
      const { data, error } = await supabase.from('channels').insert({
        name, description: description || '', avatar_url: avatar_url || '',
        created_by, is_public: is_public !== false, subscriber_count: 1, invite_code
      }).select().single();
      if (error) throw error;
      await supabase.from('channel_subscribers').insert({ channel_id: data.id, user_id: created_by, role: 'owner' });
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      const { data, error } = await supabase.from('channels').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      await supabase.from('channel_subscribers').delete().eq('channel_id', id);
      await supabase.from('messages').delete().eq('channel_id', id);
      const { error } = await supabase.from('channels').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
