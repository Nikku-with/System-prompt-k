export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { action, text, target_lang } = req.body;
    
    if (action === 'smart_reply') {
      const prompt = `Generate 3 short casual reply suggestions for this message. Return ONLY a JSON array of 3 strings, nothing else. Message: "${text}"`;
      const r = await fetch(`https://text.pollinations.ai/${encodeURIComponent(prompt)}`);
      const raw = await r.text();
      try {
        const parsed = JSON.parse(raw.trim());
        if (Array.isArray(parsed)) return res.status(200).json({ replies: parsed.slice(0, 3) });
      } catch {}
      return res.status(200).json({ replies: ['👍', '😂', 'nice!'] });
    }
    
    if (action === 'translate') {
      const lang = target_lang || 'English';
      const prompt = `Translate this text to ${lang}. Return ONLY the translated text, nothing else: "${text}"`;
      const r = await fetch(`https://text.pollinations.ai/${encodeURIComponent(prompt)}`);
      const translated = await r.text();
      return res.status(200).json({ translated: translated.trim() });
    }

    if (action === 'transcribe') {
      // Voice-to-text placeholder - would need actual audio processing
      return res.status(200).json({ text: '[Voice message]' });
    }

    return res.status(400).json({ error: 'Unknown action' });
  } catch (err) {
    console.error('AI tools error:', err);
    return res.status(500).json({ error: err.message });
  }
}
