import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id } = req.query;
      // Get notes that haven't expired
      const { data, error } = await supabase.from('user_notes').select('*').eq('user_id', parseInt(user_id)).order('created_at', { ascending: false });
      if (error) throw error;
      // Filter expired
      const now = new Date();
      const active = (data || []).filter(n => !n.expires_at || new Date(n.expires_at) > now);
      return res.status(200).json(active);
    }
    if (req.method === 'POST') {
      const { user_id, content, note_type } = req.body;
      const expires_at = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
      const { data, error } = await supabase.from('user_notes').insert({
        user_id, content, note_type: note_type || 'text', expires_at
      }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      await supabase.from('user_notes').delete().eq('id', id);
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Notes error:', err);
    return res.status(500).json({ error: err.message });
  }
}
