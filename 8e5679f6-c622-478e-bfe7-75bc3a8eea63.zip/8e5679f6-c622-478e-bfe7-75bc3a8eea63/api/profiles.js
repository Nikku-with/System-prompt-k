import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id } = req.query;
      const { data, error } = await supabase.from('user_profiles').select('*').eq('user_id', parseInt(user_id)).single();
      if (error && error.code === 'PGRST116') {
        // Create default profile
        const { data: created } = await supabase.from('user_profiles').insert({ user_id: parseInt(user_id) }).select().single();
        return res.status(200).json(created);
      }
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'PUT') {
      const { user_id, ...updates } = req.body;
      const { data: existing } = await supabase.from('user_profiles').select('id').eq('user_id', user_id).single();
      if (existing) {
        const { data, error } = await supabase.from('user_profiles').update(updates).eq('user_id', user_id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      } else {
        const { data, error } = await supabase.from('user_profiles').insert({ user_id, ...updates }).select().single();
        if (error) throw error;
        return res.status(201).json(data);
      }
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Profile error:', err);
    return res.status(500).json({ error: err.message });
  }
}
