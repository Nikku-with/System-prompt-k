import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { message_ids, target_type, target_id, sender_id, sender_name, sender_avatar } = req.body;
    const results = [];
    for (const msgId of (message_ids || [])) {
      const { data: original } = await supabase.from('messages').select('*').eq('id', msgId).single();
      if (!original) continue;
      // Use tagged_users field to store forward info as JSON
      const forwardInfo = JSON.stringify({ forwarded: true, from: original.sender_name });
      const fwd = {
        sender_id, sender_name, sender_avatar,
        content: original.content, message_type: original.message_type || 'text',
        sticker_url: original.sticker_url,
        tagged_users: forwardInfo,
        reactions: '{}',
      };
      if (target_type === 'group') fwd.group_id = target_id;
      else if (target_type === 'channel') fwd.channel_id = target_id;
      else fwd.dm_id = target_id;
      
      const { data, error } = await supabase.from('messages').insert(fwd).select().single();
      if (!error) results.push(data);
    }
    return res.status(201).json(results);
  } catch (err) {
    console.error('Forward error:', err);
    return res.status(500).json({ error: err.message });
  }
}
