import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { group_id } = req.query;
      const { data, error } = await supabase.from('group_settings_v2').select('*').eq('group_id', parseInt(group_id)).single();
      if (error && error.code === 'PGRST116') {
        // Return defaults
        return res.status(200).json({
          group_id: parseInt(group_id), slow_mode: 0, members_can_send: true,
          members_can_add: true, members_can_pin: false, members_can_edit_info: false,
          anti_spam: false, welcome_message: '', rules: ''
        });
      }
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST' || req.method === 'PUT') {
      const { group_id, ...settings } = req.body;
      const { data: existing } = await supabase.from('group_settings_v2').select('id').eq('group_id', group_id).single();
      if (existing) {
        const { data, error } = await supabase.from('group_settings_v2').update(settings).eq('group_id', group_id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      } else {
        const { data, error } = await supabase.from('group_settings_v2').insert({ group_id, ...settings }).select().single();
        if (error) throw error;
        return res.status(201).json(data);
      }
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
