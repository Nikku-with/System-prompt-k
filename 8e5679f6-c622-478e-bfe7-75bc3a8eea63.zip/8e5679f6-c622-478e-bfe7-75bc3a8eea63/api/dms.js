import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id } = req.query;
      const uid = parseInt(user_id);
      const { data, error } = await supabase.from('dms').select('*').or(`user1_id.eq.${uid},user2_id.eq.${uid}`).order('updated_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { user1_id, user2_id } = req.body;
      const u1 = Math.min(user1_id, user2_id);
      const u2 = Math.max(user1_id, user2_id);
      const { data: existing } = await supabase.from('dms').select('*').eq('user1_id', u1).eq('user2_id', u2).single();
      if (existing) return res.status(200).json(existing);
      const { data, error } = await supabase.from('dms').insert({ user1_id: u1, user2_id: u2 }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
