import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { channel_id } = req.query;
      const { data, error } = await supabase.from('channel_subscribers').select('*').eq('channel_id', parseInt(channel_id));
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { channel_id, user_id } = req.body;
      const { data: existing } = await supabase.from('channel_subscribers').select('*').eq('channel_id', channel_id).eq('user_id', user_id).single();
      if (existing) return res.status(200).json(existing);
      const { data, error } = await supabase.from('channel_subscribers').insert({ channel_id, user_id, role: 'subscriber' }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const { channel_id, user_id } = req.body;
      const { error } = await supabase.from('channel_subscribers').delete().eq('channel_id', channel_id).eq('user_id', user_id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
