import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id, type } = req.query;
      const uid = parseInt(user_id);
      if (type === 'pending') {
        const { data } = await supabase.from('friend_requests').select('*').eq('to_user_id', uid).eq('status', 'pending').order('created_at', { ascending: false });
        return res.status(200).json(data || []);
      }
      if (type === 'sent') {
        const { data } = await supabase.from('friend_requests').select('*').eq('from_user_id', uid).eq('status', 'pending');
        return res.status(200).json(data || []);
      }
      // Get accepted friends
      const { data } = await supabase.from('friend_requests').select('*').or(`from_user_id.eq.${uid},to_user_id.eq.${uid}`).eq('status', 'accepted');
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const { from_user_id, to_user_id } = req.body;
      // Check existing
      const { data: existing } = await supabase.from('friend_requests').select('*').or(`and(from_user_id.eq.${from_user_id},to_user_id.eq.${to_user_id}),and(from_user_id.eq.${to_user_id},to_user_id.eq.${from_user_id})`).single();
      if (existing) return res.status(200).json(existing);
      const { data, error } = await supabase.from('friend_requests').insert({ from_user_id, to_user_id, status: 'pending' }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, status } = req.body;
      const { data, error } = await supabase.from('friend_requests').update({ status }).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      await supabase.from('friend_requests').delete().eq('id', id);
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Friends error:', err);
    return res.status(500).json({ error: err.message });
  }
}
