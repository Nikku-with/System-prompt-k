import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  // Helper: merge user + settings
  const mergeSettings = async (user) => {
    if (!user) return user;
    const { data: settings } = await supabase.from('user_settings').select('*').eq('user_id', user.id).single();
    return { ...user, username: settings?.username || user.anon_id, chat_theme: settings?.chat_theme || 'aurora' };
  };

  try {
    if (req.method === 'GET') {
      const { auth_id, id, search, username } = req.query;
      if (auth_id) {
        const { data, error } = await supabase.from('users').select('*').eq('auth_id', auth_id).single();
        if (error && error.code === 'PGRST116') return res.status(404).json({ error: 'User not found' });
        if (error) throw error;
        return res.status(200).json(await mergeSettings(data));
      }
      if (id) {
        const { data, error } = await supabase.from('users').select('*').eq('id', parseInt(id)).single();
        if (error) throw error;
        return res.status(200).json(await mergeSettings(data));
      }
      if (username) {
        const { data: setting } = await supabase.from('user_settings').select('*').eq('username', username).single();
        if (!setting) return res.status(404).json({ error: 'User not found' });
        const { data, error } = await supabase.from('users').select('*').eq('id', setting.user_id).single();
        if (error) throw error;
        return res.status(200).json(await mergeSettings(data));
      }
      if (search) {
        const q = search.toLowerCase();
        // Search in user_settings usernames + users display_name
        const { data: settings } = await supabase.from('user_settings').select('user_id, username').ilike('username', `%${q}%`).limit(20);
        const settingUserIds = (settings || []).map(s => s.user_id);
        
        const { data: byName } = await supabase.from('users').select('*').ilike('display_name', `%${q}%`).limit(20);
        const nameUserIds = (byName || []).map(u => u.id);
        
        const allIds = [...new Set([...settingUserIds, ...nameUserIds])];
        if (allIds.length === 0) return res.status(200).json([]);
        
        const { data: users, error } = await supabase.from('users').select('*').in('id', allIds).limit(20);
        if (error) throw error;
        
        // Merge settings for all
        const { data: allSettings } = await supabase.from('user_settings').select('*').in('user_id', allIds);
        const settingsMap = {};
        (allSettings || []).forEach(s => { settingsMap[s.user_id] = s; });
        const merged = (users || []).map(u => ({
          ...u,
          username: settingsMap[u.id]?.username || u.anon_id,
          chat_theme: settingsMap[u.id]?.chat_theme || 'aurora'
        }));
        return res.status(200).json(merged);
      }
      // Get all users with settings
      const { data, error } = await supabase.from('users').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      const userIds = data.map(u => u.id);
      const { data: allSettings } = await supabase.from('user_settings').select('*').in('user_id', userIds);
      const settingsMap = {};
      (allSettings || []).forEach(s => { settingsMap[s.user_id] = s; });
      const merged = data.map(u => ({
        ...u,
        username: settingsMap[u.id]?.username || u.anon_id,
        chat_theme: settingsMap[u.id]?.chat_theme || 'aurora'
      }));
      return res.status(200).json(merged);
    }
    if (req.method === 'POST') {
      const { auth_id, display_name, username, avatar_config, bio, status_emoji, chat_theme } = req.body;
      const { data: existing } = await supabase.from('users').select('*').eq('auth_id', auth_id).single();
      if (existing) {
        return res.status(200).json(await mergeSettings(existing));
      }
      const anon_id = 'cutie_' + Math.random().toString(36).substring(2, 10);
      const finalUsername = (username || anon_id).toLowerCase().replace(/[^a-z0-9_]/g, '_');
      
      // Check username uniqueness
      if (username) {
        const { data: taken } = await supabase.from('user_settings').select('id').eq('username', finalUsername).single();
        if (taken) return res.status(400).json({ error: 'Username already taken bestie! Try another one 💕' });
      }
      
      const { data, error } = await supabase.from('users').insert({
        auth_id, display_name: display_name || finalUsername, anon_id,
        avatar_config: avatar_config || '{}', bio: bio || '', status_emoji: status_emoji || '✨', is_online: true
      }).select().single();
      if (error) throw error;
      
      // Create settings
      await supabase.from('user_settings').insert({
        user_id: data.id, username: finalUsername, chat_theme: chat_theme || 'aurora'
      });
      
      return res.status(201).json({ ...data, username: finalUsername, chat_theme: chat_theme || 'aurora' });
    }
    if (req.method === 'PUT') {
      const { id, username, chat_theme, ...rest } = req.body;
      
      // Update main user fields
      if (Object.keys(rest).length > 0) {
        const { error } = await supabase.from('users').update(rest).eq('id', id);
        if (error) throw error;
      }
      
      // Update settings
      if (username !== undefined || chat_theme !== undefined) {
        const settingsUpdate = {};
        if (username !== undefined) {
          const clean = username.toLowerCase().replace(/[^a-z0-9_]/g, '_');
          const { data: taken } = await supabase.from('user_settings').select('id').eq('username', clean).neq('user_id', id).single();
          if (taken) return res.status(400).json({ error: 'Username already taken bestie! Try another one 💕' });
          settingsUpdate.username = clean;
        }
        if (chat_theme !== undefined) settingsUpdate.chat_theme = chat_theme;
        
        const { data: existing } = await supabase.from('user_settings').select('id').eq('user_id', id).single();
        if (existing) {
          await supabase.from('user_settings').update(settingsUpdate).eq('user_id', id);
        } else {
          await supabase.from('user_settings').insert({ user_id: id, username: settingsUpdate.username || '', chat_theme: settingsUpdate.chat_theme || 'aurora' });
        }
      }
      
      const { data, error } = await supabase.from('users').select('*').eq('id', id).single();
      if (error) throw error;
      return res.status(200).json(await mergeSettings(data));
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
