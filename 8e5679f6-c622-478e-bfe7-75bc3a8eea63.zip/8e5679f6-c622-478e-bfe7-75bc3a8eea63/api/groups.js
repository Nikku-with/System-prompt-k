import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id, id, invite_code, search } = req.query;
      if (id) {
        const { data, error } = await supabase.from('groups').select('*').eq('id', parseInt(id)).single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (invite_code) {
        const { data, error } = await supabase.from('groups').select('*').eq('invite_code', invite_code).single();
        if (error && error.code === 'PGRST116') return res.status(404).json({ error: 'Group not found' });
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (search) {
        const { data, error } = await supabase.from('groups').select('*').ilike('name', `%${search}%`).eq('is_public', true).order('member_count', { ascending: false }).limit(20);
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (user_id) {
        const { data: memberships, error: mErr } = await supabase.from('group_members').select('group_id').eq('user_id', parseInt(user_id));
        if (mErr) throw mErr;
        const groupIds = memberships.map(m => m.group_id);
        if (groupIds.length === 0) return res.status(200).json([]);
        const { data, error } = await supabase.from('groups').select('*').in('id', groupIds).order('created_at', { ascending: false });
        if (error) throw error;
        return res.status(200).json(data);
      }
      const { data, error } = await supabase.from('groups').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { name, description, avatar_url, created_by, is_public, max_members } = req.body;
      const invite_code = Math.random().toString(36).substring(2, 10);
      const { data, error } = await supabase.from('groups').insert({
        name, description: description || '', avatar_url: avatar_url || '',
        created_by, is_public: is_public !== false, max_members: max_members || 500,
        member_count: 1, invite_code, settings: '{}'
      }).select().single();
      if (error) throw error;
      await supabase.from('group_members').insert({ group_id: data.id, user_id: created_by, role: 'owner' });
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      const { data, error } = await supabase.from('groups').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      await supabase.from('group_members').delete().eq('group_id', id);
      await supabase.from('messages').delete().eq('group_id', id);
      const { error } = await supabase.from('groups').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
