import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { group_id } = req.query;
      const { data, error } = await supabase.from('group_members').select('*').eq('group_id', parseInt(group_id));
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { group_id, user_id, role } = req.body;
      const { data: existing } = await supabase.from('group_members').select('*').eq('group_id', group_id).eq('user_id', user_id).single();
      if (existing) return res.status(200).json(existing);
      const { data, error } = await supabase.from('group_members').insert({ group_id, user_id, role: role || 'member' }).select().single();
      if (error) throw error;
      await supabase.from('groups').select('member_count').eq('id', group_id).single().then(async ({ data: g }) => {
        if (g) await supabase.from('groups').update({ member_count: (g.member_count || 0) + 1 }).eq('id', group_id);
      });
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { group_id, user_id, role } = req.body;
      const { data, error } = await supabase.from('group_members').update({ role }).eq('group_id', group_id).eq('user_id', user_id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { group_id, user_id } = req.body;
      const { error } = await supabase.from('group_members').delete().eq('group_id', group_id).eq('user_id', user_id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
