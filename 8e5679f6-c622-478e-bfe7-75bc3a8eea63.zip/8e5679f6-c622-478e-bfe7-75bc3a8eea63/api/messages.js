import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { channel_id, group_id, dm_id, limit: lim, before_id, search, pinned_only } = req.query;
      const limit = parseInt(lim) || 50;
      let query = supabase.from('messages').select('*');
      if (channel_id) query = query.eq('channel_id', parseInt(channel_id));
      if (group_id) query = query.eq('group_id', parseInt(group_id));
      if (dm_id) query = query.eq('dm_id', parseInt(dm_id));
      if (before_id) query = query.lt('id', parseInt(before_id));
      if (pinned_only === 'true') query = query.eq('is_pinned', true);
      if (search) query = query.ilike('content', `%${search}%`);
      const { data, error } = await query.order('created_at', { ascending: true }).limit(limit);
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { sender_id, sender_name, sender_avatar, content, message_type, sticker_url,
              reply_to_id, reply_to_content, reply_to_name, channel_id, group_id, dm_id,
              tagged_users, scheduled_at, is_silent } = req.body;
      
      const msg = {
        sender_id, sender_name: sender_name || 'Anonymous', sender_avatar: sender_avatar || '{}',
        content: content || '', message_type: message_type || 'text',
        sticker_url: sticker_url || null, reply_to_id: reply_to_id || null,
        reply_to_content: reply_to_content || null, reply_to_name: reply_to_name || null,
        channel_id: channel_id || null, group_id: group_id || null, dm_id: dm_id || null,
        tagged_users: tagged_users || '[]', reactions: '{}'
      };

      // If scheduled, store in scheduled_at field via tagged_users JSON hack
      if (scheduled_at) {
        msg.tagged_users = JSON.stringify({ scheduled: true, scheduled_at, is_silent: !!is_silent });
      }

      const { data, error } = await supabase.from('messages').insert(msg).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, reactions, is_pinned, content } = req.body;
      const updates = {};
      if (reactions !== undefined) updates.reactions = reactions;
      if (is_pinned !== undefined) updates.is_pinned = is_pinned;
      if (content !== undefined) updates.content = content; // Edit message
      
      const { data, error } = await supabase.from('messages').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id, bulk_ids } = req.body;
      if (bulk_ids && Array.isArray(bulk_ids)) {
        // Bulk delete
        const { error } = await supabase.from('messages').delete().in('id', bulk_ids);
        if (error) throw error;
        return res.status(200).json({ ok: true, deleted: bulk_ids.length });
      }
      const { error } = await supabase.from('messages').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
