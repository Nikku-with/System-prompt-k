export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const { q, type } = req.query;
  const query = q || 'cute';
  
  try {
    // Use GIPHY beta key for stickers
    const giphyKey = 'GlVGYHkr3WSBnllca54iNt0yFbjz7L65';
    const endpoint = type === 'trending'
      ? `https://api.giphy.com/v1/stickers/trending?api_key=${giphyKey}&limit=30&rating=g`
      : `https://api.giphy.com/v1/stickers/search?api_key=${giphyKey}&q=${encodeURIComponent(query)}&limit=30&rating=g`;
    
    const response = await fetch(endpoint);
    const json = await response.json();
    
    const stickers = (json.data || []).map(s => ({
      id: s.id,
      title: s.title,
      url: s.images?.fixed_height?.url || s.images?.original?.url,
      preview: s.images?.fixed_height_small?.url || s.images?.preview_gif?.url,
      width: s.images?.fixed_height?.width,
      height: s.images?.fixed_height?.height
    }));
    
    return res.status(200).json(stickers);
  } catch (err) {
    console.error('Sticker API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
